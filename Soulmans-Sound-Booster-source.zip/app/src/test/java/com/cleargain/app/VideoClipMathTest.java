package com.cleargain.app;

import static org.junit.Assert.assertEquals;
import org.junit.Test;

public final class VideoClipMathTest {
    @Test public void trimSliderMapsAcrossTheWholeVideo() {
        assertEquals(0, VideoClipMath.fromProgress(0, 60_000));
        assertEquals(30_000, VideoClipMath.fromProgress(500, 60_000));
        assertEquals(60_000, VideoClipMath.fromProgress(1000, 60_000));
        assertEquals(250, VideoClipMath.toProgress(15_000, 60_000));
    }

    @Test public void savedTrimIsClampedAndKeepsAtLeastOneSecond() {
        assertEquals(1_000, VideoClipMath.normalize(-500, 800, 10_000)[1]);
        assertEquals(9_000, VideoClipMath.normalize(20_000, 0, 10_000)[0]);
        assertEquals(10_000, VideoClipMath.normalize(20_000, 0, 10_000)[1]);
    }

    @Test public void shortVideoCanUseItsFullDurationAsTheMinimumRange() {
        long[] range = VideoClipMath.normalize(900, 200, 500);
        assertEquals(0, range[0]);
        assertEquals(500, range[1]);
    }
}
