package com.cleargain.app;

import org.junit.Test;
import static org.junit.Assert.*;

public class ReelTapeMathTest {
    @Test public void tapeTransfersCompletelyAtSongStartAndEnd() {
        assertEquals(50, ReelTapeMath.packRadius(1,17,50),.001);
        assertEquals(17, ReelTapeMath.packRadius(0,17,50),.001);
        assertEquals(0, ReelTapeMath.progress(-100,1000),.001);
        assertEquals(1, ReelTapeMath.progress(3000,1000),.001);
        assertEquals(0, ReelTapeMath.progress(1000,0),.001);
    }
    @Test public void combinedTapePackAreaStaysConstantAsTheSongPlays() {
        for(int step=0;step<=100;step++) {
            double fraction=step/100.0;
            double supply=ReelTapeMath.packRadius(1-fraction,17,50);
            double takeup=ReelTapeMath.packRadius(fraction,17,50);
            assertEquals(50*50+17*17,supply*supply+takeup*takeup,.01);
        }
    }
    @Test public void seekingRebalancesTheReelsUsingTheMediaTimeline() {
        double progress=ReelTapeMath.progress(75000,100000);
        assertEquals(.75,progress,.001);
        assertTrue(ReelTapeMath.packRadius(progress,17,50)>ReelTapeMath.packRadius(1-progress,17,50));
    }
}
