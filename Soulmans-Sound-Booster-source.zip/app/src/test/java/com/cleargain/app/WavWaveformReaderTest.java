package com.cleargain.app;

import static org.junit.Assert.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import org.junit.Test;

public class WavWaveformReaderTest {
    @Test public void extractsPeakLevelsByPosition() throws Exception {
        float[] peaks=WavWaveformReader.read(new ByteArrayInputStream(pcm16Wav(new short[]{0,16384,1000,32767})),2);
        assertNotNull(peaks);assertEquals(2,peaks.length);assertEquals(.5f,peaks[0],.01f);assertEquals(1f,peaks[1],.01f);
    }
    @Test public void returnsNoEnvelopeForCompressedWavData() throws Exception {
        assertNull(WavWaveformReader.read(new ByteArrayInputStream(wavHeader(6,16,new byte[8])),4));
    }
    @Test public void ignoresNonWavInput() throws Exception {
        assertNull(WavWaveformReader.read(new ByteArrayInputStream(new byte[]{1,2,3,4}),4));
    }
    @Test public void shortClipsDoNotGetArtificialEmptyBinsWhenZoomResolutionIsHigh() throws Exception {
        float[] peaks=WavWaveformReader.read(new ByteArrayInputStream(pcm16Wav(new short[]{16384,16384,16384,16384})),16384);
        assertEquals(4,peaks.length);
        for(float peak:peaks)assertEquals(.5f,peak,.001f);
    }
    private static byte[] pcm16Wav(short[] values)throws IOException{return wavHeader(1,16,samples(values));}
    private static byte[] samples(short[] values){byte[] out=new byte[values.length*2];for(int i=0;i<values.length;i++){out[i*2]=(byte)values[i];out[i*2+1]=(byte)(values[i]>>8);}return out;}
    private static byte[] wavHeader(int format,int bits,byte[] samples)throws IOException{
        ByteArrayOutputStream out=new ByteArrayOutputStream();ascii(out,"RIFF");le32(out,36+samples.length);ascii(out,"WAVEfmt ");le32(out,16);le16(out,format);le16(out,1);le32(out,8000);le32(out,8000*(bits/8));le16(out,bits/8);le16(out,bits);ascii(out,"data");le32(out,samples.length);out.write(samples);return out.toByteArray();
    }
    private static void ascii(ByteArrayOutputStream out,String value)throws IOException{out.write(value.getBytes("US-ASCII"));}
    private static void le16(ByteArrayOutputStream out,int n){out.write(n&255);out.write((n>>8)&255);}
    private static void le32(ByteArrayOutputStream out,int n){out.write(n&255);out.write((n>>8)&255);out.write((n>>16)&255);out.write((n>>24)&255);}
}
