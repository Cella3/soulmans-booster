package com.cleargain.app;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;
import static org.junit.Assert.*;

public final class PcmWaveWriterTest {
    @Rule public final TemporaryFolder files = new TemporaryFolder();

    @Test public void stereoTakeHasCorrectHeaderAndSignedLittleEndianSamples() throws Exception {
        File file = files.newFile("stereo.wav");
        try (PcmWaveWriter writer = new PcmWaveWriter(file, 48000, 2)) {
            writer.write(new short[]{Short.MIN_VALUE, Short.MAX_VALUE, -1, 0}, 4);
        }
        ByteBuffer bytes = ByteBuffer.wrap(Files.readAllBytes(file.toPath())).order(ByteOrder.LITTLE_ENDIAN);
        assertEquals(52, bytes.capacity()); assertEquals(44, bytes.getInt(4));
        assertEquals(1, bytes.getShort(20)); assertEquals(2, bytes.getShort(22));
        assertEquals(48000, bytes.getInt(24)); assertEquals(192000, bytes.getInt(28));
        assertEquals(4, bytes.getShort(32)); assertEquals(16, bytes.getShort(34)); assertEquals(8, bytes.getInt(40));
        assertEquals(Short.MIN_VALUE, bytes.getShort(44)); assertEquals(Short.MAX_VALUE, bytes.getShort(46));
        assertEquals(-1, bytes.getShort(48)); assertEquals(0, bytes.getShort(50));
    }

    @Test public void checkpointKeepsLaterAudioAndDurationCorrect() throws Exception {
        File file = files.newFile("mono.wav"); short[] block = new short[4410]; block[0] = 12345;
        try (PcmWaveWriter writer = new PcmWaveWriter(file, 44100, 1)) {
            writer.write(block, block.length); writer.checkpoint(); writer.write(block, block.length);
            assertEquals(200, writer.durationMs());
        }
        assertEquals(200, PcmWaveWriter.durationMs(file));
        ByteBuffer bytes = ByteBuffer.wrap(Files.readAllBytes(file.toPath())).order(ByteOrder.LITTLE_ENDIAN);
        assertEquals(17640, bytes.getInt(40)); assertEquals(12345, bytes.getShort(44 + 8820));
    }

    @Test public void interruptedStereoDraftRecoversOnlyCompleteFrames() throws Exception {
        File file = files.newFile("draft.part");
        try (PcmWaveWriter writer = new PcmWaveWriter(file, 48000, 2)) { writer.write(new short[]{1, 2, 3, 4}, 4); }
        try (RandomAccessFile broken = new RandomAccessFile(file, "rw")) { broken.seek(40); broken.writeInt(0); broken.seek(broken.length()); broken.write(99); }
        PcmWaveWriter.repair(file);
        ByteBuffer bytes = ByteBuffer.wrap(Files.readAllBytes(file.toPath())).order(ByteOrder.LITTLE_ENDIAN);
        assertEquals(52, bytes.capacity()); assertEquals(8, bytes.getInt(40)); assertEquals(4, bytes.getShort(50));
    }

    @Test public void rejectsHalfOfAStereoFrame() throws Exception {
        try (PcmWaveWriter writer = new PcmWaveWriter(files.newFile("invalid.wav"), 44100, 2)) {
            assertThrows(IllegalArgumentException.class, () -> writer.write(new short[]{1}, 1));
        }
    }
}
