package com.cleargain.app;

import org.junit.Test;
import static org.junit.Assert.*;

public class DjMathTest {
    @Test public void crossfaderHasEqualPowerAndIsolatesEachDeck(){
        for(int i=0;i<=100;i++){float x=i/100f,a=DjEngine.fadeGain(x,0),b=DjEngine.fadeGain(x,1);assertEquals(1,a*a+b*b,.000001);}
        assertEquals(1,DjEngine.fadeGain(0,0),0);assertEquals(0,DjEngine.fadeGain(0,1),.000001);assertEquals(1,DjEngine.fadeGain(1,1),.000001);
    }
    @Test public void scratchCanRunBackwardAndStopsWhenHandStops(){
        assertTrue(DjEngine.transportStep(true,1000,2000,44100,1,true,10)<0);
        assertTrue(DjEngine.transportStep(true,2000,1000,44100,1,false,10)>0);
        assertEquals(0,DjEngine.transportStep(true,2000,1000,44100,1,true,100),0);
        assertEquals(48000.0/44100,DjEngine.transportStep(false,0,0,48000,1,true,0),.000001);
        assertEquals(0,DjEngine.transportStep(false,0,0,44100,1,false,0),0);
    }
    @Test public void silenceHasNoInventedTempoOrKey(){DjAnalysis.Result r=DjAnalysis.analyze(new float[11025*10],11025);assertEquals(0,r.bpm(),0);assertEquals("Unknown",r.key());}
    @Test public void regularClicksAreAnalyzedAs120Bpm(){int rate=11025;float[] samples=new float[rate*25];for(int i=0;i<samples.length;i++){int beat=i%(rate/2);if(beat<rate/25)samples[i]=(float)(Math.sin(i*2*Math.PI*180/rate)*Math.exp(-beat/(rate*.007)));}DjAnalysis.Result r=DjAnalysis.analyze(samples,rate);assertEquals(120,r.bpm(),2);assertTrue(r.confidence()>.12);}
    @Test public void majorKeyTemplateRotatesCorrectly(){double[] c={6.35,2.23,3.48,2.33,4.38,4.09,2.52,5.19,2.39,3.66,2.29,2.88};assertEquals("C major",DjAnalysis.key(c));double[] g=new double[12];for(int i=0;i<12;i++)g[(i+7)%12]=c[i];assertEquals("G major",DjAnalysis.key(g));}
}
