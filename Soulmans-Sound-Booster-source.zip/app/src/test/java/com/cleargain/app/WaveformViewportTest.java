package com.cleargain.app;

import org.junit.Test;
import static org.junit.Assert.*;

public class WaveformViewportTest {
    @Test public void pannedAndZoomedSeekUsesVisibleTimeRatherThanWholeSong() {
        WaveformViewport view = new WaveformViewport();
        view.zoomBy(4); view.panTo(1);
        assertEquals(.75, view.timeAt(0), 1e-9);
        assertEquals(.875, view.timeAt(.5), 1e-9);
        assertEquals(1, view.timeAt(1), 1e-9);
        assertEquals(.5, view.xAt(.875), 1e-9);
    }
    @Test public void zoomPreservesWindowCenterAndClampsAtFileEnds() {
        WaveformViewport view = new WaveformViewport();
        view.zoomBy(4); view.panTo(.4);
        double center = view.timeAt(.5); view.zoomBy(2);
        assertEquals(center, view.timeAt(.5), 1e-9);
        view.panTo(-5); assertEquals(0, view.start(), 1e-9);
        view.panTo(99); assertEquals(1, view.end(), 1e-9);
        view.zoomBy(.01); assertEquals(0, view.start(), 1e-9); assertEquals(1, view.span(), 1e-9);
        view.zoomBy(1e9); assertEquals(128, view.zoom(), 1e-9);
    }
    @Test public void defaultShowsThirtySecondsAroundAnchorAndShortFilesFit() {
        WaveformViewport view = new WaveformViewport();
        view.setDuration(180000); view.defaultView(.5);
        assertEquals(30000, view.span() * view.duration(), .01);
        assertEquals(.5, view.timeAt(.5), 1e-9);
        view.setDuration(5000); view.defaultView(.9);
        assertEquals(1, view.span(), 1e-9); assertEquals(0, view.start(), 1e-9);
    }
    @Test public void peakPoolingIncludesTransientAndRespectsPannedWindow() {
        WaveformViewport view = new WaveformViewport();
        float[] peaks = {0, 1, 0, 0, .2f, .3f, .4f, .5f};
        assertEquals(1, view.peak(peaks, 0, .5), .001);
        view.zoomBy(2); view.panTo(1);
        assertEquals(.3, view.peak(peaks, 0, .5), .001);
        assertEquals(.5, view.peak(peaks, .5, 1), .001);
    }
}
