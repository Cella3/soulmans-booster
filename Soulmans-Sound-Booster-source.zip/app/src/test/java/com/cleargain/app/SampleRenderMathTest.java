package com.cleargain.app;

import static org.junit.Assert.*;
import org.junit.Test;

public class SampleRenderMathTest {
    @Test public void pitchMovesClipByOctaveWithoutChangingChannels(){
        short[] input={1000,-1000,2000,-2000,3000,-3000,4000,-4000};
        short[] raised=SampleRenderMath.render(input,2,8000,12,0,0,0,0);
        short[] lowered=SampleRenderMath.render(input,2,8000,-12,0,0,0,0);
        assertEquals(2,raised.length/2);
        assertEquals(8,lowered.length/2);
        assertEquals(1000,raised[0]);assertEquals(-1000,raised[1]);
    }

    @Test public void fadesReduceTheClipEdges(){
        short[] input={10000,10000,10000,10000,10000,10000};
        short[] rendered=SampleRenderMath.render(input,1,1000,0,3,2,0,0);
        assertEquals(0,rendered[0]);
        assertTrue(rendered[1]>0&&rendered[1]<rendered[2]);
        assertTrue(rendered[4]>0&&rendered[4]<rendered[3]);
    }

    @Test public void echoAddsAudibleRepeatsAndASeparateTail(){
        short[] rendered=SampleRenderMath.render(new short[]{12000},1,8000,0,0,0,1,.5f);
        assertEquals(25,rendered.length);
        assertTrue(rendered[8]>0);
        assertTrue(rendered[16]>0&&rendered[16]<rendered[8]);
    }

    @Test public void rejectsIncompleteInterleavedFrames(){
        try{SampleRenderMath.render(new short[]{1},2,44100,0,0,0,0,0);fail("expected invalid PCM to fail");}
        catch(IllegalArgumentException expected){assertEquals("PCM must contain complete frames",expected.getMessage());}
    }
}
