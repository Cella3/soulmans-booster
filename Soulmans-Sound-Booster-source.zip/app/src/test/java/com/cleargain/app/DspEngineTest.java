package com.cleargain.app;
import org.junit.Test;
import static org.junit.Assert.*;
public class DspEngineTest {
    private double level(float boost,int[] bands,boolean eq,int frequency){
        DspEngine d=new DspEngine();d.configure(48000,2,boost,bands,eq);double energy=0;
        for(int i=0;i<48000;i++){float y=d.process((float)(.02*Math.sin(2*Math.PI*frequency*i/48000)),0);if(i>=24000)energy+=y*y;assertTrue(Float.isFinite(y));assertTrue(Math.abs(y)<=1);}
        return Math.sqrt(energy/24000);
    }
    @Test public void boostProducesExpectedGainOnQuietAudio(){double dry=level(0,new int[7],false,1000),boost=level(6,new int[7],false,1000);assertEquals(Math.pow(10,6/20.0),boost/dry,.005);}
    @Test public void centerBandActuallyChangesFrequencyResponse(){int[] b={0,0,0,6,0,0,0};assertEquals(2,level(0,b,true,1000)/level(0,b,false,1000),.03);}
    @Test public void limiterContainsMaximumBoostAndEq(){DspEngine d=new DspEngine();d.configure(44100,2,12,new int[]{6,6,6,6,6,6,6},true);for(int i=0;i<100000;i++){float y=d.process((float)Math.sin(i*.12),i%2);assertTrue(Float.isFinite(y));assertTrue(Math.abs(y)<=1);}}
    @Test public void stereoChannelsDoNotLeak(){DspEngine d=new DspEngine();d.configure(48000,2,6,new int[]{3,2,1,0,1,2,3},true);for(int i=0;i<1000;i++){d.process(.2f,0);assertEquals(0,d.process(0,1),0);}}
}
