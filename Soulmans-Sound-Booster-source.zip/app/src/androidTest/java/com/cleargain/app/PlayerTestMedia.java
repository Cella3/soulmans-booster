package com.cleargain.app;
import android.content.Context;
import android.media.*;
import android.os.SystemClock;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.Arrays;
import static org.junit.Assert.*;
final class PlayerTestMedia {
    static File aac(Context context)throws Exception{
        File file=new File(context.getFilesDir(),"Golden Hour Groove.m4a");int rate=44100,frames=0,total=rate*12,track=-1;boolean inputDone=false,done=false;MediaCodec codec=MediaCodec.createEncoderByType("audio/mp4a-latm");MediaMuxer muxer=new MediaMuxer(file.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        try{MediaFormat format=MediaFormat.createAudioFormat("audio/mp4a-latm",rate,2);format.setInteger(MediaFormat.KEY_AAC_PROFILE,MediaCodecInfo.CodecProfileLevel.AACObjectLC);format.setInteger(MediaFormat.KEY_BIT_RATE,128000);codec.configure(format,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE);codec.start();MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();long deadline=SystemClock.elapsedRealtime()+30000;
            while(!done&&SystemClock.elapsedRealtime()<deadline){
                if(!inputDone){int in=codec.dequeueInputBuffer(1000);if(in>=0){ByteBuffer bytes=codec.getInputBuffer(in);bytes.clear();bytes.order(java.nio.ByteOrder.LITTLE_ENDIAN);if(frames>=total){codec.queueInputBuffer(in,0,0,frames*1000000L/rate,MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputDone=true;}else{int n=Math.min(Math.min(1024,bytes.remaining()/4),total-frames);for(int i=0;i<n;i++){int f=frames+i;double beat=(f%(rate*60/128))/(double)rate;short v=(short)((.16*Math.sin(f*2*Math.PI*330/rate)+.25*Math.sin(f*2*Math.PI*140/rate)*Math.exp(-beat/.008))*32767);bytes.putShort(v);bytes.putShort(v);}codec.queueInputBuffer(in,0,n*4,frames*1000000L/rate,0);frames+=n;}}}
                int out=codec.dequeueOutputBuffer(info,1000);if(out==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){track=muxer.addTrack(codec.getOutputFormat());muxer.start();}else if(out>=0){if(info.size>0&&(info.flags&MediaCodec.BUFFER_FLAG_CODEC_CONFIG)==0){ByteBuffer bytes=codec.getOutputBuffer(out);bytes.position(info.offset);bytes.limit(info.offset+info.size);muxer.writeSampleData(track,bytes,info);}done=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;codec.releaseOutputBuffer(out,false);}
            }assertTrue(done);muxer.stop();
        }finally{codec.release();muxer.release();}return file;
    }
    static File videoWithAudio(Context context)throws Exception{
        File video=video(context),audio=aac(context),file=new File(context.getFilesDir(),"Neon Motion with sound.mp4");MediaExtractor v=new MediaExtractor(),a=new MediaExtractor();MediaMuxer muxer=new MediaMuxer(file.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        try{v.setDataSource(video.getAbsolutePath());a.setDataSource(audio.getAbsolutePath());v.selectTrack(0);a.selectTrack(0);int vi=muxer.addTrack(v.getTrackFormat(0)),ai=muxer.addTrack(a.getTrackFormat(0));muxer.start();ByteBuffer bytes=ByteBuffer.allocate(262144);MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();boolean vd=false,ad=false;
            while(!vd||!ad){MediaExtractor chosen;int target;if(ad||(!vd&&v.getSampleTime()<=a.getSampleTime())){chosen=v;target=vi;}else{chosen=a;target=ai;}bytes.clear();int size=chosen.readSampleData(bytes,0);if(size<0){if(chosen==v)vd=true;else ad=true;continue;}info.set(0,size,chosen.getSampleTime(),chosen.getSampleFlags());muxer.writeSampleData(target,bytes,info);chosen.advance();}muxer.stop();
        }finally{v.release();a.release();muxer.release();}return file;
    }
    static File audio(Context context,String name,int bpm,double frequency)throws Exception{
        File file=new File(context.getFilesDir(),name+".wav");int rate=44100;short[] data=new short[rate*2];
        try(PcmWaveWriter writer=new PcmWaveWriter(file,rate,2)){for(int second=0;second<24;second++){for(int i=0;i<rate;i++){int frame=second*rate+i;double pulse=(frame%(rate*60/bpm))/(double)rate;double wave=.16*Math.sin(frame*2*Math.PI*frequency/rate)+.25*Math.sin(frame*2*Math.PI*140/rate)*Math.exp(-pulse/.008);short v=(short)(wave*32767);data[i*2]=v;data[i*2+1]=v;}writer.write(data,data.length);}}return file;
    }
    static File video(Context context) throws Exception {
        File file = new File(context.getFilesDir(), "Neon Motion.mp4"); int width = 320, height = 192, frames = 180;
        MediaCodec codec = MediaCodec.createEncoderByType("video/avc"); MediaMuxer muxer = null;
        try {
            int color = 0; for (int supported : codec.getCodecInfo().getCapabilitiesForType("video/avc").colorFormats) if (supported == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar || supported == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar) { color = supported; break; }
            assertTrue("A test AVC encoder with byte-buffer input is required", color != 0);
            MediaFormat format = MediaFormat.createVideoFormat("video/avc", width, height); format.setInteger(MediaFormat.KEY_COLOR_FORMAT, color); format.setInteger(MediaFormat.KEY_BIT_RATE, 500000); format.setInteger(MediaFormat.KEY_FRAME_RATE, 15); format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); codec.start();
            muxer = new MediaMuxer(file.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            byte[] yuv = new byte[width * height * 3 / 2]; int index = 0, track = -1; boolean endQueued = false, done = false; long deadline = SystemClock.elapsedRealtime() + 30000;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            while (!done && SystemClock.elapsedRealtime() < deadline) {
                if (!endQueued) {
                    int input = codec.dequeueInputBuffer(1000);
                    if (input >= 0) {
                        ByteBuffer bytes = codec.getInputBuffer(input); assertNotNull(bytes); bytes.clear();
                        if (index == frames) { codec.queueInputBuffer(input, 0, 0, index * 1000000L / 15, MediaCodec.BUFFER_FLAG_END_OF_STREAM); endQueued = true; }
                        else {
                            for (int y = 0; y < height; y++) for (int x = 0; x < width; x++) yuv[y * width + x] = (byte) ((x + index * 3) % width < width / 3 ? 155 : x < width * 2 / 3 ? 88 : 55);
                            if (color == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar) { Arrays.fill(yuv, width * height, width * height * 5 / 4, (byte) 160); Arrays.fill(yuv, width * height * 5 / 4, yuv.length, (byte) 80); }
                            else for (int p = width * height; p < yuv.length; p += 2) { yuv[p] = (byte) 160; yuv[p + 1] = (byte) 80; }
                            bytes.put(yuv); codec.queueInputBuffer(input, 0, yuv.length, index++ * 1000000L / 15, 0);
                        }
                    }
                }
                int output = codec.dequeueOutputBuffer(info, 1000);
                if (output == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { track = muxer.addTrack(codec.getOutputFormat()); muxer.start(); }
                else if (output >= 0) {
                    ByteBuffer bytes = codec.getOutputBuffer(output);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && info.size > 0) { assertTrue(track >= 0); bytes.position(info.offset); bytes.limit(info.offset + info.size); muxer.writeSampleData(track, bytes, info); }
                    done = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0; codec.releaseOutputBuffer(output, false);
                }
            } assertTrue("Synthetic video encoder finished", done); muxer.stop();
        } finally { codec.release(); if (muxer != null) muxer.release(); }
        return file;
    }
}
