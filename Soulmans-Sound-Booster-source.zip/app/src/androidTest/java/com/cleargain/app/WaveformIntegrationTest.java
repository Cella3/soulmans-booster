package com.cleargain.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;
import androidx.media3.common.Player;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.atomic.AtomicBoolean;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Real seeks and view-only panning on an isolated emulator with synthetic WAV audio. */
@RunWith(AndroidJUnit4.class)
public final class WaveformIntegrationTest {
    private final Instrumentation test = InstrumentationRegistry.getInstrumentation();
    private Activity activity;
    private Context context;
    private void main(Runnable action) { test.runOnMainSync(action); }
    private interface Check { boolean ok(); }
    private void await(Check check) {
        long end = SystemClock.elapsedRealtime() + 30000;
        while (SystemClock.elapsedRealtime() < end) {
            AtomicBoolean result = new AtomicBoolean(); main(() -> result.set(check.ok()));
            if (result.get()) return; SystemClock.sleep(100);
        }
        fail("Timed out waiting for the waveform");
    }
    @Test public void songAndSamplerZoomPanWithoutChangingPlaybackOrTrimAndSeekVisibleRange() throws Exception {
        assertTrue("Run on an isolated Android emulator", Build.FINGERPRINT.contains("generic") || Build.MODEL.startsWith("sdk"));
        context = test.getTargetContext();
        context.getSharedPreferences("settings", 0).edit().putBoolean("auto_visuals", false).putBoolean("rack_full_waveform",false).putBoolean("rack_full_sampler",false).apply();
        Track track = MusicStore.get(context).importTrack(Uri.fromFile(wave()));
        activity = test.startActivitySync(new Intent(context, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK).putExtra("open_tab", 0));
        try {
            await(() -> PlaybackService.live != null);
            main(()->find(activity.getWindow().getDecorView(),"Expand WAVEFORM / ZOOM & PAN module").performClick());
            main(() -> { Player player = PlaybackService.live.player; player.setMediaItem(track.item()); player.prepare(); player.pause(); player.seekTo(90000); });
            await(() -> PlaybackService.live.player.getPlaybackState() == Player.STATE_READY
                    && waveform() != null && waveform().viewport().available() && waveform().getWidth() > 0);
            main(() -> {
                WaveformView wave = waveform();
                WaveformControls.PanSlider pan = (WaveformControls.PanSlider) find(activity.getWindow().getDecorView(), "Waveform pan");
                assertFalse("Full song has no pan range", pan.isEnabled());
                find(activity.getWindow().getDecorView(), "Zoom waveform in").performClick();
                find(activity.getWindow().getDecorView(), "Zoom waveform in").performClick();
                assertTrue(pan.isEnabled()); dragToEnd(pan);
                assertEquals("Panning must leave playback at its original position", 90000, PlaybackService.live.player.getCurrentPosition(), 250);
                assertEquals(1, wave.viewport().end(), .001); tap(wave, .5f);
            });
            await(() -> Math.abs(PlaybackService.live.player.getCurrentPosition() - 157500) < 1000);
            main(() -> {
                find(activity.getWindow().getDecorView(), "Default waveform view").performClick();
                assertEquals(30000, waveform().viewport().span() * 180000, 100); scrollTo(waveform());
            });
            SystemClock.sleep(200); screenshot("waveform-zoom-player.png");
            main(() -> {
                find(activity.getWindow().getDecorView(), "Show full waveform").performClick();
                assertEquals(1, waveform().viewport().span(), .001);
                assertFalse(find(activity.getWindow().getDecorView(), "Waveform pan").isEnabled());
            });
            context.getSharedPreferences("settings", 0).edit().putString("pad_uri_0", track.uri)
                    .putString("pad_name_0", "Waveform test sample").putInt("pad_duration_0", 180000)
                    .putInt("pad_start_0", 50000).putInt("pad_end_0", 110000).apply();
            main(()->find(activity.getWindow().getDecorView(),"Expand MPC SAMPLER & RECORDER module").performClick());
            await(() -> findPad(activity.getWindow().getDecorView()) != null);
            main(() -> findPad(activity.getWindow().getDecorView()).performLongClick());
            await(() -> editor() != null && editor().isShowing()
                    && sample(editor().getWindow().getDecorView()) != null && sample(editor().getWindow().getDecorView()).viewport().available());
            main(() -> {
                View root = editor().getWindow().getDecorView(); SampleWaveformView wave = sample(root);
                find(root, "Default waveform view").performClick();
                assertEquals(30000, wave.viewport().span() * 180000, 100);
                dragToEnd((WaveformControls.PanSlider) find(root, "Waveform pan"));
                assertEquals(1, wave.viewport().end(), .001);
                find(root, "Default waveform view").performClick(); scrollTo(wave);
            });
            SystemClock.sleep(200); screenshot("waveform-zoom-sampler.png");
            main(() -> {
                find(editor().getWindow().getDecorView(), "Show full waveform").performClick();
                editor().getButton(AlertDialog.BUTTON_NEGATIVE).performClick();
            });
            assertEquals("Panning must not alter the sample IN point", 50000, context.getSharedPreferences("settings", 0).getInt("pad_start_0", -1));
            assertEquals("Panning must not alter the sample OUT point", 110000, context.getSharedPreferences("settings", 0).getInt("pad_end_0", -1));
        } finally {
            main(() -> { if (PlaybackService.live != null) PlaybackService.live.player.pause(); if (activity != null) activity.finish(); });
        }
    }
    private WaveformView waveform() { return typed(activity.getWindow().getDecorView(), WaveformView.class); }
    private SampleWaveformView sample(View root) { return typed(root, SampleWaveformView.class); }
    private <T extends View> T typed(View root, Class<T> type) {
        if (type.isInstance(root)) return type.cast(root);
        if (root instanceof ViewGroup) for (int i = 0; i < ((ViewGroup) root).getChildCount(); i++) {
            T found = typed(((ViewGroup) root).getChildAt(i), type); if (found != null) return found;
        }
        return null;
    }
    private View find(View root, String description) {
        if (description.contentEquals(root.getContentDescription() == null ? "" : root.getContentDescription())) return root;
        if (root instanceof ViewGroup) for (int i = 0; i < ((ViewGroup) root).getChildCount(); i++) {
            View found = find(((ViewGroup) root).getChildAt(i), description); if (found != null) return found;
        }
        return null;
    }
    private View findPad(View root) {
        CharSequence description = root.getContentDescription();
        if (description != null && description.toString().startsWith("Sampler pad 1, Waveform test sample")) return root;
        if (root instanceof ViewGroup) for (int i = 0; i < ((ViewGroup) root).getChildCount(); i++) {
            View found = findPad(((ViewGroup) root).getChildAt(i)); if (found != null) return found;
        }
        return null;
    }
    private AlertDialog editor() {
        try { Field field = MainActivity.class.getDeclaredField("padEditor"); field.setAccessible(true); return (AlertDialog) field.get(activity); }
        catch (Exception error) { throw new AssertionError(error); }
    }
    private void tap(View view, float fraction) {
        long now = SystemClock.uptimeMillis(); float x = view.getWidth() * fraction, y = view.getHeight() / 2f;
        event(view, now, now, MotionEvent.ACTION_DOWN, x, y); event(view, now, now + 50, MotionEvent.ACTION_UP, x, y);
    }
    private void dragToEnd(View view) {
        long now = SystemClock.uptimeMillis(); float x = view.getWidth() / 2f, y = view.getHeight() / 2f;
        event(view, now, now, MotionEvent.ACTION_DOWN, x, y);
        event(view, now, now + 50, MotionEvent.ACTION_MOVE, view.getWidth(), y);
        event(view, now, now + 100, MotionEvent.ACTION_UP, view.getWidth(), y);
    }
    private void event(View view, long down, long time, int action, float x, float y) {
        MotionEvent event = MotionEvent.obtain(down, time, action, x, y, 0); view.dispatchTouchEvent(event); event.recycle();
    }
    private void scrollTo(View view) {
        View parent = view;
        while (parent.getParent() instanceof View) {
            parent = (View) parent.getParent();
            if (parent instanceof ScrollView) {
                ((ScrollView) parent).scrollTo(0, Math.max(0, view.getTop() - Math.round(18 * context.getResources().getDisplayMetrics().density))); return;
            }
        }
    }
    private void screenshot(String name) throws Exception {
        Bitmap image = test.getUiAutomation().takeScreenshot();
        try (FileOutputStream out = new FileOutputStream(new File(context.getFilesDir(), name))) { image.compress(Bitmap.CompressFormat.PNG, 100, out); }
        image.recycle();
    }
    private File wave() throws Exception {
        int rate = 8000, frames = rate * 180;
        ByteBuffer buffer = ByteBuffer.allocate(44 + frames * 2).order(ByteOrder.LITTLE_ENDIAN);
        buffer.put("RIFF".getBytes("US-ASCII")).putInt(36 + frames * 2).put("WAVEfmt ".getBytes("US-ASCII")).putInt(16)
                .putShort((short) 1).putShort((short) 1).putInt(rate).putInt(rate * 2).putShort((short) 2).putShort((short) 16)
                .put("data".getBytes("US-ASCII")).putInt(frames * 2);
        for (int i = 0; i < frames; i++) buffer.putShort((short) (Math.sin(2 * Math.PI * 220 * i / rate) * (4000 + 15000 * ((i / rate) % 20) / 20.0)));
        File file = new File(context.getFilesDir(), "Waveform zoom test.wav");
        try (FileOutputStream out = new FileOutputStream(file)) { out.write(buffer.array()); } return file;
    }
}
