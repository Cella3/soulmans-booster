package com.cleargain.app;

import android.content.*;
import android.net.Uri;
import android.os.SystemClock;
import android.app.Instrumentation;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;
import androidx.media3.common.*;
import androidx.media3.session.*;
import java.io.*;
import java.nio.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** Real Android decoding, service, DSP, storage and mixing checks. Only synthetic audio is used. */
@RunWith(AndroidJUnit4.class)
public class PlayerIntegrationTest {
    private Instrumentation getInstrumentation(){return InstrumentationRegistry.getInstrumentation();}
    private Context c;private MediaController controller;private MusicStore store;
    private Track a,b;
    @Before public void setUp() throws Exception {
        c=getInstrumentation().getTargetContext();store=MusicStore.get(c);
        a=store.importTrack(Uri.fromFile(wave("Test pulse.wav",220)));b=store.importTrack(Uri.fromFile(wave("Test shimmer.wav",660)));
        AtomicReference<com.google.common.util.concurrent.ListenableFuture<MediaController>> ref=new AtomicReference<>();
        main(()->ref.set(new MediaController.Builder(c,new SessionToken(c,new ComponentName(c,PlaybackService.class))).buildAsync()));
        controller=ref.get().get(15,TimeUnit.SECONDS);
    }
    private File wave(String name,int frequency) throws Exception {
        File f=new File(c.getFilesDir(),name);int rate=44100,samples=rate*35;ByteBuffer b=ByteBuffer.allocate(44+samples*2).order(ByteOrder.LITTLE_ENDIAN);
        b.put("RIFF".getBytes("US-ASCII")).putInt(36+samples*2).put("WAVEfmt ".getBytes("US-ASCII")).putInt(16).putShort((short)1).putShort((short)1).putInt(rate).putInt(rate*2).putShort((short)2).putShort((short)16).put("data".getBytes("US-ASCII")).putInt(samples*2);
        for(int i=0;i<samples;i++)b.putShort((short)(Math.sin(2*Math.PI*frequency*i/rate)*2500));try(FileOutputStream out=new FileOutputStream(f)){out.write(b.array());}return f;
    }
    private void main(Runnable r) throws Exception {getInstrumentation().runOnMainSync(r);}
    interface Check{boolean ok();}
    private void await(Check check) throws Exception {long end=SystemClock.elapsedRealtime()+15000;while(SystemClock.elapsedRealtime()<end){AtomicBoolean good=new AtomicBoolean();main(()->good.set(check.ok()));if(good.get())return;SystemClock.sleep(100);}fail("Timed out waiting for playback state");}
    @Test public void testPlaybackMixPersistenceAndFailureRecovery() throws Exception {
        long list=store.createPlaylist("Integration playlist",Arrays.asList(a.uri,b.uri));assertEquals(2,store.playlist(list).size());
        main(()->{controller.setMediaItems(Arrays.asList(a.item(),b.item()));controller.prepare();controller.play();});await(()->controller.isPlaying()&&controller.getCurrentPosition()>700);
        await(()->PlaybackService.live.processor.capturedAt>0);
        AtomicReference<float[]> bars=new AtomicReference<>();main(()->bars.set(PlaybackService.live.processor.spectrum));float max=0;for(float v:bars.get())max=Math.max(max,v);assertTrue("Visualizer must contain real audio energy",max>.03);
        main(()->{PlaybackService.live.pitch(5);controller.seekTo(12000);});await(()->controller.getCurrentPosition()>=12000);assertEquals(5f,store.track(a.uri).pitch,0.001f);
        c.getSharedPreferences("settings",0).edit().putBoolean("player_boost",true).putInt("gain_db",6).putBoolean("player_eq",true).apply();
        main(()->{PlaybackService.live.applySound();for(int i=0;i<4;i++){c.getSharedPreferences("settings",0).edit().putString("pad_uri_"+i,b.uri).putString("pad_name_"+i,"Test sample "+(i+1)).apply();PlaybackService.live.triggerPad(i);}});
        await(()->PlaybackService.live.padPlaying(0)&&PlaybackService.live.padPlaying(1)&&PlaybackService.live.padPlaying(2)&&PlaybackService.live.padPlaying(3));
        main(()->assertTrue("Samples must not pause music",controller.isPlaying()));
        main(()->{controller.pause();PlaybackService.live.saveQueue();});await(()->!PlaybackService.live.padPlaying(0)&&!PlaybackService.live.padPlaying(3));
        assertTrue(store.history().size()>0);assertTrue(store.track(a.uri).plays>0);assertEquals(2,new org.json.JSONArray(c.getSharedPreferences("settings",0).getString("queue","[]")).length());
        main(()->{controller.seekToNextMediaItem();controller.play();});await(()->controller.isPlaying()&&controller.getCurrentMediaItem().mediaId.equals(b.uri));
        main(()->assertEquals("Next track restores its own pitch",1f,controller.getPlaybackParameters().pitch,.001f));
        main(()->{controller.setMediaItem(MediaItem.fromUri("file:///does-not-exist.wav"));controller.prepare();controller.play();});await(()->controller.getPlayerError()!=null);
        main(()->{controller.setMediaItems(Arrays.asList(a.item(),b.item()));controller.prepare();controller.play();});await(()->controller.isPlaying());
        store.removePlaylistEntry(list,0);assertEquals(b.uri,store.playlist(list).get(0).uri);store.deletePlaylist(list);assertFalse(store.playlists().containsKey(list));
        main(()->{controller.pause();controller.seekTo(8000);PlaybackService.live.saveQueue();});
        store.createPlaylist("Emulator test mix",Arrays.asList(a.uri,b.uri));
    }
    @After public void tearDown() throws Exception {if(controller!=null)main(()->controller.release());}
}
