package com.cleargain.app;

import android.app.*;
import android.content.*;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.*;
import android.view.*;
import androidx.media3.common.*;
import androidx.media3.ui.PlayerView;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.atomic.*;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

@RunWith(AndroidJUnit4.class)
public final class PlayerUpgradeIntegrationTest {
    final Instrumentation test=InstrumentationRegistry.getInstrumentation();Context context;Activity activity;
    interface Check{boolean okay()throws Exception;}
    void main(Runnable action){test.runOnMainSync(action);}
    void await(Check check)throws Exception{long end=SystemClock.elapsedRealtime()+30000;while(SystemClock.elapsedRealtime()<end){AtomicBoolean yes=new AtomicBoolean();AtomicReference<Exception> error=new AtomicReference<>();main(()->{try{yes.set(check.okay());}catch(Exception e){error.set(e);}});if(error.get()!=null)throw error.get();if(yes.get())return;SystemClock.sleep(100);}fail("Timed out waiting for upgraded player");}
    @Before public void setup(){assertTrue(Build.FINGERPRINT.contains("generic")||Build.MODEL.startsWith("sdk"));context=test.getTargetContext();context.getSharedPreferences("settings",0).edit().putBoolean("auto_visuals",false).putBoolean("player_boost",false).putBoolean("player_eq",false).apply();}
    @Test public void launcherPortraitFillsAdaptiveIconAndRemainsTransparent()throws Exception{
        android.graphics.drawable.Drawable icon=context.getPackageManager().getApplicationIcon(context.getPackageName());assertTrue(icon instanceof android.graphics.drawable.AdaptiveIconDrawable);
        Bitmap image=Bitmap.createBitmap(256,256,Bitmap.Config.ARGB_8888);icon.setBounds(0,0,256,256);icon.draw(new android.graphics.Canvas(image));int visible=0;for(int y=0;y<256;y++)for(int x=0;x<256;x++)if(android.graphics.Color.alpha(image.getPixel(x,y))>128)visible++;assertTrue("Portrait fills most of the launcher mask",visible>256*256*.5);assertEquals(0,android.graphics.Color.alpha(image.getPixel(0,0)));
        try(FileOutputStream out=new FileOutputStream(new File(context.getFilesDir(),"Soulmans-Launcher-v10.png"))){image.compress(Bitmap.CompressFormat.PNG,100,out);}image.recycle();
    }
    @Test public void importedSelectionPlaysImmediatelyAndModulesRemainCollapsible()throws Exception{
        activity=test.startActivitySync(new Intent(context,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK));await(()->PlaybackService.live!=null);
        File source=PlayerTestMedia.audio(context,"Autoplay proof",120,220);Method importFiles=MainActivity.class.getDeclaredMethod("importFiles",List.class,boolean.class);importFiles.setAccessible(true);
        main(()->{try{importFiles.invoke(activity,Collections.singletonList(Uri.fromFile(source)),false);}catch(Exception e){throw new RuntimeException(e);}});
        await(()->PlaybackService.live.player.isPlaying()&&PlaybackService.live.player.getCurrentMediaItem().mediaId.equals(Uri.fromFile(source).toString()));
        main(()->{View module=find(activity.getWindow().getDecorView(),"Expand EQ & BOOST module");if(module==null)module=find(activity.getWindow().getDecorView(),"Collapse EQ & BOOST module");assertNotNull(module);module.performClick();});
    }
    @Test public void videoPinchPanDoubleTapRotationColorAndSpeedKeepRealPicture()throws Exception{
        Track track=MusicStore.get(context).importTrack(Uri.fromFile(PlayerTestMedia.videoWithAudio(context)));activity=test.startActivitySync(new Intent(context,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK));await(()->PlaybackService.live!=null);
        main(()->{PlaybackService.live.player.setMediaItem(track.item());PlaybackService.live.player.prepare();PlaybackService.live.player.setRepeatMode(Player.REPEAT_MODE_ONE);PlaybackService.live.player.play();});
        AtomicReference<PlayerView> inline=new AtomicReference<>();await(()->{inline.set(findVideo(activity.getWindow().getDecorView()));return inline.get()!=null&&inline.get().isShown()&&picture(inline.get());});
        VideoGestureOverlay gesture=findGesture(inline.get());assertNotNull(gesture);main(()->pinch(gesture));assertTrue(gesture.zoom()>1.4);
        main(()->{long t=SystemClock.uptimeMillis();event(gesture,t,t,MotionEvent.ACTION_DOWN,100,80);event(gesture,t,t+30,MotionEvent.ACTION_MOVE,170,110);event(gesture,t,t+60,MotionEvent.ACTION_UP,170,110);assertEquals(1,gesture.getScaleX(),0);assertTrue(Math.abs(gesture.panX())>0);});
        Instrumentation.ActivityMonitor monitor=test.addMonitor(VideoPlayerActivity.class.getName(),null,false);main(()->doubleTap(gesture));Activity fullscreen=test.waitForMonitorWithTimeout(monitor,8000);test.removeMonitor(monitor);assertNotNull("Double tap opens fullscreen",fullscreen);activity=fullscreen;VideoPlayerActivity screen=(VideoPlayerActivity)fullscreen;
        await(()->picture(screen.video));assertTrue(screen.gestures.zoom()>1.4);
        main(()->screen.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE));await(()->screen.video.getWidth()>screen.video.getHeight()&&picture(screen.video));
        main(()->screen.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT));await(()->screen.video.getHeight()>screen.video.getWidth()&&picture(screen.video));
        main(()->{screen.gestures.resetZoom();screen.video.hideController();context.getSharedPreferences("settings",0).edit().putInt("video_saturation_"+VideoClipPrefs.key(track.uri),-100).apply();PlaybackService.live.applyVideoEffects();});
        await(()->{Bitmap frame=test.getUiAutomation().takeScreenshot();if(frame==null)return false;View surface=screen.video.getVideoSurfaceView();int[] location=new int[2];surface.getLocationOnScreen(location);int color=frame.getPixel(Math.min(frame.getWidth()-1,location[0]+surface.getWidth()/2),Math.min(frame.getHeight()-1,location[1]+surface.getHeight()/2));frame.recycle();return Math.abs(android.graphics.Color.red(color)-android.graphics.Color.green(color))<12&&android.graphics.Color.red(color)>12;});
        main(()->PlaybackService.live.speed(.25f));await(()->Math.abs(PlaybackService.live.player.getPlaybackParameters().speed-.25)<.01);
        main(()->PlaybackService.live.speed(50));await(()->Math.abs(PlaybackService.live.player.getPlaybackParameters().speed-50)<.01&&PlaybackService.live.player.isPlaying());
        main(()->{PlaybackService.live.speed(1);screen.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);});await(()->picture(screen.video));screenshot("Soulmans-Video-v10.png");
        main(()->context.getSharedPreferences("settings",0).edit().remove("video_saturation_"+VideoClipPrefs.key(track.uri)).apply());
    }
    @Test public void djDecodesMixesScratchesSyncsAndShowsTwoDecks()throws Exception{
        Track a=MusicStore.get(context).importTrack(Uri.fromFile(PlayerTestMedia.audio(context,"Aurora Club Mix",120,220))),b=MusicStore.get(context).importTrack(Uri.fromFile(PlayerTestMedia.aac(context)));
        try(DjEngine engine=new DjEngine()){
            engine.load(0,a,DjDecoder.decode(context,a.uri,()->false,0),120);engine.load(1,b,DjDecoder.decode(context,b.uri,()->false,0),128);engine.toggle(0);engine.toggle(1);engine.crossfade(0);float[] audio=new float[2048];engine.render(audio);assertTrue(energy(audio)>.001);assertTrue(engine.state(0).seconds()>0);engine.seek(0,8);engine.scratchBegin(0);engine.scratchMove(0,-.2);engine.render(audio);assertTrue("Scratch moves backward through PCM",engine.state(0).seconds()<8);assertTrue("Reverse scratch produces audio",energy(audio)>.001);engine.scratchEnd(0);assertTrue(engine.sync(0,false,0,0));assertEquals(128,engine.state(0).bpm()*engine.state(0).rate(),.01);engine.loop(0,2,2.1,true);engine.seek(0,2.099);engine.render(audio);assertTrue(engine.state(0).seconds()<2.1);engine.cue(0,0,true);double cue=engine.cueTime(0,0);engine.seek(0,9);engine.cue(0,0,false);assertEquals(cue,engine.state(0).seconds(),.001);
            engine.pause();engine.crossfade(1);engine.volume(1,0);engine.render(audio);assertEquals(0,energy(audio),.000001);
        }
        activity=test.startActivitySync(new Intent(context,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TASK));await(()->PlaybackService.live!=null);main(()->PlaybackService.live.player.pause());
        activity=test.startActivitySync(new Intent(context,DjActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));await(()->DjService.live!=null);main(()->{DjService.live.load(0,a);DjService.live.load(1,b);});await(()->DjService.live.engine.state(0).loaded()&&DjService.live.engine.state(1).loaded());
        main(()->{DjService.live.engine.bpm(0,120);DjService.live.engine.bpm(1,128);DjService.live.toggle(0);DjService.live.toggle(1);});await(()->DjService.live.engine.state(0).seconds()>1&&DjService.live.engine.state(1).seconds()>1&&DjService.live.engine.renderedFrames>44100);assertEquals(2,count(activity.getWindow().getDecorView(),DjPlatterView.class));screenshot("Soulmans-DJ-v10.png");
        context.getSharedPreferences("settings",0).edit().putString("dj_queue","[]").apply();main(()->find(activity.getWindow().getDecorView(),"LIBRARY / QUEUE ▴").performClick());test.waitForIdleSync();
        Field library= DjActivity.class.getDeclaredField("libraryRows"),queue= DjActivity.class.getDeclaredField("queueRows");library.setAccessible(true);queue.setAccessible(true);AtomicReference<View> source=new AtomicReference<>(),destination=new AtomicReference<>();main(()->{try{ViewGroup rows=(ViewGroup)library.get(activity);for(int i=0;i<rows.getChildCount();i++)if(String.valueOf(rows.getChildAt(i).getContentDescription()).startsWith(a.title))source.set(rows.getChildAt(i));destination.set((View)queue.get(activity));}catch(Exception e){throw new RuntimeException(e);}});assertNotNull(source.get());await(()->source.get().isShown()&&source.get().getWidth()>0&&destination.get().getWidth()>0);test.waitForIdleSync();int[] from=new int[2],to=new int[2];main(()->{source.get().getLocationOnScreen(from);destination.get().getLocationOnScreen(to);});long t=SystemClock.uptimeMillis();inject(t,t,MotionEvent.ACTION_DOWN,from[0]+30,from[1]+20);main(()->assertTrue(source.get().performLongClick()));test.waitForIdleSync();inject(t,t+50,MotionEvent.ACTION_MOVE,to[0]+40,to[1]+40);inject(t,t+100,MotionEvent.ACTION_UP,to[0]+40,to[1]+40);await(()->queued(a.uri));screenshot("Soulmans-DJ-Queue-v10.png");
    }
    boolean queued(String uri)throws Exception{org.json.JSONArray q=new org.json.JSONArray(context.getSharedPreferences("settings",0).getString("dj_queue","[]"));for(int i=0;i<q.length();i++)if(uri.equals(q.getString(i)))return true;return false;}
    double energy(float[] x){double sum=0;for(float sample:x)sum+=sample*sample;return sum/x.length;}
    void screenshot(String name)throws Exception{Bitmap b=test.getUiAutomation().takeScreenshot();assertNotNull(b);try(FileOutputStream out=new FileOutputStream(new File(context.getFilesDir(),name))){b.compress(Bitmap.CompressFormat.PNG,100,out);}b.recycle();}
    boolean picture(PlayerView v){if(!(v.getVideoSurfaceView() instanceof TextureView))return false;Bitmap b=((TextureView)v.getVideoSurfaceView()).getBitmap(16,16);if(b==null)return false;long light=0;for(int y=2;y<14;y++)for(int x=2;x<14;x++){int c=b.getPixel(x,y);light+=android.graphics.Color.red(c)+android.graphics.Color.green(c)+android.graphics.Color.blue(c);}b.recycle();return light>1000;}
    View find(View v,String description){if(description.equals(String.valueOf(v.getContentDescription())))return v;if(v instanceof ViewGroup)for(int i=0;i<((ViewGroup)v).getChildCount();i++){View found=find(((ViewGroup)v).getChildAt(i),description);if(found!=null)return found;}return null;}
    PlayerView findVideo(View v){if(v instanceof PlayerView)return (PlayerView)v;if(v instanceof ViewGroup)for(int i=0;i<((ViewGroup)v).getChildCount();i++){PlayerView found=findVideo(((ViewGroup)v).getChildAt(i));if(found!=null)return found;}return null;}
    VideoGestureOverlay findGesture(View v){if(v instanceof VideoGestureOverlay)return (VideoGestureOverlay)v;if(v instanceof ViewGroup)for(int i=0;i<((ViewGroup)v).getChildCount();i++){VideoGestureOverlay found=findGesture(((ViewGroup)v).getChildAt(i));if(found!=null)return found;}return null;}
    int count(View v,Class<?> type){int n=type.isInstance(v)?1:0;if(v instanceof ViewGroup)for(int i=0;i<((ViewGroup)v).getChildCount();i++)n+=count(((ViewGroup)v).getChildAt(i),type);return n;}
    void event(View view,long down,long time,int action,float x,float y){MotionEvent e=MotionEvent.obtain(down,time,action,x,y,0);view.dispatchTouchEvent(e);e.recycle();}
    void inject(long down,long time,int action,float x,float y){MotionEvent e=MotionEvent.obtain(down,time,action,x,y,0);e.setSource(InputDevice.SOURCE_TOUCHSCREEN);test.getUiAutomation().injectInputEvent(e,true);e.recycle();}
    void doubleTap(View view){long t=SystemClock.uptimeMillis();event(view,t,t,0,100,80);event(view,t,t+20,1,100,80);event(view,t+100,t+100,0,100,80);event(view,t+100,t+120,1,100,80);}
    void pinch(View view){long t=SystemClock.uptimeMillis();event(view,t,t,0,100,80);MotionEvent.PointerProperties[] ids={new MotionEvent.PointerProperties(),new MotionEvent.PointerProperties()};ids[0].id=0;ids[1].id=1;ids[0].toolType=ids[1].toolType=MotionEvent.TOOL_TYPE_FINGER;MotionEvent.PointerCoords[] xy={new MotionEvent.PointerCoords(),new MotionEvent.PointerCoords()};for(MotionEvent.PointerCoords c:xy){c.pressure=1;c.size=1;c.y=80;}xy[0].x=100;xy[1].x=150;MotionEvent e=MotionEvent.obtain(t,t+10,MotionEvent.ACTION_POINTER_DOWN|(1<<8),2,ids,xy,0,0,1,1,0,0,0,0);view.dispatchTouchEvent(e);e.recycle();for(int i=1;i<=8;i++){xy[0].x=100-i*7;xy[1].x=150+i*7;e=MotionEvent.obtain(t,t+10+i*20,MotionEvent.ACTION_MOVE,2,ids,xy,0,0,1,1,0,0,0,0);view.dispatchTouchEvent(e);e.recycle();}e=MotionEvent.obtain(t,t+200,MotionEvent.ACTION_POINTER_UP|(1<<8),2,ids,xy,0,0,1,1,0,0,0,0);view.dispatchTouchEvent(e);e.recycle();event(view,t,t+210,MotionEvent.ACTION_UP,xy[0].x,80);}
    @After public void finish()throws Exception{main(()->{context.stopService(new Intent(context,DjService.class));FloatingPlayerService.hide(context);if(PlaybackService.live!=null){PlaybackService.live.player.pause();PlaybackService.live.speed(1);PlaybackService.live.player.setRepeatMode(Player.REPEAT_MODE_OFF);}if(activity!=null)activity.finish();});}
}
