package com.cleargain.app;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.*;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import androidx.media3.common.*;
import androidx.media3.ui.PlayerView;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.concurrent.atomic.*;
import org.junit.*;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Isolated emulator only. Generates both music and video; never loads personal media. */
@RunWith(AndroidJUnit4.class)
public final class MiniPlayerIntegrationTest {
    private final Instrumentation test = InstrumentationRegistry.getInstrumentation();
    private Context context;
    private Activity activity;
    private void main(Runnable action) { test.runOnMainSync(action); }
    private interface Check { boolean ok(); }
    private void await(Check check) throws Exception {
        long end = SystemClock.elapsedRealtime() + 15000;
        while (SystemClock.elapsedRealtime() < end) { AtomicBoolean result = new AtomicBoolean(); main(() -> result.set(check.ok())); if (result.get()) return; SystemClock.sleep(100); }
        fail("Timed out waiting for the floating media player");
    }
    @Before public void prepare() throws Exception {
        assertTrue("Use an isolated Android emulator", Build.FINGERPRINT.contains("generic") || Build.MODEL.startsWith("sdk"));
        context = test.getTargetContext();
        try (ParcelFileDescriptor result = test.getUiAutomation().executeShellCommand("appops set " + context.getPackageName() + " SYSTEM_ALERT_WINDOW allow")) {
            try (FileInputStream input = new FileInputStream(result.getFileDescriptor())) { byte[] buffer = new byte[256]; while (input.read(buffer) != -1) {} }
        }
        assertTrue(Settings.canDrawOverlays(context));
        context.getSharedPreferences("settings", 0).edit().putBoolean("auto_visuals", false).remove("mini_width").remove("mini_x").remove("mini_y").apply();
        activity = test.startActivitySync(new Intent(context, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK).putExtra("open_tab", 0));
        await(() -> PlaybackService.live != null);
    }
    private void openMini() throws Exception {
        main(() -> { View button = find(activity.getWindow().getDecorView(), "Open floating mini player"); assertNotNull(button); button.performClick(); });
        await(() -> FloatingPlayerService.live != null && FloatingPlayerService.live.window != null && FloatingPlayerService.live.window.isAttachedToWindow());
        await(() -> find(FloatingPlayerService.live.window, "Pause") != null);
    }
    @Test public void musicWindowMovesResizesSeeksAndPreservesPlaybackAndPlacement() throws Exception {
        Track track = MusicStore.get(context).importTrack(Uri.fromFile(tone()));
        main(() -> { PlaybackService.live.player.setMediaItem(track.item()); PlaybackService.live.player.prepare(); PlaybackService.live.player.play(); });
        await(() -> PlaybackService.live.player.isPlaying() && PlaybackService.live.processor.capturedAt > 0);
        await(() -> { ReelToReelView fullDeck=findReels(activity.getWindow().getDecorView()); return fullDeck!=null && fullDeck.isShown() && fullDeck.leftRotation()>.5; });
        screenshot("gold-reel-full-player.png");
        openMini();
        AtomicReference<ReelToReelView> deck = new AtomicReference<>();
        main(() -> { deck.set(findReels(FloatingPlayerService.live.window)); assertNotNull("Music includes the mechanical reel deck",deck.get()); assertTrue(deck.get().isShown()); });
        AtomicReference<Double> spinning = new AtomicReference<>(); main(() -> spinning.set(deck.get().leftRotation()));
        await(() -> Math.abs(deck.get().leftRotation()-spinning.get())>.5);
        renderWindow("Soulmans-Gold-Reel-Player.png");
        AtomicInteger oldY = new AtomicInteger(), oldWidth = new AtomicInteger();
        main(() -> { oldY.set(FloatingPlayerService.live.windowParams.y); oldWidth.set(FloatingPlayerService.live.windowParams.width); });
        drag("Drag title bar to move the mini player", 10, 90);
        await(() -> FloatingPlayerService.live.windowParams.y > oldY.get());
        drag("Drag corner sideways to resize mini player", -70, 0);
        await(() -> FloatingPlayerService.live.windowParams.width < oldWidth.get());
        SystemClock.sleep(400); screenshot("mini-player-music.png");
        main(() -> { View pause = find(FloatingPlayerService.live.window, "Pause"); assertNotNull(pause); pause.performClick(); });
        await(() -> !PlaybackService.live.player.getPlayWhenReady());
        await(() -> find(FloatingPlayerService.live.window, "Play") != null);
        AtomicReference<Double> stopped = new AtomicReference<>(); main(() -> stopped.set(deck.get().leftRotation()));
        SystemClock.sleep(250); main(() -> assertEquals("Paused reels must stop spinning",stopped.get(),deck.get().leftRotation(),.001));
        main(() -> find(FloatingPlayerService.live.window, "Play").performClick()); await(() -> PlaybackService.live.player.isPlaying());
        tapSeek(); await(() -> PlaybackService.live.player.getCurrentPosition() > 10000);
        await(() -> deck.get().progress()>.4 && deck.get().takeUpRadius()>deck.get().supplyRadius());
        screenshot("gold-reel-mini-player.png");
        main(() -> find(FloatingPlayerService.live.window, "Collapse mini player").performClick());
        await(() -> find(FloatingPlayerService.live.window, "Expand mini player") != null);
        main(() -> { assertTrue(PlaybackService.live.player.isPlaying()); find(FloatingPlayerService.live.window, "Expand mini player").performClick(); });
        AtomicInteger width = new AtomicInteger(), savedX = new AtomicInteger(), savedY = new AtomicInteger(); main(() -> { width.set(FloatingPlayerService.live.windowParams.width); savedX.set(FloatingPlayerService.live.windowParams.x); savedY.set(FloatingPlayerService.live.windowParams.y); find(FloatingPlayerService.live.window, "Close mini player; keep playback running").performClick(); });
        await(() -> FloatingPlayerService.live == null); main(() -> assertTrue(PlaybackService.live.player.isPlaying()));
        main(() -> context.startActivity(new Intent(context, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT).putExtra("open_tab", 0)));
        await(() -> activity.hasWindowFocus()); openMini();
        main(() -> { assertEquals("Remember window size", width.get(), FloatingPlayerService.live.windowParams.width); assertEquals("Remember horizontal position", savedX.get(), FloatingPlayerService.live.windowParams.x); assertEquals("Remember vertical position", savedY.get(), FloatingPlayerService.live.windowParams.y); });
        main(() -> find(FloatingPlayerService.live.window, "Return to full player").performClick());
        await(() -> FloatingPlayerService.live == null); main(() -> assertTrue("Returning to full player must not stop the song", PlaybackService.live.player.isPlaying()));
    }
    @Test public void videoRendersInTheFloatingWindowAndReturnsToTheFullPlayer() throws Exception {
        Track track = MusicStore.get(context).importTrack(Uri.fromFile(video()));
        main(() -> { PlaybackService.live.player.setMediaItem(track.item()); PlaybackService.live.player.setRepeatMode(Player.REPEAT_MODE_ONE); PlaybackService.live.player.prepare(); PlaybackService.live.player.play(); });
        await(() -> PlaybackService.live.player.isPlaying() && PlaybackService.live.player.getVideoSize().width > 0);
        openMini();
        await(() -> { PlayerView view = findVideo(FloatingPlayerService.live.window); return view != null && view.isShown() && view.getVideoSurfaceView() instanceof TextureView && ((TextureView) view.getVideoSurfaceView()).isAvailable(); });
        await(() -> {
            Bitmap frame = ((TextureView) findVideo(FloatingPlayerService.live.window).getVideoSurfaceView()).getBitmap(16, 16);
            if (frame == null) return false;
            boolean colored = false; for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) if ((frame.getPixel(x, y) & 0xffffff) > 0x101010) colored = true;
            frame.recycle(); return colored;
        });
        drag("Drag title bar to move the mini player", 0, 65); SystemClock.sleep(300); screenshot("mini-player-video.png");
        main(() -> find(FloatingPlayerService.live.window, "Return to full player").performClick()); await(() -> FloatingPlayerService.live == null);
        await(() -> PlaybackService.live.player.isPlaying());
        // Verify that the resumed activity obtains video output again, rather than leaving a black full player.
        AtomicReference<View> full = new AtomicReference<>(); main(() -> full.set(activity.getWindow().getDecorView()));
        await(() -> { PlayerView view = findVideo(full.get()); return view != null && view.getPlayer() != null; });
    }
    private View find(View view, String description) {
        if (!view.isShown()) return null;
        if (description.contentEquals(view.getContentDescription() == null ? "" : view.getContentDescription())) return view;
        if (view instanceof ViewGroup) for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) { View result = find(((ViewGroup) view).getChildAt(i), description); if (result != null) return result; }
        return null;
    }
    private PlayerView findVideo(View view) {
        if (view instanceof PlayerView) return (PlayerView) view;
        if (view instanceof ViewGroup) for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) { PlayerView result = findVideo(((ViewGroup) view).getChildAt(i)); if (result != null) return result; }
        return null;
    }
    private ReelToReelView findReels(View view) {
        if (view instanceof ReelToReelView) return (ReelToReelView)view;
        if (view instanceof ViewGroup) for(int i=0;i<((ViewGroup)view).getChildCount();i++){ReelToReelView found=findReels(((ViewGroup)view).getChildAt(i));if(found!=null)return found;}
        return null;
    }
    private void drag(String description, int dx, int dy) {
        int[] point = new int[2]; main(() -> { View view = find(FloatingPlayerService.live.window, description); assertNotNull(view); view.getLocationOnScreen(point); point[0] += view.getWidth() / 2; point[1] += view.getHeight() / 2; });
        long start = SystemClock.uptimeMillis(); inject(start, MotionEvent.ACTION_DOWN, point[0], point[1]);
        for (int step = 1; step <= 5; step++) { SystemClock.sleep(30); inject(start, MotionEvent.ACTION_MOVE, point[0] + dx * step / 5f, point[1] + dy * step / 5f); }
        inject(start, MotionEvent.ACTION_UP, point[0] + dx, point[1] + dy);
    }
    private void tapSeek() {
        int[] point = new int[2]; main(() -> { View view = find(FloatingPlayerService.live.window, "Mini player position"); view.getLocationOnScreen(point); point[0] += view.getWidth() * 2 / 3; point[1] += view.getHeight() / 2; });
        long start = SystemClock.uptimeMillis(); inject(start, MotionEvent.ACTION_DOWN, point[0], point[1]); inject(start, MotionEvent.ACTION_UP, point[0], point[1]);
    }
    private void inject(long start, int action, float x, float y) {
        MotionEvent event = MotionEvent.obtain(start, SystemClock.uptimeMillis(), action, x, y, 0); event.setSource(InputDevice.SOURCE_TOUCHSCREEN);
        try { assertTrue(test.getUiAutomation().injectInputEvent(event, true)); } finally { event.recycle(); }
    }
    private void screenshot(String name) throws IOException {
        Bitmap image = test.getUiAutomation().takeScreenshot(); assertNotNull(image);
        try (FileOutputStream output = new FileOutputStream(new File(context.getFilesDir(), name))) { image.compress(Bitmap.CompressFormat.PNG, 100, output); } finally { image.recycle(); }
    }
    private void renderWindow(String name) throws IOException {
        AtomicReference<Bitmap> rendered=new AtomicReference<>();
        main(() -> { View window=FloatingPlayerService.live.window; Bitmap image=Bitmap.createBitmap(window.getWidth(),window.getHeight(),Bitmap.Config.ARGB_8888); window.draw(new Canvas(image)); rendered.set(image); });
        Bitmap image=rendered.get();
        try (FileOutputStream output=new FileOutputStream(new File(context.getFilesDir(),name))) { image.compress(Bitmap.CompressFormat.PNG,100,output); } finally { image.recycle(); }
    }
    private File tone() throws IOException {
        File file = new File(context.getFilesDir(), "Neon Drift.wav");
        try (PcmWaveWriter writer = new PcmWaveWriter(file, 44100, 1)) {
            short[] wave = new short[44100];
            for (int second = 0; second < 45; second++) { for (int i = 0; i < wave.length; i++) wave[i] = (short) (Math.sin(i * 2 * Math.PI * 220 / 44100) * 19000); writer.write(wave, wave.length); }
        } return file;
    }
    private File video() throws Exception {
        File file = new File(context.getFilesDir(), "Neon Motion.mp4"); int width = 320, height = 192, frames = 180;
        MediaCodec codec = MediaCodec.createEncoderByType("video/avc"); MediaMuxer muxer = null;
        try {
            int color = 0; for (int supported : codec.getCodecInfo().getCapabilitiesForType("video/avc").colorFormats) if (supported == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar || supported == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar) { color = supported; break; }
            assertTrue("A test AVC encoder with byte-buffer input is required", color != 0);
            MediaFormat format = MediaFormat.createVideoFormat("video/avc", width, height); format.setInteger(MediaFormat.KEY_COLOR_FORMAT, color); format.setInteger(MediaFormat.KEY_BIT_RATE, 500000); format.setInteger(MediaFormat.KEY_FRAME_RATE, 15); format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); codec.start();
            muxer = new MediaMuxer(file.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            byte[] yuv = new byte[width * height * 3 / 2]; int index = 0, track = -1; boolean endQueued = false, done = false; long deadline = SystemClock.elapsedRealtime() + 30000;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            while (!done && SystemClock.elapsedRealtime() < deadline) {
                if (!endQueued) {
                    int input = codec.dequeueInputBuffer(1000);
                    if (input >= 0) {
                        ByteBuffer bytes = codec.getInputBuffer(input); assertNotNull(bytes); bytes.clear();
                        if (index == frames) { codec.queueInputBuffer(input, 0, 0, index * 1000000L / 15, MediaCodec.BUFFER_FLAG_END_OF_STREAM); endQueued = true; }
                        else {
                            for (int y = 0; y < height; y++) for (int x = 0; x < width; x++) yuv[y * width + x] = (byte) ((x + index * 3) % width < width / 3 ? 155 : x < width * 2 / 3 ? 88 : 55);
                            if (color == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar) { Arrays.fill(yuv, width * height, width * height * 5 / 4, (byte) 160); Arrays.fill(yuv, width * height * 5 / 4, yuv.length, (byte) 80); }
                            else for (int p = width * height; p < yuv.length; p += 2) { yuv[p] = (byte) 160; yuv[p + 1] = (byte) 80; }
                            bytes.put(yuv); codec.queueInputBuffer(input, 0, yuv.length, index++ * 1000000L / 15, 0);
                        }
                    }
                }
                int output = codec.dequeueOutputBuffer(info, 1000);
                if (output == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { track = muxer.addTrack(codec.getOutputFormat()); muxer.start(); }
                else if (output >= 0) {
                    ByteBuffer bytes = codec.getOutputBuffer(output);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && info.size > 0) { assertTrue(track >= 0); bytes.position(info.offset); bytes.limit(info.offset + info.size); muxer.writeSampleData(track, bytes, info); }
                    done = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0; codec.releaseOutputBuffer(output, false);
                }
            } assertTrue("Synthetic video encoder finished", done); muxer.stop();
        } finally { codec.release(); if (muxer != null) muxer.release(); }
        return file;
    }
    @After public void finish() throws Exception {
        if (context != null) main(() -> { FloatingPlayerService.hide(context); if (PlaybackService.live != null) { PlaybackService.live.player.pause(); PlaybackService.live.player.setRepeatMode(Player.REPEAT_MODE_OFF); } if (activity != null) activity.finish(); });
        await(() -> FloatingPlayerService.live == null);
    }
}
