package com.cleargain.app;

import android.Manifest;
import android.app.Activity;
import android.app.Instrumentation;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.TextView;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import java.io.File;
import java.io.FileOutputStream;
import java.io.RandomAccessFile;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.junit.Assert.*;

/** Run on an emulator with host microphone input disabled; media uses a generated sine tone. */
@RunWith(AndroidJUnit4.class)
public final class RecordingIntegrationTest {
    private final Instrumentation instrumentation = InstrumentationRegistry.getInstrumentation();
    private Context context;
    private Activity activity;
    private SharedPreferences prefs;
    private void main(Runnable action) { instrumentation.runOnMainSync(action); }
    interface Check { boolean ok(); }
    private void await(Check check) throws Exception {
        long end = SystemClock.elapsedRealtime() + 15000;
        while (SystemClock.elapsedRealtime() < end) { if (check.ok()) return; SystemClock.sleep(100); }
        fail("Timed out waiting for Android recording");
    }
    @Before public void prepare() throws Exception {
        context = instrumentation.getTargetContext(); prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE);
        instrumentation.getUiAutomation().grantRuntimePermission(context.getPackageName(), Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33) instrumentation.getUiAutomation().grantRuntimePermission(context.getPackageName(), Manifest.permission.POST_NOTIFICATIONS);
        prefs.edit().putBoolean("auto_visuals", false).putInt("record_source", 0).apply();
        activity = instrumentation.startActivitySync(new Intent(context, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        await(() -> PlaybackService.live != null);
    }

    @Test public void microphonePauseResumeSavesAPlayableWavToThePad() throws Exception {
        String before = prefs.getString("recording_completion_id", "");
        main(() -> context.startForegroundService(new Intent(context, RecordingService.class).setAction(RecordingService.START)
                .putExtra("source", 1).putExtra("pad", 3).putExtra("rate", 44100).putExtra("max_ms", 3000)));
        await(() -> RecordingService.live != null && RecordingService.live.durationMs >= 500);
        main(() -> RecordingService.live.togglePause()); SystemClock.sleep(300);
        long pausedAt = RecordingService.live.durationMs; SystemClock.sleep(600);
        assertEquals("Paused input must not be appended to the take", pausedAt, RecordingService.live.durationMs);
        main(() -> RecordingService.live.togglePause()); await(() -> !before.equals(prefs.getString("recording_completion_id", "")));
        assertTrue(prefs.getString("recording_completion_message", ""), prefs.getBoolean("recording_completion_saved", false));
        File file = new File(Uri.parse(prefs.getString("pad_uri_3", "")).getPath());
        assertEquals(3000, PcmWaveWriter.durationMs(file)); assertEquals(44 + 44100 * 2 * 3, file.length());
        main(() -> PlaybackService.live.triggerPad(3));
        AtomicBoolean playing = new AtomicBoolean(); await(() -> { main(() -> playing.set(PlaybackService.live.padPlaying(3))); return playing.get(); });
    }

    @Test public void phoneAudioConsentCapturesThePlayingSyntheticTone() throws Exception {
        if (Build.VERSION.SDK_INT < 29) return;
        File tone = new File(context.getFilesDir(), "capture-tone.wav");
        try (PcmWaveWriter writer = new PcmWaveWriter(tone, 44100, 1)) {
            short[] samples = new short[44100 * 20]; for (int i = 0; i < samples.length; i++) samples[i] = (short) (Math.sin(i * 2 * Math.PI * 440 / 44100) * 12000);
            writer.write(samples, samples.length);
        }
        AudioManager audio = context.getSystemService(AudioManager.class); audio.setStreamVolume(AudioManager.STREAM_MUSIC, audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0);
        main(() -> { PlaybackService.live.player.setMediaItem(androidx.media3.common.MediaItem.fromUri(Uri.fromFile(tone))); PlaybackService.live.player.prepare(); PlaybackService.live.player.play(); });
        AtomicBoolean playing = new AtomicBoolean(); await(() -> { main(() -> playing.set(PlaybackService.live.player.isPlaying())); return playing.get(); });
        main(() -> { TextView record = findButton(activity.getWindow().getDecorView(), "● RECORD"); assertNotNull(record); record.performClick(); });
        SystemClock.sleep(300); screenshot("recording-options.png");
        clickSystemText("START RECORDING"); clickSystemText("Start now");
        await(() -> RecordingService.live != null && RecordingService.live.durationMs >= 1500 && RecordingService.live.hasSignal);
        SystemClock.sleep(300); screenshot("recording-live.png");
        long beforeBackground = RecordingService.live.durationMs;
        main(() -> context.startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)));
        await(() -> RecordingService.live != null && RecordingService.live.durationMs >= beforeBackground + 700);
        String before = prefs.getString("recording_completion_id", ""); int pad = RecordingService.live.pad;
        main(() -> { assertTrue("Recording must preserve live playback", PlaybackService.live.player.isPlaying()); RecordingService.live.stop(false); });
        await(() -> !before.equals(prefs.getString("recording_completion_id", "")));
        assertTrue(prefs.getString("recording_completion_message", ""), prefs.getBoolean("recording_completion_saved", false));
        File take = new File(Uri.parse(prefs.getString("pad_uri_" + pad, "")).getPath());
        assertTrue(PcmWaveWriter.durationMs(take) >= 1500);
        int maximum = 0; try (RandomAccessFile input = new RandomAccessFile(take, "r")) {
            input.seek(44); while (input.getFilePointer() + 1 < input.length()) { int sample = input.readUnsignedByte() | input.readUnsignedByte() << 8; maximum = Math.max(maximum, Math.abs((short) sample)); }
        }
        assertTrue("Phone capture must contain real audio, not a silent WAV", maximum > 100);
    }

    private void screenshot(String name) throws Exception {
        Bitmap image = instrumentation.getUiAutomation().takeScreenshot();
        assertNotNull("Recording UI screenshot", image);
        try (FileOutputStream output = new FileOutputStream(new File(context.getFilesDir(), name))) {
            image.compress(Bitmap.CompressFormat.PNG, 100, output);
        } finally { image.recycle(); }
    }

    private TextView findButton(View view, String text) {
        if (view instanceof TextView && text.contentEquals(((TextView) view).getText())) return (TextView) view;
        if (view instanceof ViewGroup) for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) { TextView match = findButton(((ViewGroup) view).getChildAt(i), text); if (match != null) return match; }
        return null;
    }
    private void clickSystemText(String text) throws Exception {
        await(() -> {
            AccessibilityNodeInfo root = instrumentation.getUiAutomation().getRootInActiveWindow(); if (root == null) return false;
            List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByText(text);
            for (AccessibilityNodeInfo node : nodes) if (node.isClickable() && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            return false;
        });
    }
    @After public void finish() throws Exception {
        if (RecordingService.live != null) main(() -> RecordingService.live.stop(false));
        main(() -> { if (PlaybackService.live != null) { PlaybackService.live.player.pause(); PlaybackService.live.stopPads(); } if (activity != null) activity.finish(); });
        await(() -> RecordingService.live == null);
    }
}
