package com.cleargain.app;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.Drawable;

/** Dark anodized rack face with a fine gold bevel and silver fastening points. */
final class DeckPanelDrawable extends Drawable {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density, radius;
    private int alpha=255;
    DeckPanelDrawable(Context context,float radiusDp) { density=context.getResources().getDisplayMetrics().density; radius=radiusDp*density; }
    @Override public void draw(Canvas canvas) {
        Rect bounds=getBounds(); if(bounds.isEmpty())return;
        RectF frame=new RectF(bounds),face=new RectF(bounds); face.inset(1.5f*density,1.5f*density);
        paint.setAlpha(alpha);
        paint.setShader(new LinearGradient(frame.left,frame.top,frame.right,frame.bottom,new int[]{0xff494d43,0xffe7c776,0xff655024,0xffb8bcb3},null,Shader.TileMode.CLAMP));
        canvas.drawRoundRect(frame,radius,radius,paint);
        paint.setShader(new LinearGradient(face.left,face.top,face.left,face.bottom,new int[]{0xff29352e,0xff101a16,0xff070d0b},new float[]{0,.18f,1},Shader.TileMode.CLAMP));
        canvas.drawRoundRect(face,Math.max(0,radius-density),Math.max(0,radius-density),paint); paint.setShader(null);
        int save=canvas.save(); Path clip=new Path();clip.addRoundRect(face,radius,radius,Path.Direction.CW);canvas.clipPath(clip);
        paint.setStrokeWidth(.4f*density);paint.setColor(0x0affffff);
        for(float y=face.top+2*density;y<face.bottom;y+=2*density)canvas.drawLine(face.left,y,face.right,y,paint);
        canvas.restoreToCount(save);
        paint.setColor(0xffbabdad);
        for(float x:new float[]{frame.left+4*density,frame.right-4*density})for(float y:new float[]{frame.top+4*density,frame.bottom-4*density}){
            canvas.drawCircle(x,y,1.5f*density,paint);paint.setColor(0xff353b32);canvas.drawLine(x-density,y,x+density,y,paint);paint.setColor(0xffbabdad);
        }
        paint.setAlpha(255);
    }
    @Override public void getOutline(Outline outline){outline.setRoundRect(getBounds(),radius);}
    @Override public void setAlpha(int value){alpha=value;invalidateSelf();}
    @Override public void setColorFilter(ColorFilter filter){paint.setColorFilter(filter);invalidateSelf();}
    @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
