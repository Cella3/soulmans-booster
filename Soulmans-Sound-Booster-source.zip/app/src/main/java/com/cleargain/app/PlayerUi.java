package com.cleargain.app;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.*;

final class PlayerUi {
    static int dp(Context c,float n){return Math.round(n*c.getResources().getDisplayMetrics().density);}
    static LinearLayout column(Context c){LinearLayout v=new LinearLayout(c);v.setOrientation(LinearLayout.VERTICAL);return v;}
    static LinearLayout row(Context c){LinearLayout v=new LinearLayout(c);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    static TextView text(Context c,String s,int size){TextView t=new TextView(c);t.setText(s);t.setTextSize(size);t.setTextColor(DeckSkin.GOLD);t.setTypeface(Typeface.MONOSPACE);return t;}
    static TextView button(Context c,String s,Runnable action){TextView t=text(c,s,11);t.setGravity(Gravity.CENTER);DeckSkin.button(t);t.setPadding(dp(c,5),dp(c,4),dp(c,5),dp(c,4));t.setClickable(true);t.setFocusable(true);t.setOnClickListener(v->action.run());t.setContentDescription(s);return t;}
    static void weighted(LinearLayout row,android.view.View view,int height){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(row.getContext(),height),1);p.setMargins(2,2,2,2);row.addView(view,p);}
    static String clock(long ms){long s=Math.max(0,ms)/1000;return String.format(java.util.Locale.US,"%d:%02d",s/60,s%60);}
    private PlayerUi(){}
}
