package com.cleargain.app;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.function.DoubleConsumer;

final class MixerFader extends View {
    private final Paint p=new Paint(3);private float value=1;private DoubleConsumer change;private final String label;
    MixerFader(Context c,String label,float value,DoubleConsumer change){super(c);this.label=label;this.value=value;this.change=change;setContentDescription(label+" channel fader");setClickable(true);}
    protected void onDraw(Canvas c){float w=getWidth(),h=getHeight(),top=PlayerUi.dp(getContext(),22),bottom=h-PlayerUi.dp(getContext(),10);p.setColor(0xff09100d);c.drawRoundRect(w*.4f,top,w*.6f,bottom,4,4,p);p.setStrokeWidth(1);for(int i=0;i<=10;i++){float y=top+(bottom-top)*i/10;p.setColor(0xff676c56);c.drawLine(w*.18f,y,w*.33f,y,p);c.drawLine(w*.67f,y,w*.82f,y,p);}float y=bottom-value*(bottom-top);p.setShader(new LinearGradient(0,y-8,w,y+8,0xffe8dfbd,0xff6e786f,Shader.TileMode.CLAMP));c.drawRoundRect(w*.1f,y-8,w*.9f,y+8,3,3,p);p.setShader(null);p.setColor(0xffbc9c49);c.drawLine(w*.16f,y,w*.84f,y,p);p.setTextSize(PlayerUi.dp(getContext(),10));p.setTextAlign(Paint.Align.CENTER);p.setColor(DeckSkin.GOLD);c.drawText(label,w/2,PlayerUi.dp(getContext(),14),p);}
    public boolean onTouchEvent(MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN)getParent().requestDisallowInterceptTouchEvent(true);if(e.getAction()==MotionEvent.ACTION_DOWN||e.getAction()==MotionEvent.ACTION_MOVE){value=Math.max(0,Math.min(1,(getHeight()-PlayerUi.dp(getContext(),10)-e.getY())/(getHeight()-PlayerUi.dp(getContext(),32))));change.accept(value);invalidate();}if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){getParent().requestDisallowInterceptTouchEvent(false);performClick();}return true;}
    public boolean performClick(){super.performClick();return true;}
}
