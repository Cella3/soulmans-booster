package com.cleargain.app;

import android.app.*;
import android.content.*;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.os.*;
import java.util.concurrent.*;

/** Keeps both decks together through pickers, backgrounding, and fullscreen rotation. */
public final class DjService extends Service {
    static DjService live;
    final DjEngine engine=new DjEngine();
    final String[] status={"Choose a song","Choose a song"};
    private final java.util.concurrent.atomic.AtomicIntegerArray generation=new java.util.concurrent.atomic.AtomicIntegerArray(2);private final boolean[] counted={false,false};
    private final ExecutorService loaders=Executors.newFixedThreadPool(2);
    private final Handler main=new Handler(Looper.getMainLooper());
    private AudioManager audio;private AudioFocusRequest focus;private PowerManager.WakeLock wake;
    private volatile boolean destroyed;
    private final BroadcastReceiver noisy=new BroadcastReceiver(){public void onReceive(Context c,Intent i){engine.pause();}};
    public void onCreate(){super.onCreate();live=this;
        NotificationManager manager=getSystemService(NotificationManager.class);manager.createNotificationChannel(new NotificationChannel("dj","DJ mixer",NotificationManager.IMPORTANCE_LOW));
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,DjActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent stop=PendingIntent.getService(this,0,new Intent(this,DjService.class).setAction("STOP"),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        startForeground(34,new Notification.Builder(this,"dj").setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("Soulman's DJ Mixer").setContentText("Two decks · tap to open the mixer").setContentIntent(open).addAction(new Notification.Action.Builder(null,"STOP MIX",stop).build()).setOngoing(true).build());
        audio=getSystemService(AudioManager.class);focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_MEDIA).setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC).build()).setOnAudioFocusChangeListener(change->{if(change!=AudioManager.AUDIOFOCUS_GAIN){engine.pause();status[0]="Audio focus changed · press play to resume";}}).build();
        if(audio.requestAudioFocus(focus)!=AudioManager.AUDIOFOCUS_REQUEST_GRANTED)status[0]="Audio busy · press play to retry";
        wake=getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"Soulmans:DJ");wake.acquire();
        if(Build.VERSION.SDK_INT>=33)registerReceiver(noisy,new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY),Context.RECEIVER_NOT_EXPORTED);else registerReceiver(noisy,new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
        if(PlaybackService.live!=null){PlaybackService.live.player.pause();PlaybackService.live.disableGlobalBoost();}
        try{engine.start();}catch(RuntimeException e){status[0]="Audio output failed: "+e.getMessage();}
    }
    void load(int index,Track track){int request=generation.incrementAndGet(index);status[index]="DECODING · "+track.title;
        loaders.execute(()->{DjPcm pcm=null;try{
            pcm=DjDecoder.decode(this,track.uri,()->destroyed||generation.get(index)!=request,0);DjAnalysis.Result result=DjAnalysis.analyze(pcm);DjMetadata.save(getSharedPreferences("settings",0),track.uri,result);
            DjPcm ready=pcm;main.post(()->{if(destroyed||generation.get(index)!=request){ready.close();return;}engine.load(index,track,ready,DjMetadata.bpm(getSharedPreferences("settings",0),track.uri));for(int cue=0;cue<4;cue++)engine.restoreCue(index,cue,getSharedPreferences("settings",0).getFloat("dj_cue_"+index+"_"+cue+"_"+DjMetadata.suffix(track.uri),-1));counted[index]=false;status[index]="READY · tap PLAY / scratch the vinyl";});
        }catch(Exception e){if(pcm!=null)pcm.close();main.post(()->{if(!destroyed&&generation.get(index)==request)status[index]="LOAD FAILED · "+e.getMessage();});}});
    }
    void toggle(int index){if(audio.requestAudioFocus(focus)!=AudioManager.AUDIOFOCUS_REQUEST_GRANTED){status[index]="Another app has audio focus";return;}if(PlaybackService.live!=null)PlaybackService.live.player.pause();engine.toggle(index);DjEngine.State state=engine.state(index);if(state.playing()&&!counted[index]){MusicStore.get(this).played(state.uri());counted[index]=true;}status[index]=state.playing()?"PLAYING":"PAUSED";}
    public int onStartCommand(Intent intent,int flags,int id){if(intent!=null&&"STOP".equals(intent.getAction()))stopSelf();return START_NOT_STICKY;}
    public IBinder onBind(Intent intent){return null;}
    public void onDestroy(){destroyed=true;generation.incrementAndGet(0);generation.incrementAndGet(1);loaders.shutdownNow();main.removeCallbacksAndMessages(null);engine.close();try{unregisterReceiver(noisy);}catch(RuntimeException ignored){}if(audio!=null&&focus!=null)audio.abandonAudioFocusRequest(focus);if(wake!=null&&wake.isHeld())wake.release();live=null;super.onDestroy();}
}
