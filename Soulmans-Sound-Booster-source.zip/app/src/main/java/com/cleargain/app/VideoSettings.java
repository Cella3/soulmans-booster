package com.cleargain.app;

import android.app.*;
import android.content.*;
import android.widget.*;
import java.util.Locale;

/** Real frame effects and playback controls shared by inline and fullscreen video. */
final class VideoSettings {
    static void show(Activity activity,VideoGestureOverlay gesture,Runnable export){
        PlaybackService service=PlaybackService.live;if(service==null)return;
        androidx.media3.common.MediaItem item=service.player.getCurrentMediaItem();if(item==null)return;
        String uri=item.mediaId,key=VideoClipPrefs.key(uri);SharedPreferences p=activity.getSharedPreferences("settings",0);
        LinearLayout body=PlayerUi.column(activity);body.setPadding(18,10,18,18);body.setBackgroundColor(0xff101614);
        body.addView(PlayerUi.text(activity,"PICTURE · saved for this file",12));
        Runnable[] resetPicture={adjustment(activity,body,"Brightness","video_brightness_"+key,100,p,service),
        adjustment(activity,body,"Saturation","video_saturation_"+key,100,p,service),
        adjustment(activity,body,"Hue / color","video_hue_"+key,180,p,service),
        adjustment(activity,body,"Contrast","video_contrast_"+key,90,p,service)};
        body.addView(PlayerUi.button(activity,"RESET PICTURE & FRAMING",()->{
            p.edit().remove("video_brightness_"+key).remove("video_saturation_"+key).remove("video_hue_"+key).remove("video_contrast_"+key).apply();
            service.applyVideoEffects();for(Runnable reset:resetPicture)reset.run();if(gesture!=null)gesture.resetZoom();
        }),new LinearLayout.LayoutParams(-1,PlayerUi.dp(activity,44)));
        TextView speed=PlayerUi.text(activity,"",12);body.addView(speed);
        SeekBar rate=new SeekBar(activity);DeckSkin.slider(rate);rate.setMax(1000);rate.setContentDescription("Video speed quarter to fifty times");
        float initial=service.requestedSpeed();rate.setProgress(Math.round((float)(Math.log(initial/.25)/Math.log(200))*1000));
        Runnable updateSpeed=()->speed.setText(String.format(Locale.US,"SPEED %.2f×%s",service.requestedSpeed(),service.requestedSpeed()>8?" · silent scan":""));updateSpeed.run();
        body.addView(rate,new LinearLayout.LayoutParams(-1,PlayerUi.dp(activity,40)));
        rate.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar s,int n,boolean user){if(user)speed.setText(String.format(Locale.US,"SPEED %.2f×",.25*Math.pow(200,n/1000.0)));}public void onStopTrackingTouch(SeekBar s){service.speed((float)(.25*Math.pow(200,s.getProgress()/1000.0)));updateSpeed.run();}});
        LinearLayout quick=PlayerUi.row(activity);for(float value:new float[]{.25f,1,2,8,50})PlayerUi.weighted(quick,PlayerUi.button(activity,value+"×",()->{service.speed(value);rate.setProgress(Math.round((float)(Math.log(value/.25)/Math.log(200))*1000));updateSpeed.run();}),40);body.addView(quick);
        body.addView(PlayerUi.text(activity,"Above 8×: silent fast scan. Frame smoothness depends on the video and phone.",10));
        long duration=Math.max(1,service.player.getDuration());if(duration<1)duration=1;final long length=duration;
        long[] range={VideoClipPrefs.start(p,uri),VideoClipPrefs.end(p,uri,length)};
        SeekBar[] loopPoints=new SeekBar[2];TextView points=PlayerUi.text(activity,"",12);body.addView(points);CheckBox loop=new CheckBox(activity);loop.setText("LOOP BETWEEN IN / OUT");loop.setTextColor(DeckSkin.GOLD);loop.setChecked(VideoClipPrefs.loops(p,uri));body.addView(loop);
        Runnable save=()->{VideoClipPrefs.save(p,uri,range[0],range[1],loop.isChecked(),p.getInt("video_export_quality_"+key,0),p.getInt("video_export_type_"+key,0));points.setText("IN "+PlayerUi.clock(range[0])+"   OUT "+PlayerUi.clock(range[1]));service.updateVideoLoop();for(int i=0;i<2;i++)if(loopPoints[i]!=null&&!loopPoints[i].isPressed())loopPoints[i].setProgress((int)(range[i]*1000/length));};
        for(int j=0;j<2;j++){final int i=j;SeekBar point=new SeekBar(activity);loopPoints[i]=point;DeckSkin.slider(point);point.setContentDescription(i==0?"Video loop IN":"Video loop OUT");point.setMax(1000);point.setProgress((int)(range[i]*1000/length));body.addView(point,new LinearLayout.LayoutParams(-1,PlayerUi.dp(activity,40)));point.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar s,int n,boolean user){if(user){range[i]=Math.max(i==0?0:range[0]+1,Math.min(i==0?range[1]-1:length,length*n/1000));save.run();}}});}
        LinearLayout marks=PlayerUi.row(activity);PlayerUi.weighted(marks,PlayerUi.button(activity,"IN = NOW",()->{range[0]=Math.min(range[1]-1,service.player.getCurrentPosition());save.run();}),42);PlayerUi.weighted(marks,PlayerUi.button(activity,"OUT = NOW",()->{range[1]=Math.max(range[0]+1,service.player.getCurrentPosition());save.run();}),42);PlayerUi.weighted(marks,PlayerUi.button(activity,"EXPORT CLIP",export),42);body.addView(marks);loop.setOnCheckedChangeListener((v,on)->save.run());save.run();
        body.addView(PlayerUi.text(activity,"AUDIO · EQ & optional boost",12));body.addView(new DeckEqControls(activity));
        TextView pitch=PlayerUi.text(activity,"",12);body.addView(pitch);Track track=MusicStore.get(activity).track(uri);SeekBar pitchControl=new SeekBar(activity);DeckSkin.slider(pitchControl);pitchControl.setContentDescription("Video audio pitch");pitchControl.setMax(48);pitchControl.setProgress(track==null?24:Math.round(track.pitch*2+24));pitch.setText("PITCH "+(track==null?0:track.pitch)+" st");body.addView(pitchControl,new LinearLayout.LayoutParams(-1,PlayerUi.dp(activity,40)));pitchControl.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar s,int n,boolean user){if(user){service.pitch((n-24)/2f);pitch.setText("PITCH "+(n-24)/2f+" st");}}});
        ScrollView scroll=new ScrollView(activity);scroll.addView(body);AlertDialog dialog=new AlertDialog.Builder(activity).setTitle("VIDEO & AUDIO SETTINGS").setView(scroll).setPositiveButton("DONE",null).create();dialog.show();dialog.getWindow().setLayout(Math.min(PlayerUi.dp(activity,540),activity.getResources().getDisplayMetrics().widthPixels-32),Math.round(activity.getResources().getDisplayMetrics().heightPixels*.86f));
    }
    private static Runnable adjustment(Activity a,LinearLayout body,String name,String key,int range,SharedPreferences p,PlaybackService service){
        TextView label=PlayerUi.text(a,name+": "+p.getInt(key,0),11);body.addView(label);SeekBar slider=new SeekBar(a);DeckSkin.slider(slider);slider.setMax(range*2);slider.setProgress(p.getInt(key,0)+range);slider.setContentDescription("Video "+name);body.addView(slider,new LinearLayout.LayoutParams(-1,PlayerUi.dp(a,36)));
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar s,int n,boolean user){if(user)label.setText(name+": "+(n-range));}public void onStopTrackingTouch(SeekBar s){p.edit().putInt(key,s.getProgress()-range).apply();service.applyVideoEffects();}});
        return ()->{slider.setProgress(range);label.setText(name+": 0");};
    }
}
