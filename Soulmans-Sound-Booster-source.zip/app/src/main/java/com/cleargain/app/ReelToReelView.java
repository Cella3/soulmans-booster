package com.cleargain.app;

import android.content.Context;
import android.graphics.*;
import android.os.SystemClock;
import android.view.View;

/** Animated, mechanical reel deck. The tape packs follow the actual media timeline. */
final class ReelToReelView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path tape = new Path();
    private final Typeface nameplate;
    private String mediaKey = "";
    private long position, duration, capturedAt, lastFrame;
    private boolean playing;
    private SoundProcessor source;
    private double leftAngle, rightAngle;
    private float tapeTravel;

    ReelToReelView(Context context) {
        super(context); nameplate = MetalSkin.nameplate(context);
        setBackground(new DeckPanelDrawable(context, 3));
        setContentDescription("Reel-to-reel tape deck. Tape moves from the supply reel to the take-up reel as the song progresses.");
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }
    void state(String key, long position, long duration, boolean playing, SoundProcessor source) {
        if (!mediaKey.equals(key)) { mediaKey = key; leftAngle = rightAngle = tapeTravel = 0; lastFrame = 0; }
        if (this.playing != playing) lastFrame = 0;
        this.position = Math.max(0, position); this.duration = Math.max(0, duration);
        this.playing = playing; this.source = source; capturedAt = SystemClock.elapsedRealtime(); invalidate();
    }
    double progress() {
        long elapsed = playing ? Math.max(0, SystemClock.elapsedRealtime() - capturedAt) : 0;
        return ReelTapeMath.progress(position + elapsed, duration);
    }
    double leftRotation() { return leftAngle; }
    void pauseAnimation() { playing = false; lastFrame = 0; invalidate(); }
    float supplyRadius() { return ReelTapeMath.packRadius(1 - progress(), 17, 50); }
    float takeUpRadius() { return ReelTapeMath.packRadius(progress(), 17, 50); }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        long now = SystemClock.elapsedRealtime();
        boolean running = playing && isShown() && getWindowVisibility() == VISIBLE;
        float supply = supplyRadius(), takeUp = takeUpRadius();
        if (running && lastFrame > 0) {
            double seconds = Math.min(.1, Math.max(0, now - lastFrame) / 1000.0);
            leftAngle = (leftAngle + seconds * 38 / supply * 180 / Math.PI) % 360;
            rightAngle = (rightAngle + seconds * 38 / takeUp * 180 / Math.PI) % 360;
            tapeTravel = (tapeTravel + (float) seconds * 38) % 27;
        }
        lastFrame = now;
        float scale = Math.min(getWidth() / 360f, getHeight() / 170f);
        if (scale <= 0) return;
        int save = canvas.save();
        canvas.translate((getWidth() - 360 * scale) / 2, (getHeight() - 170 * scale) / 2); canvas.scale(scale, scale);
        screw(canvas, 12, 12); screw(canvas, 348, 12); screw(canvas, 12, 158); screw(canvas, 348, 158);
        drawTape(canvas, supply, takeUp);
        reel(canvas, 88, 72, supply, (float) leftAngle);
        reel(canvas, 272, 72, takeUp, (float) rightAngle);
        guide(canvas, 129, 132); guide(canvas, 231, 132);
        paint.setShader(new LinearGradient(145, 115, 216, 157, new int[]{0xff777d83, 0xffeff1ed, 0xffa99150}, null, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(145, 115, 215, 157, 5, 5, paint); paint.setShader(null);
        paint.setColor(0xff1b242a); canvas.drawRoundRect(151, 122, 209, 151, 3, 3, paint);
        paint.setColor(0xff8b703c); canvas.drawRect(153, 136, 207, 140, paint);
        paint.setColor(0xffd5bd82); canvas.drawRect(175, 123, 185, 134, paint);
        paint.setColor(0xff7f8990); canvas.drawRect(176, 127, 184, 133, paint);
        paint.setColor(0xff424d57); canvas.drawRoundRect(144, 34, 216, 94, 7, 7, paint);
        paint.setColor(0xff111a21); canvas.drawRoundRect(147, 37, 213, 91, 5, 5, paint);
        paint.setTypeface(nameplate); paint.setTextAlign(Paint.Align.CENTER); paint.setTextSize(15); paint.setColor(0xfff2d88f);
        canvas.drawText("Soulman’s", 180, 54, paint);
        paint.setTypeface(Typeface.MONOSPACE); paint.setTextSize(6.5f); paint.setColor(0xffcfbe93);
        canvas.drawText("REEL / 2 REEL", 180, 66, paint);
        meter(canvas, running, now);
        paint.setTextSize(7.5f); paint.setColor(DeckSkin.GOLD);
        canvas.drawText("SUPPLY", 88, 156, paint); canvas.drawText("TAKE-UP", 272, 156, paint);
        paint.setTextAlign(Paint.Align.LEFT); canvas.restoreToCount(save);
        if (running) postInvalidateDelayed(33);
    }
    private void drawTape(Canvas canvas, float supply, float takeUp) {
        tape.reset(); tape.moveTo(88 + supply * .71f, 72 + supply * .71f);
        tape.lineTo(129, 132); tape.quadTo(129, 141, 142, 140); tape.lineTo(218, 140);
        tape.quadTo(231, 141, 231, 132); tape.lineTo(272 - takeUp * .71f, 72 + takeUp * .71f);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(4); paint.setColor(0xff302319); canvas.drawPath(tape, paint);
        paint.setStrokeWidth(1.1f); paint.setColor(0xffc1a46c); paint.setPathEffect(new DashPathEffect(new float[]{7, 20}, -tapeTravel));
        canvas.drawPath(tape, paint); paint.setPathEffect(null); paint.setStyle(Paint.Style.FILL);
    }
    private void reel(Canvas canvas, float x, float y, float pack, float angle) {
        paint.setColor(0x440e1319); canvas.drawCircle(x + 1, y + 3, 58.5f, paint);
        paint.setShader(new RadialGradient(x - 16, y - 22, 82, new int[]{0xfffafcfc, 0xffb5bdc3, 0xffeef0f1, 0xff686e75}, new float[]{0, .35f, .67f, 1}, Shader.TileMode.CLAMP));
        canvas.drawCircle(x, y, 57, paint); paint.setShader(null);
        paint.setColor(0xff453122); canvas.drawCircle(x, y, pack, paint);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(.55f);
        for (float r = 18; r < pack; r += 2) { paint.setColor(((int) r % 4 == 0) ? 0xff79603c : 0xff241c17); canvas.drawCircle(x, y, r, paint); }
        paint.setStyle(Paint.Style.FILL);
        int save = canvas.save(); canvas.rotate(angle, x, y);
        Path face=new Path();face.setFillType(Path.FillType.EVEN_ODD);face.addCircle(x,y,54,Path.Direction.CW);
        for(int cutout=0;cutout<3;cutout++){
            Path slot=new Path();slot.addRoundRect(x-8,y-49,x+8,y-22,4,4,Path.Direction.CW);
            Matrix turn=new Matrix();turn.setRotate(cutout*120,x,y);slot.transform(turn);face.addPath(slot);
        }
        paint.setShader(new LinearGradient(x-50,y-50,x+45,y+45,new int[]{0xff806023,0xffeacb77,0xffb58e37,0xfff4db91,0xff8e6c27},null,Shader.TileMode.CLAMP));canvas.drawPath(face,paint);paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(.7f);paint.setColor(0xff5e4825);canvas.drawPath(face,paint);paint.setStyle(Paint.Style.FILL);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(3);
        paint.setShader(new LinearGradient(x - 57, y - 57, x + 57, y + 57,
                new int[]{0xff7c5721, 0xffffe5a1, 0xff9b722b, 0xfff8d88a}, null, Shader.TileMode.CLAMP));
        canvas.drawCircle(x, y, 56, paint); paint.setShader(null);
        paint.setStrokeWidth(.8f); paint.setColor(0xfff6f9f8); canvas.drawCircle(x, y, 53, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new RadialGradient(x - 5, y - 6, 26, new int[]{0xffffedb6, 0xffba8b38, 0xff6e4e20}, null, Shader.TileMode.CLAMP));
        canvas.drawCircle(x, y, 17, paint); paint.setShader(null);
        paint.setColor(0xff3d4951); canvas.drawCircle(x, y, 9, paint);
        paint.setColor(0xffced5d8); canvas.drawCircle(x - 1, y - 1, 6, paint);
        paint.setColor(0xff464b4d); canvas.drawRoundRect(x - 1, y - 5, x + 1, y + 4, .7f, .7f, paint);
        canvas.restoreToCount(save);
    }
    private void guide(Canvas canvas, float x, float y) {
        paint.setColor(0xff756032); canvas.drawCircle(x, y, 8, paint);
        paint.setShader(new RadialGradient(x - 2, y - 3, 10, new int[]{0xfffcfdfd, 0xffa4adb5, 0xff515b63}, null, Shader.TileMode.CLAMP));
        canvas.drawCircle(x, y, 6, paint); paint.setShader(null);
        paint.setColor(0xff473b2a); canvas.drawCircle(x, y, 2, paint);
    }
    private void screw(Canvas canvas, float x, float y) {
        paint.setColor(0xff86672f); canvas.drawCircle(x, y, 3.4f, paint);
        paint.setColor(0xffe5d7b4); canvas.drawCircle(x - .3f, y - .3f, 2.5f, paint);
        paint.setColor(0xff655333); canvas.drawRect(x - 1.8f, y - .4f, x + 1.8f, y + .4f, paint);
    }
    private void meter(Canvas canvas, boolean running, long now) {
        float level = 0;
        if (running && source != null && now - source.capturedAt < 600)
            for (float sample : source.waveform) level = Math.max(level, Math.abs(sample));
        for (int i = 0; i < 10; i++) {
            paint.setColor(level > (i + 1) / 12f ? (i >= 8 ? 0xffe09762 : 0xffebca7c) : 0xff34403f);
            canvas.drawRect(154 + i * 5.2f, 77, 157 + i * 5.2f, 85, paint);
        }
    }
}
