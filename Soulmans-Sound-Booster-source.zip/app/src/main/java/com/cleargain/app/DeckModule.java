package com.cleargain.app;

import android.content.*;
import android.graphics.Typeface;
import android.view.*;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.*;

/** A working rack section; its open state survives reopening the player. */
final class DeckModule extends LinearLayout {
    final LinearLayout content;
    private final TextView header;
    private final SharedPreferences prefs;
    private final String key,name;
    private Runnable changed;
    DeckModule(Context context,String key,String name,boolean defaultOpen){
        super(context);this.key=key;this.name=name;prefs=context.getSharedPreferences("settings",0);setOrientation(VERTICAL);setBackground(new DeckPanelDrawable(context,3));
        header=new TextView(context);header.setTextSize(11);header.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));header.setTextColor(DeckSkin.GOLD);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(12),0,dp(8),0);header.setLetterSpacing(.08f);header.setClickable(true);header.setFocusable(true);
        header.setAccessibilityDelegate(new View.AccessibilityDelegate(){@Override public void onInitializeAccessibilityNodeInfo(View host,AccessibilityNodeInfo info){super.onInitializeAccessibilityNodeInfo(host,info);info.setClassName(Button.class.getName());}});
        addView(header,new LayoutParams(-1,dp(44)));content=new LinearLayout(context);content.setOrientation(VERTICAL);content.setPadding(dp(8),0,dp(8),dp(8));addView(content,new LayoutParams(-1,-2));
        setExpanded(prefs.getBoolean(key,defaultOpen),false);header.setOnClickListener(v->setExpanded(!expanded(),true));
    }
    void onChanged(Runnable action){changed=action;}
    boolean expanded(){return content.getVisibility()==VISIBLE;}
    void open(){setExpanded(true,true);}
    private void setExpanded(boolean open,boolean save){content.setVisibility(open?VISIBLE:GONE);header.setText((open?"−  ":"＋  ")+name+"   ·   "+(open?"OPEN":"ADD-ON"));header.setContentDescription((open?"Collapse ":"Expand ")+name+" module");if(save){prefs.edit().putBoolean(key,open).apply();if(changed!=null)changed.run();}}
    int expandedHeight(int width){if(!expanded())return 0;content.measure(MeasureSpec.makeMeasureSpec(Math.max(1,width),MeasureSpec.EXACTLY),MeasureSpec.makeMeasureSpec(0,MeasureSpec.UNSPECIFIED));return content.getMeasuredHeight();}
    private int dp(float value){return Math.round(value*getResources().getDisplayMetrics().density);}
}
