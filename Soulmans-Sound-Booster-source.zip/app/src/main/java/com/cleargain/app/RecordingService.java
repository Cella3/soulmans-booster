package com.cleargain.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioPlaybackCaptureConfiguration;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

/** A visible, user-started recording session that survives switching to a playing app. */
public final class RecordingService extends Service {
    static final String START = "com.cleargain.app.RECORD_START", STOP = "com.cleargain.app.RECORD_SAVE",
            PAUSE = "com.cleargain.app.RECORD_PAUSE", DISCARD = "com.cleargain.app.RECORD_DISCARD";
    static volatile RecordingService live;
    volatile boolean paused, saving, hasSignal;
    volatile long durationMs, countInRemainingMs;
    volatile int level;
    int source, pad, rate, maxMs;
    private static final int NOTIFICATION = 703;
    private static final String CHANNEL = "sample-recording";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private MediaProjection projection;
    private volatile AudioRecord audio;
    private volatile boolean stopRequested, discard;
    private boolean finished;
    private Thread recordingThread;
    private String sessionId;
    private final MediaProjection.Callback projectionCallback = new MediaProjection.Callback() {
        @Override public void onStop() { if (!finished) stop(false); }
    };
    private final Runnable notificationTick = new Runnable() {
        @Override public void run() {
            if (finished) return;
            getSystemService(NotificationManager.class).notify(NOTIFICATION, notification());
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate() {
        super.onCreate(); live = this; prefs = getSharedPreferences("settings", MODE_PRIVATE);
        getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel(CHANNEL, "Sampler recording", NotificationManager.IMPORTANCE_LOW));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        String action = intent.getAction();
        if (STOP.equals(action) || DISCARD.equals(action)) { if (recordingThread != null) stop(DISCARD.equals(action)); else stopSelf(); return START_NOT_STICKY; }
        if (PAUSE.equals(action)) { if (recordingThread != null) togglePause(); else stopSelf(); return START_NOT_STICKY; }
        if (!START.equals(action)) { if (recordingThread == null) stopSelf(); return START_NOT_STICKY; }
        if (recordingThread != null) return START_NOT_STICKY;
        source = intent.getIntExtra("source", 0) == 0 ? 0 : 1;
        pad = Math.max(0, Math.min(3, intent.getIntExtra("pad", 0)));
        rate = intent.getIntExtra("rate", 44100) == 48000 ? 48000 : 44100;
        maxMs = Math.max(1000, Math.min(300000, intent.getIntExtra("max_ms", 60000)));
        int countIn = Math.max(0, Math.min(3000, intent.getIntExtra("count_in_ms", 0)));
        sessionId = UUID.randomUUID().toString();
        try {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                throw new IOException("Audio recording permission was not granted. Choose Record again to allow it.");
            if (source == 0 && Build.VERSION.SDK_INT < 29) throw new IOException("Phone audio recording requires Android 10 or newer.");
            int type = source == 0 ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                    : Build.VERSION.SDK_INT >= 30 ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE : 0;
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION, notification(), type);
            else startForeground(NOTIFICATION, notification());
            if (source == 0) {
                Intent consent = Build.VERSION.SDK_INT >= 33 ? intent.getParcelableExtra("projection_data", Intent.class) : intent.getParcelableExtra("projection_data");
                if (consent == null) throw new IOException("Approve Android's phone audio capture prompt to record.");
                projection = getSystemService(MediaProjectionManager.class).getMediaProjection(intent.getIntExtra("projection_result", 0), consent);
                if (projection == null) throw new IOException("Android did not start the audio capture session.");
                projection.registerCallback(projectionCallback, handler);
            }
            countInRemainingMs = countIn;
            recordingThread = new Thread(() -> capture(countIn), "SoulmansRecorder");
            recordingThread.start(); handler.post(notificationTick);
        } catch (Exception error) { finish(null, error.getMessage()); }
        return START_NOT_STICKY;
    }

    @SuppressLint("MissingPermission") // Checked before the user-started foreground service begins.
    private void capture(int countIn) {
        File draft = null;
        PcmWaveWriter writer = null;
        String failure = null;
        AudioRecord recorder = null;
        try {
            int channels = source == 0 ? 2 : 1;
            int mask = channels == 2 ? AudioFormat.CHANNEL_IN_STEREO : AudioFormat.CHANNEL_IN_MONO;
            int minimum = AudioRecord.getMinBufferSize(rate, mask, AudioFormat.ENCODING_PCM_16BIT);
            if (minimum <= 0) throw new IOException("This device does not support the selected recording quality.");
            AudioFormat format = new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(mask).build();
            AudioRecord.Builder builder = new AudioRecord.Builder().setAudioFormat(format).setBufferSizeInBytes(Math.max(minimum * 2, 16384));
            if (source == 0 && Build.VERSION.SDK_INT >= 29) {
                builder.setAudioPlaybackCaptureConfig(new AudioPlaybackCaptureConfiguration.Builder(projection)
                        .addMatchingUsage(AudioAttributes.USAGE_MEDIA).addMatchingUsage(AudioAttributes.USAGE_GAME)
                        .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN).build());
            } else builder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder = builder.build(); audio = recorder;
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) throw new IOException("The audio input could not be opened. Another recorder may be using it.");
            File directory = RecordingStore.directory(this);
            if (directory.getUsableSpace() < (long) rate * channels * 2 * maxMs / 1000 + 1048576)
                throw new IOException("There is not enough free storage for this recording length.");
            draft = RecordingStore.draft(this, source == 1); writer = new PcmWaveWriter(draft, rate, channels);
            if (!stopRequested) recorder.startRecording();
            short[] samples = new short[Math.max(minimum, 8192) / channels * channels];
            long begin = SystemClock.elapsedRealtime(), lastCheckpoint = begin, frames = 0;
            long maximumFrames = (long) rate * maxMs / 1000;
            while (!stopRequested) {
                int count = recorder.read(samples, 0, samples.length, AudioRecord.READ_BLOCKING);
                if (count < 0) { if (stopRequested) break; throw new IOException("The audio input stopped. Save this take and start a new recording."); }
                if (count == 0) continue;
                count -= count % channels;
                int peak = 0; for (int i = 0; i < count; i++) peak = Math.max(peak, Math.abs((int) samples[i]));
                level = paused ? 0 : peak * 100 / 32768;
                long now = SystemClock.elapsedRealtime(); countInRemainingMs = Math.max(0, begin + countIn - now);
                if (paused || countInRemainingMs > 0) continue;
                count = (int) Math.min(count, (maximumFrames - frames) * channels);
                if (count > 0) { writer.write(samples, count); frames += count / channels; durationMs = frames * 1000 / rate; if (peak > 64) hasSignal = true; }
                if (now - lastCheckpoint >= 1000) { writer.checkpoint(); lastCheckpoint = now; }
                if (frames >= maximumFrames) { saving = true; break; }
            }
        } catch (Exception error) { if (!stopRequested) failure = error.getMessage() == null ? "Recording could not be started on this device." : error.getMessage(); }
        finally {
            saving = true; audio = null; level = 0;
            if (recorder != null) { try { recorder.stop(); } catch (RuntimeException ignored) {} recorder.release(); }
            if (writer != null) { try { writer.close(); } catch (IOException error) { failure = "The recording could not be fully saved: " + error.getMessage(); } }
            File completedDraft = draft; String message = failure;
            handler.post(() -> finish(completedDraft, message));
        }
    }

    boolean isActive() { return recordingThread != null && !finished; }
    void togglePause() { if (!saving && !stopRequested) { paused = !paused; getSystemService(NotificationManager.class).notify(NOTIFICATION, notification()); } }
    void stop(boolean discardTake) {
        if (finished || stopRequested) return;
        discard = discardTake; stopRequested = true; saving = true; paused = false;
        AudioRecord recorder = audio; if (recorder != null) try { recorder.stop(); } catch (RuntimeException ignored) {}
    }

    private void finish(File draft, String error) {
        if (finished) return; finished = true;
        boolean saved = false; String message = error;
        if (discard) { if (draft != null) draft.delete(); message = "Recording discarded."; }
        else if (draft != null && durationMs > 0) {
            try { File file = RecordingStore.finish(draft); RecordingStore.loadPad(prefs, pad, file, durationMs); saved = true;
                message = "Saved take to PAD " + (pad + 1) + (hasSignal ? "" : " · no audio signal detected") + (error == null ? "" : " · " + error); }
            catch (IOException problem) { message = "The take remains in recordings storage but could not be loaded: " + problem.getMessage(); }
        } else { if (draft != null) draft.delete(); if (message == null) message = "No audio was recorded. Wait until the countdown ends before saving."; }
        prefs.edit().putString("recording_completion_id", sessionId == null ? UUID.randomUUID().toString() : sessionId)
                .putString("recording_completion_message", message == null ? "Recording ended." : message)
                .putBoolean("recording_completion_saved", saved).putInt("recording_completion_pad", pad).apply();
        handler.removeCallbacks(notificationTick);
        if (projection != null) { projection.unregisterCallback(projectionCallback); projection.stop(); projection = null; }
        stopForeground(STOP_FOREGROUND_REMOVE); stopSelf();
    }

    private Notification notification() {
        String sourceName = source == 0 ? "Phone audio" : "Microphone";
        String state = saving ? "Saving take…" : countInRemainingMs > 0 ? "Starts in " + ((countInRemainingMs + 999) / 1000) : paused ? "Paused" : "Recording";
        String time = String.format(java.util.Locale.US, "%d:%02d", durationMs / 60000, durationMs / 1000 % 60);
        PendingIntent open = PendingIntent.getActivity(this, 703, new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("open_recorder", true), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = new Notification.Builder(this, CHANNEL).setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Soulmans sampler · " + sourceName).setContentText(state + " · " + time + " · PAD " + (pad + 1))
                .setContentIntent(open).setOngoing(true).setOnlyAlertOnce(true).setCategory(Notification.CATEGORY_SERVICE);
        if (!saving) { builder.addAction(new Notification.Action.Builder(null, paused ? "Resume" : "Pause", action(PAUSE, 704)).build());
            builder.addAction(new Notification.Action.Builder(null, "Save / stop", action(STOP, 705)).build()); }
        return builder.build();
    }
    private PendingIntent action(String action, int request) { return PendingIntent.getService(this, request, new Intent(this, RecordingService.class).setAction(action), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE); }
    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onDestroy() { stop(false); handler.removeCallbacks(notificationTick); if (live == this) live = null; super.onDestroy(); }
}
