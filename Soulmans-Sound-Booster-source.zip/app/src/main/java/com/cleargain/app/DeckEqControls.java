package com.cleargain.app;

import android.content.*;
import android.view.*;
import android.widget.*;

/** Shared working controls for the main rack and floating rack. */
final class DeckEqControls extends LinearLayout {
    private final SharedPreferences prefs;
    private final Switch boost,eq;
    private final SeekBar gain;
    private final TextView gainLabel,preset;
    private final EqBandView bands;
    private boolean syncing;
    DeckEqControls(Context context){
        super(context);setOrientation(VERTICAL);prefs=context.getSharedPreferences("settings",0);EqProfile.ensureDefaults(prefs);
        LinearLayout switches=new LinearLayout(context);boost=toggle("BOOST",switches);eq=toggle("7-BAND EQ",switches);addView(switches,new LayoutParams(-1,dp(44)));
        LinearLayout gainRow=new LinearLayout(context);gainRow.setGravity(Gravity.CENTER_VERTICAL);gainLabel=text("GAIN +4 dB",10);gainRow.addView(gainLabel,new LayoutParams(dp(80),-1));gain=new SeekBar(context);DeckSkin.slider(gain);gain.setMax(12);gain.setContentDescription("Rack boost gain in decibels");gainRow.addView(gain,new LayoutParams(0,-1,1));addView(gainRow,new LayoutParams(-1,dp(40)));
        preset=text("",11);preset.setGravity(Gravity.CENTER);DeckSkin.button(preset);preset.setContentDescription("Cycle equalizer preset");preset.setClickable(true);preset.setFocusable(true);addView(preset,new LayoutParams(-1,dp(44)));
        bands=new EqBandView(context);addView(bands,new LayoutParams(-1,dp(138)));
        boost.setOnCheckedChangeListener((v,on)->{if(!syncing){prefs.edit().putBoolean("player_boost",on).apply();apply();}});
        eq.setOnCheckedChangeListener((v,on)->{if(!syncing){prefs.edit().putBoolean("player_eq",on).apply();apply();}});
        gain.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar v){}public void onStopTrackingTouch(SeekBar v){}public void onProgressChanged(SeekBar v,int value,boolean user){if(user){prefs.edit().putInt("gain_db",value).apply();gainLabel.setText("GAIN +"+value+" dB");apply();}}});
        preset.setOnClickListener(v->{String current=prefs.getString("eq_preset","Bass");int index=-1;for(int i=0;i<EqProfile.PRESETS.length;i++)if(current.equals(EqProfile.PRESETS[i]))index=i;EqProfile.setPreset(prefs,EqProfile.PRESETS[(index+1)%EqProfile.PRESETS.length]);prefs.edit().putBoolean("player_eq",true).apply();sync();apply();});
        bands.setOnChange((i,db)->{EqProfile.setBand(prefs,i,db);prefs.edit().putBoolean("player_eq",true).apply();sync();apply();});sync();
    }
    void sync(){syncing=true;boost.setChecked(prefs.getBoolean("player_boost",false));eq.setChecked(prefs.getBoolean("player_eq",false));if(!gain.isPressed())gain.setProgress(prefs.getInt("gain_db",4));gainLabel.setText("GAIN +"+prefs.getInt("gain_db",4)+" dB");preset.setText("PRESET  ·  "+prefs.getString("eq_preset","Bass").toUpperCase(java.util.Locale.ROOT)+"  ›");bands.setLevels(EqProfile.levels(prefs));syncing=false;}
    private void apply(){if(PlaybackService.live!=null)PlaybackService.live.applySound();}
    private Switch toggle(String label,LinearLayout row){Switch view=new Switch(getContext());view.setText(label);view.setTextSize(10);view.setTextColor(DeckSkin.GOLD);view.setContentDescription("Rack "+label+" switch");view.setThumbTintList(android.content.res.ColorStateList.valueOf(0xffcbd0c3));view.setTrackTintList(android.content.res.ColorStateList.valueOf(0xff526743));LayoutParams p=new LayoutParams(0,-1,1);p.setMargins(dp(2),0,dp(6),0);row.addView(view,p);return view;}
    private TextView text(String value,int size){TextView view=new TextView(getContext());view.setText(value);view.setTextColor(DeckSkin.GOLD);view.setTextSize(size);view.setGravity(Gravity.CENTER_VERTICAL);return view;}
    private int dp(float value){return Math.round(value*getResources().getDisplayMetrics().density);}
}
