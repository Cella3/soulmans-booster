package com.cleargain.app;

import android.app.Activity;
import android.content.*;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.*;
import android.widget.*;
import androidx.media3.ui.PlayerView;
import androidx.media3.session.*;
import androidx.media3.session.MediaController;
import com.google.common.util.concurrent.ListenableFuture;

/** One fullscreen surface survives rotation; playback stays in the shared service. */
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public final class VideoPlayerActivity extends Activity {
    PlayerView video;
    VideoGestureOverlay gestures;
    private MediaController controller;
    private ListenableFuture<MediaController> future;
    private boolean active;
    public void onCreate(Bundle state){
        super.onCreate(state);FloatingPlayerService.hide(this);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);immersive();
        FrameLayout scene=new FrameLayout(this);scene.setBackgroundColor(0xff000000);setContentView(scene);
        video=(PlayerView)getLayoutInflater().inflate(R.layout.mini_video_player,scene,false);video.setUseController(true);video.setControllerShowTimeoutMs(3500);scene.addView(video,new FrameLayout.LayoutParams(-1,-1));
        gestures=VideoGestureOverlay.attach(this,video,()->{if(video.isControllerFullyVisible())video.hideController();else video.showController();},video::showController);
        if(state!=null)gestures.restore(state.getFloat("zoom",1),state.getFloat("panX"),state.getFloat("panY"));else gestures.restore(getIntent().getFloatExtra("zoom",1),getIntent().getFloatExtra("panX",0),getIntent().getFloatExtra("panY",0));
        LinearLayout toolbar=PlayerUi.row(this);toolbar.setBackgroundColor(0xa00b100e);PlayerUi.weighted(toolbar,PlayerUi.button(this,"‹ PLAYER",this::finish),44);PlayerUi.weighted(toolbar,PlayerUi.button(this,"RESET ZOOM",gestures::resetZoom),44);PlayerUi.weighted(toolbar,PlayerUi.button(this,"⚙ SETTINGS",()->VideoSettings.show(this,gestures,this::export)),44);
        FrameLayout.LayoutParams top=new FrameLayout.LayoutParams(-2,PlayerUi.dp(this,48),Gravity.TOP|Gravity.RIGHT);top.width=PlayerUi.dp(this,330);top.setMargins(0,8,8,0);scene.addView(toolbar,top);
    }
    protected void onStart(){super.onStart();active=true;future=new MediaController.Builder(this,new SessionToken(this,new ComponentName(this,PlaybackService.class))).buildAsync();ListenableFuture<MediaController> connecting=future;connecting.addListener(()->{try{if(!active||future!=connecting)return;controller=connecting.get();video.setPlayer(PlaybackService.live==null?controller:PlaybackService.live.player);video.showController();}catch(Exception e){Toast.makeText(this,"Player connection unavailable",Toast.LENGTH_LONG).show();finish();}},this::runOnUiThread);}
    protected void onStop(){active=false;video.setPlayer(null);if(future!=null)MediaController.releaseFuture(future);controller=null;super.onStop();}
    protected void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);b.putFloat("zoom",gestures.zoom());b.putFloat("panX",gestures.panX());b.putFloat("panY",gestures.panY());}
    public void onConfigurationChanged(Configuration c){super.onConfigurationChanged(c);immersive();}
    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);}
    private void export(){startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("edit_video",true));finish();}
}
