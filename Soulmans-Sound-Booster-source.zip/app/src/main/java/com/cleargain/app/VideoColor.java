package com.cleargain.app;

import android.content.SharedPreferences;
import android.graphics.*;
import android.view.*;
import java.util.*;

/** Hardware texture compositing keeps color controls independent of the decoder/surface lifecycle. */
final class VideoColor {
    private static final Map<TextureView,Boolean> views=new WeakHashMap<>();
    static void attach(TextureView view){
        views.put(view,true);apply(view);
        view.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){public void onViewAttachedToWindow(View v){views.put(view,true);apply(view);}public void onViewDetachedFromWindow(View v){views.remove(view);}});
    }
    static void refresh(){for(TextureView view:new ArrayList<>(views.keySet()))if(view!=null)apply(view);}
    private static void apply(TextureView view){
        PlaybackService service=PlaybackService.live;String uri=service==null||service.player==null||service.player.getCurrentMediaItem()==null?"":service.player.getCurrentMediaItem().mediaId;
        SharedPreferences prefs=view.getContext().getSharedPreferences("settings",0);String key=VideoClipPrefs.key(uri);
        float hue=prefs.getInt("video_hue_"+key,0),saturation=prefs.getInt("video_saturation_"+key,0),brightness=prefs.getInt("video_brightness_"+key,0),contrast=prefs.getInt("video_contrast_"+key,0);
        float cos=(float)Math.cos(Math.toRadians(hue)),sin=(float)Math.sin(Math.toRadians(hue)),r=.213f,g=.715f,b=.072f;
        ColorMatrix matrix=new ColorMatrix(new float[]{r+cos*(1-r)-sin*r,g-cos*g-sin*g,b-cos*b+sin*(1-b),0,0,r-cos*r+sin*.143f,g+cos*(1-g)+sin*.140f,b-cos*b-sin*.283f,0,0,r-cos*r-sin*(1-r),g-cos*g+sin*g,b+cos*(1-b)+sin*b,0,0,0,0,0,1,0});
        ColorMatrix sat=new ColorMatrix();sat.setSaturation(Math.max(0,1+saturation/100));matrix.postConcat(sat);
        float scale=1+contrast/100,offset=brightness*2.55f+128*(1-scale);matrix.postConcat(new ColorMatrix(new float[]{scale,0,0,0,offset,0,scale,0,0,offset,0,0,scale,0,offset,0,0,0,1,0}));
        Paint paint=new Paint();if(hue!=0||saturation!=0||brightness!=0||contrast!=0)paint.setColorFilter(new ColorMatrixColorFilter(matrix));view.setLayerPaint(paint);
    }
}
