package com.cleargain.app;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.function.IntConsumer;

final class DjKnobView extends View {
    private final Paint p=new Paint(3);private final String label;private int value;private float downY;private int start;private final IntConsumer change;
    DjKnobView(Context c,String label,int value,IntConsumer change){super(c);this.label=label;this.value=value;this.change=change;setContentDescription(label+" EQ knob, drag vertically");setClickable(true);}
    void value(int value){this.value=value;invalidate();}
    protected void onDraw(Canvas c){float x=getWidth()/2f,y=getHeight()*.43f,r=Math.min(getWidth()*.3f,getHeight()*.3f);p.setShader(new RadialGradient(x-r*.3f,y-r*.3f,r*2,0xff879389,0xff1d2822,Shader.TileMode.CLAMP));c.drawCircle(x,y,r,p);p.setShader(null);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(0xffa98e4a);c.drawArc(x-r-3,y-r-3,x+r+3,y+r+3,135,270,false,p);p.setStyle(Paint.Style.FILL);double a=Math.toRadians(270+value*22.5);p.setColor(DeckSkin.GREEN);p.setStrokeWidth(3);c.drawLine(x+(float)Math.cos(a)*r*.4f,y+(float)Math.sin(a)*r*.4f,x+(float)Math.cos(a)*r*.86f,y+(float)Math.sin(a)*r*.86f,p);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(PlayerUi.dp(getContext(),8));p.setColor(DeckSkin.GOLD);c.drawText(label+" "+(value>0?"+":"")+value,x,getHeight()-2,p);}
    public boolean onTouchEvent(MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){downY=e.getY();start=value;getParent().requestDisallowInterceptTouchEvent(true);}if(e.getAction()==MotionEvent.ACTION_MOVE){int next=Math.max(-6,Math.min(6,start+Math.round((downY-e.getY())/PlayerUi.dp(getContext(),7))));if(next!=value){value=next;change.accept(value);invalidate();}}if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){getParent().requestDisallowInterceptTouchEvent(false);performClick();}return true;}
    public boolean performClick(){super.performClick();return true;}
}
