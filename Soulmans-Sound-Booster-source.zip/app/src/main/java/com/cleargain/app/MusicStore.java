package com.cleargain.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import java.util.*;

/** Device-local library. Persisted document grants survive process and phone restarts. */
final class MusicStore extends SQLiteOpenHelper {
    private static MusicStore instance;
    static synchronized MusicStore get(Context c) {
        if(instance==null) instance=new MusicStore(c.getApplicationContext());
        return instance;
    }
    private final Context context;
    private MusicStore(Context c) { super(c,"soulmans-music.db",null,1); context=c; }
    @Override public void onConfigure(SQLiteDatabase db) { db.setForeignKeyConstraintsEnabled(true); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE tracks(uri TEXT PRIMARY KEY,title TEXT NOT NULL,artist TEXT NOT NULL,duration INTEGER,plays INTEGER DEFAULT 0,last_played INTEGER DEFAULT 0,pitch REAL DEFAULT 0)");
        db.execSQL("CREATE TABLE playlists(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL)");
        db.execSQL("CREATE TABLE entries(list_id INTEGER REFERENCES playlists(id) ON DELETE CASCADE,uri TEXT REFERENCES tracks(uri) ON DELETE CASCADE,position INTEGER,PRIMARY KEY(list_id,position))");
        db.execSQL("CREATE TABLE history(id INTEGER PRIMARY KEY AUTOINCREMENT,uri TEXT REFERENCES tracks(uri) ON DELETE CASCADE,at INTEGER)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) { }
    private Track read(Cursor c) { return new Track(c.getString(0),c.getString(1),c.getString(2),c.getLong(3),c.getInt(4),c.getLong(5),c.getFloat(6)); }
    private List<Track> query(String sql,String...args) {
        List<Track> result=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery(sql,args)) { while(c.moveToNext()) result.add(read(c)); }
        return result;
    }
    List<Track> tracks() { return query("SELECT * FROM tracks ORDER BY title COLLATE NOCASE"); }
    Track track(String uri) { List<Track> t=query("SELECT * FROM tracks WHERE uri=?",uri); return t.isEmpty()?null:t.get(0); }
    List<Track> playlist(long id) { return query("SELECT t.* FROM entries e JOIN tracks t ON e.uri=t.uri WHERE list_id=? ORDER BY position",Long.toString(id)); }
    List<Track> history() { return query("SELECT t.uri,t.title,t.artist,t.duration,t.plays,h.at,t.pitch FROM history h JOIN tracks t ON h.uri=t.uri ORDER BY h.id DESC LIMIT 200"); }
    Map<Long,String> playlists() {
        Map<Long,String> result=new LinkedHashMap<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,name FROM playlists ORDER BY name COLLATE NOCASE",null)) { while(c.moveToNext())result.put(c.getLong(0),c.getString(1)); }
        return result;
    }
    long createPlaylist(String name,List<String> uris) {
        SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();
        try { ContentValues v=new ContentValues(); v.put("name",name); long id=db.insertOrThrow("playlists",null,v);
            for(String uri:uris) addToPlaylist(id,uri);
            db.setTransactionSuccessful();return id;
        } finally { db.endTransaction(); }
    }
    synchronized void addToPlaylist(long id,String uri) {
        SQLiteDatabase db=getWritableDatabase(); int pos=0;
        try(Cursor c=db.rawQuery("SELECT COALESCE(MAX(position),-1)+1 FROM entries WHERE list_id=?",new String[]{""+id})) { if(c.moveToFirst())pos=c.getInt(0); }
        ContentValues v=new ContentValues();v.put("list_id",id);v.put("uri",uri);v.put("position",pos);db.insertOrThrow("entries",null,v);
    }
    void removePlaylistEntry(long id,int index) {
        SQLiteDatabase db=getWritableDatabase();
        db.execSQL("DELETE FROM entries WHERE list_id=? AND position=(SELECT position FROM entries WHERE list_id=? ORDER BY position LIMIT 1 OFFSET ?)",new Object[]{id,id,index});
    }
    void renamePlaylist(long id,String name) { ContentValues v=new ContentValues();v.put("name",name);getWritableDatabase().update("playlists",v,"id=?",new String[]{""+id}); }
    void deletePlaylist(long id) { getWritableDatabase().delete("playlists","id=?",new String[]{""+id}); }
    void removeTrack(String uri) { getWritableDatabase().delete("tracks","uri=?",new String[]{uri}); }
    void clearHistory() { SQLiteDatabase db=getWritableDatabase(); db.beginTransaction();try {db.delete("history",null,null);db.execSQL("UPDATE tracks SET plays=0,last_played=0");db.setTransactionSuccessful();}finally{db.endTransaction();} }
    void played(String uri) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try { long now=System.currentTimeMillis();db.execSQL("UPDATE tracks SET plays=plays+1,last_played=? WHERE uri=?",new Object[]{now,uri});
            ContentValues v=new ContentValues();v.put("uri",uri);v.put("at",now);db.insert("history",null,v);
            db.execSQL("DELETE FROM history WHERE id NOT IN (SELECT id FROM history ORDER BY id DESC LIMIT 200)");db.setTransactionSuccessful();
        } finally {db.endTransaction();}
    }
    void pitch(String uri,float semitones) { ContentValues v=new ContentValues();v.put("pitch",semitones);getWritableDatabase().update("tracks",v,"uri=?",new String[]{uri}); }
    String displayName(Uri uri) {
        try(Cursor c=context.getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)) { if(c!=null&&c.moveToFirst())return c.getString(0); }
        catch(RuntimeException ignored) { }
        String s=uri.getLastPathSegment();return s==null?"Audio track":s;
    }
    Track importTrack(Uri uri) throws Exception {
        String key=uri.toString(); Track existing=track(key);if(existing!=null)return existing;
        // Open first so revoked or unreadable documents are reported at import time.
        try(android.os.ParcelFileDescriptor fd=context.getContentResolver().openFileDescriptor(uri,"r")) { if(fd==null)throw new java.io.IOException("File unavailable"); }
        String title=displayName(uri),artist="Local audio";long duration=0;
        MediaMetadataRetriever r=new MediaMetadataRetriever(); try {
            r.setDataSource(context,uri);
            String t=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE),a=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST),d=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if(t!=null&&!t.trim().isEmpty())title=t;if(a!=null&&!a.trim().isEmpty())artist=a;
            if(d!=null)duration=Long.parseLong(d);
        } catch(Exception ignored) { /* ExoPlayer may decode formats the platform metadata reader cannot. */ } finally { try {r.release();}catch(Exception ignored){} }
        ContentValues v=new ContentValues();v.put("uri",key);v.put("title",title);v.put("artist",artist);v.put("duration",duration);
        getWritableDatabase().insertWithOnConflict("tracks",null,v,SQLiteDatabase.CONFLICT_IGNORE);return track(key);
    }
    interface Progress { void found(int count); }
    List<Uri> folder(Uri tree,Progress progress) {
        List<Uri> files=new ArrayList<>(); ArrayDeque<String> dirs=new ArrayDeque<>();Set<String> visited=new HashSet<>();
        dirs.add(DocumentsContract.getTreeDocumentId(tree));
        while(!dirs.isEmpty()) {
            String id=dirs.removeFirst();if(!visited.add(id))continue;
            Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,id);
            try(Cursor c=context.getContentResolver().query(children,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_DISPLAY_NAME},null,null,null)) {
                if(c==null)continue;
                while(c.moveToNext()) {
                    String child=c.getString(0),mime=c.getString(1),name=c.getString(2);
                    if(DocumentsContract.Document.MIME_TYPE_DIR.equals(mime))dirs.add(child);
                    else if(isAudio(mime,name)) {files.add(DocumentsContract.buildDocumentUriUsingTree(tree,child));progress.found(files.size());}
                }
            }
        }
        return files;
    }
    static boolean isAudio(String mime,String name) {
        return (mime!=null&&mime.startsWith("audio/")) || (name!=null&&name.toLowerCase(Locale.ROOT).matches(".*\\.(mp3|wav|wave|flac|ogg|oga|opus|m4a|m4b|aac|amr|3gp|aif|aiff|ac3|ec3|mp4|webm|mka|mid|midi|wma)$"));
    }
}
