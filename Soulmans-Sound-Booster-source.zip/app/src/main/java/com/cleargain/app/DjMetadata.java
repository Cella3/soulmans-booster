package com.cleargain.app;

import android.content.SharedPreferences;

final class DjMetadata {
    static String suffix(String uri){return VideoClipPrefs.key(uri);}
    static float bpm(SharedPreferences p,String uri){String k=suffix(uri);return p.getFloat("dj_manual_bpm_"+k,p.getFloat("dj_bpm_"+k,0));}
    static String key(SharedPreferences p,String uri){String k=suffix(uri);return p.getString("dj_manual_key_"+k,p.getString("dj_key_"+k,"Not analyzed"));}
    static boolean analyzed(SharedPreferences p,String uri){return p.contains("dj_key_"+suffix(uri));}
    static void save(SharedPreferences p,String uri,DjAnalysis.Result result){String k=suffix(uri);p.edit().putFloat("dj_bpm_"+k,result.bpm()).putString("dj_key_"+k,result.key()).putFloat("dj_confidence_"+k,result.confidence()).putFloat("dj_phase_"+k,(float)result.firstBeatSeconds()).apply();}
}
