package com.cleargain.app;

import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import androidx.media3.common.Effect;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.effect.Presentation;
import androidx.media3.muxer.Mp4Muxer;
import androidx.media3.transformer.DefaultEncoderFactory;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.ProgressHolder;
import androidx.media3.transformer.Transformer;
import androidx.media3.transformer.VideoEncoderSettings;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collections;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Trims and encodes a video into a temporary file, then copies it to the user's SAF location. */
@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
final class VideoClipExporter {
    interface Listener {
        void onFinished(String displayName);
        void onFailed(String reason);
    }

    private final Context context;
    private final ContentResolver resolver;
    private final File temporary;
    private final Transformer transformer;
    private final ProgressHolder progress = new ProgressHolder();
    private boolean cancelled;

    private VideoClipExporter(Context context, Uri source, Uri destination, long startMs, long endMs,
                              int quality, int type, Listener listener) throws Exception {
        this.context = context.getApplicationContext();
        resolver = context.getContentResolver();
        temporary = File.createTempFile("soulmans-video-", type == 1 ? ".3gp" : ".mp4", context.getCacheDir());

        MediaItem input = new MediaItem.Builder()
                .setUri(source)
                .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(startMs).setEndPositionMs(endMs).build())
                .build();
        java.util.List<Effect> videoEffects = Collections.emptyList();
        if (quality == 1) videoEffects = Collections.singletonList(Presentation.createForHeight(1080));
        else if (quality == 2) videoEffects = Collections.singletonList(Presentation.createForHeight(720));
        else if (quality == 3) videoEffects = Collections.singletonList(Presentation.createForHeight(480));
        EditedMediaItem edited = new EditedMediaItem.Builder(input)
                .setEffects(new Effects(Collections.emptyList(), videoEffects))
                .build();

        int bitrate = quality == 3 ? 1_500_000 : quality == 2 ? 4_000_000 : 8_000_000;
        DefaultEncoderFactory encoders = new DefaultEncoderFactory.Builder(context)
                .setRequestedVideoEncoderSettings(new VideoEncoderSettings.Builder().setBitrate(bitrate).build())
                .build();
        Transformer.Builder builder = new Transformer.Builder(context)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setEncoderFactory(encoders);
        if (type == 1) builder.setMuxerFactory(new ThreeGpMuxerFactory());
        transformer = builder.addListener(new Transformer.Listener() {
            @Override public void onCompleted(androidx.media3.transformer.Composition composition, ExportResult result) {
                copyToDestination(destination, listener);
            }

            @Override public void onError(androidx.media3.transformer.Composition composition,
                                          ExportResult result, ExportException error) {
                fail(listener, error.getMessage() == null ? "This video could not be encoded on this device." : error.getMessage());
            }
        }).build();
        transformer.start(edited, temporary.getAbsolutePath());
    }

    static VideoClipExporter start(Context context, Uri source, Uri destination, long startMs, long endMs,
                                   int quality, int type, Listener listener) throws Exception {
        return new VideoClipExporter(context, source, destination, startMs, endMs, quality, type, listener);
    }

    int progressPercent() {
        if (cancelled) return -1;
        try {
            return transformer.getProgress(progress) == Transformer.PROGRESS_STATE_AVAILABLE ? progress.progress : -1;
        } catch (RuntimeException ignored) { return -1; }
    }

    void cancel() {
        cancelled = true;
        try { transformer.cancel(); } catch (RuntimeException ignored) {}
        temporary.delete();
    }

    private void copyToDestination(Uri destination, Listener listener) {
        ExecutorService copier = Executors.newSingleThreadExecutor();
        copier.execute(() -> {
            try (InputStream input = new FileInputStream(temporary);
                 OutputStream output = resolver.openOutputStream(destination, "w")) {
                if (output == null) throw new java.io.IOException("The selected location cannot create a file.");
                byte[] buffer = new byte[64 * 1024];
                int count;
                while ((count = input.read(buffer)) >= 0) if (count > 0) output.write(buffer, 0, count);
                temporary.delete();
                new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                    if (!cancelled) listener.onFinished(destination.getLastPathSegment());
                });
            } catch (Exception e) {
                fail(listener, e.getMessage() == null ? "Could not save to that location." : e.getMessage());
            } finally { copier.shutdown(); }
        });
    }

    private void fail(Listener listener, String reason) {
        temporary.delete();
        new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
            if (!cancelled) listener.onFailed(reason);
        });
    }
}
