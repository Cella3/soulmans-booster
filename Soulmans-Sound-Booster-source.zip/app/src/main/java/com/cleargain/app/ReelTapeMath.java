package com.cleargain.app;

/** Tape length is proportional to the area of the pack around its hub. */
final class ReelTapeMath {
    private ReelTapeMath() {}
    static double progress(long position, long duration) {
        return duration <= 0 ? 0 : Math.max(0, Math.min(1, position / (double) duration));
    }
    static float packRadius(double fraction, float hub, float full) {
        double amount = Double.isFinite(fraction) ? Math.max(0, Math.min(1, fraction)) : 0;
        return (float) Math.sqrt(hub * hub + amount * (full * full - hub * hub));
    }
}
