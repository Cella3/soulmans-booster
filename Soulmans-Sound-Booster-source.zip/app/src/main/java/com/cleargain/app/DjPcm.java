package com.cleargain.app;

import java.io.*;
import java.nio.*;
import java.nio.channels.FileChannel;

/** Disk-backed stereo PCM: long tracks do not occupy a giant Java heap array. */
final class DjPcm implements AutoCloseable {
    final File file;
    final int rate,frames;
    final float[] peaks=new float[2048];
    private final RandomAccessFile reader;
    private final ByteBuffer data;
    DjPcm(File file,int rate)throws IOException{
        this.file=file;this.rate=rate;reader=new RandomAccessFile(file,"r");frames=(int)(reader.length()/4);
        if(frames==0){reader.close();throw new IOException("No decoded audio samples");}
        data=reader.getChannel().map(FileChannel.MapMode.READ_ONLY,0,frames*4L).order(ByteOrder.LITTLE_ENDIAN);
        for(int i=0;i<frames;i+=Math.max(1,rate/8000)){int bin=(int)((long)i*peaks.length/frames);peaks[bin]=Math.max(peaks[bin],Math.max(Math.abs(sample(i,0)),Math.abs(sample(i,1))));}
    }
    float sample(int frame,int channel){if(frame<0||frame>=frames)return 0;return data.getShort(frame*4+channel*2)/32768f;}
    float interpolated(double position,int channel){int frame=(int)Math.floor(position);float f=(float)(position-frame);return sample(frame,channel)*(1-f)+sample(frame+1,channel)*f;}
    long duration(){return frames*1000L/rate;}
    public void close(){try{reader.close();}catch(IOException ignored){}file.delete();}
}
