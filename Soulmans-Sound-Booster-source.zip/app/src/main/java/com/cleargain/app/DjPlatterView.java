package com.cleargain.app;

import android.content.Context;
import android.graphics.*;
import android.view.*;

/** Own-brand silver direct-drive deck, with touch-driven bidirectional audio scratching. */
final class DjPlatterView extends View {
    interface Scratch{void begin();void move(double seconds);void end();}
    private final Paint paint=new Paint(3);private Scratch scratch;private double angle,lastTouch;private boolean touched;private int accent=0xff71dfcf;private float peak;
    DjPlatterView(Context c){super(c);setContentDescription("Scratch turntable: hold vinyl and rotate forward or backward");setClickable(true);}
    void listener(Scratch listener){scratch=listener;}
    void state(double seconds,float peak,int accent){if(!touched)angle=seconds/1.8*360;this.peak=peak;this.accent=accent;invalidate();}
    protected void onDraw(Canvas c){float w=getWidth(),h=getHeight(),r=Math.min(w*.39f,h*.47f),x=w*.46f,y=h*.5f;
        paint.setShader(new LinearGradient(0,0,w,h,new int[]{0xff929d9c,0xff394442,0xff151d1b},null,Shader.TileMode.CLAMP));c.drawRoundRect(2,2,w-2,h-2,8,8,paint);paint.setShader(null);
        for(int i=5;i<h;i+=4){paint.setColor(0x166f8b85);c.drawLine(4,i,w-4,i,paint);}
        paint.setColor(0xffc0a34e);c.drawCircle(x,y,r,paint);paint.setColor(0xffd8e4df);c.drawCircle(x,y,r-3,paint);
        paint.setColor(0xff090c0d);c.drawCircle(x,y,r-9,paint);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1);
        for(float g=r*.3f;g<r-10;g+=3){paint.setColor(0xff263230);c.drawCircle(x,y,g,paint);}paint.setStyle(Paint.Style.FILL);
        c.save();c.rotate((float)angle,x,y);paint.setColor(accent);c.drawCircle(x,y,r*.3f,paint);paint.setColor(0xff091514);paint.setTextSize(r*.13f);paint.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));paint.setTextAlign(Paint.Align.CENTER);c.drawText("SOULMAN",x,y,paint);paint.setColor(0xfff4e7b5);c.drawRect(x-2,y-r+12,x+2,y-r*.36f,paint);c.restore();
        paint.setColor(0xffbfcac6);c.drawCircle(x,y,3,paint);paint.setStrokeWidth(5);c.drawLine(w*.88f,h*.15f,w*.82f,h*.7f,paint);c.drawLine(w*.82f,h*.7f,w*.68f,h*.82f,paint);paint.setColor(0xff252e2b);c.drawCircle(w*.88f,h*.15f,9,paint);paint.setColor(accent);c.drawRect(12,h-18,42,h-9,paint);paint.setColor(peak>.9?0xffff7373:accent);c.drawCircle(w-15,h-15,4+peak*2,paint);
    }
    private double angle(MotionEvent e){return Math.toDegrees(Math.atan2(e.getY()-getHeight()*.5,e.getX()-getWidth()*.46));}
    public boolean onTouchEvent(MotionEvent e){switch(e.getActionMasked()){
        case MotionEvent.ACTION_DOWN:touched=true;lastTouch=angle(e);getParent().requestDisallowInterceptTouchEvent(true);if(scratch!=null)scratch.begin();return true;
        case MotionEvent.ACTION_MOVE:double current=angle(e),delta=current-lastTouch;while(delta>180)delta-=360;while(delta< -180)delta+=360;angle+=delta;lastTouch=current;if(scratch!=null)scratch.move(delta/360*1.8);invalidate();return true;
        case MotionEvent.ACTION_UP:case MotionEvent.ACTION_CANCEL:touched=false;getParent().requestDisallowInterceptTouchEvent(false);if(scratch!=null)scratch.end();performClick();return true;
    }return true;}
    public boolean performClick(){super.performClick();return true;}
}
