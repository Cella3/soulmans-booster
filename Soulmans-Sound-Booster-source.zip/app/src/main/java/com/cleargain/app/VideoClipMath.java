package com.cleargain.app;

/** Millisecond/fraction mapping shared by the video trim controls and tests. */
final class VideoClipMath {
    private VideoClipMath() {}

    static long fromProgress(int progress, long durationMs) {
        if (durationMs <= 0) return 0;
        int clamped = Math.max(0, Math.min(1000, progress));
        return Math.round(durationMs * (clamped / 1000.0));
    }

    static int toProgress(long positionMs, long durationMs) {
        if (durationMs <= 0) return 0;
        long clamped = Math.max(0, Math.min(durationMs, positionMs));
        return (int) Math.round(1000.0 * clamped / durationMs);
    }

    static long[] normalize(long startMs, long endMs, long durationMs) {
        if (durationMs <= 0) return new long[]{0, 0};
        long gap = Math.min(1000, durationMs);
        long start = Math.max(0, Math.min(durationMs - gap, startMs));
        long end = Math.max(start + gap, Math.min(durationMs, endMs));
        return new long[]{start, end};
    }
}
