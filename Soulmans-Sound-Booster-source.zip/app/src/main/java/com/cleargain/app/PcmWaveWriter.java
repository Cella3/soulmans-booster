package com.cleargain.app;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

/** Streams 16-bit PCM to disk so recording length does not increase memory usage. */
final class PcmWaveWriter implements Closeable {
    private final RandomAccessFile output;
    private final int rate, channels;
    private long dataBytes;
    private boolean closed;
    private byte[] block = new byte[0];

    PcmWaveWriter(File file, int rate, int channels) throws IOException {
        if (rate < 8000 || rate > 192000 || channels < 1 || channels > 2)
            throw new IllegalArgumentException("Unsupported recording format");
        this.rate = rate;
        this.channels = channels;
        output = new RandomAccessFile(file, "rw");
        output.setLength(0);
        header(output, 0, rate, channels);
    }

    void write(short[] samples, int count) throws IOException {
        if (closed) throw new IOException("The WAV recording is closed");
        if (count < 0 || count > samples.length || count % channels != 0)
            throw new IllegalArgumentException("Write complete PCM frames");
        if (dataBytes + count * 2L > 0xffffffffL - 36)
            throw new IOException("The recording has reached the WAV size limit");
        if (block.length < count * 2) block = new byte[count * 2];
        for (int i = 0; i < count; i++) {
            block[i * 2] = (byte) samples[i];
            block[i * 2 + 1] = (byte) (samples[i] >>> 8);
        }
        output.write(block, 0, count * 2);
        dataBytes += count * 2L;
    }

    long durationMs() { return dataBytes * 1000 / (rate * channels * 2L); }

    void checkpoint() throws IOException {
        output.seek(0);
        header(output, dataBytes, rate, channels);
        output.seek(44 + dataBytes);
    }

    @Override public void close() throws IOException {
        if (closed) return;
        try { checkpoint(); output.getFD().sync(); }
        finally { closed = true; output.close(); }
    }

    static long durationMs(File file) throws IOException {
        try (RandomAccessFile input = new RandomAccessFile(file, "r")) {
            int[] format = readFormat(input);
            return Math.max(0, input.length() - 44) * 1000 / (format[0] * format[1] * 2L);
        }
    }

    /** Recovers a draft if Android terminated the process during recording. */
    static void repair(File file) throws IOException {
        try (RandomAccessFile input = new RandomAccessFile(file, "rw")) {
            int[] format = readFormat(input);
            int frameBytes = format[1] * 2;
            long bytes = (input.length() - 44) / frameBytes * frameBytes;
            input.setLength(44 + bytes);
            input.seek(0);
            header(input, bytes, format[0], format[1]);
        }
    }

    private static int[] readFormat(RandomAccessFile input) throws IOException {
        if (input.length() < 44) throw new IOException("Incomplete WAV recording");
        input.seek(0);
        if (input.readInt() != 0x52494646) throw new IOException("Invalid WAV recording");
        input.seek(8);
        if (input.readInt() != 0x57415645) throw new IOException("Invalid WAV recording");
        input.seek(20);
        int encoding = le16(input), channels = le16(input), rate = le32(input);
        input.seek(34);
        if (encoding != 1 || le16(input) != 16 || channels < 1 || channels > 2 || rate < 8000 || rate > 192000)
            throw new IOException("Unsupported WAV recording");
        return new int[]{rate, channels};
    }

    private static void header(RandomAccessFile out, long bytes, int rate, int channels) throws IOException {
        out.writeBytes("RIFF"); le32(out, 36 + bytes); out.writeBytes("WAVEfmt ");
        le32(out, 16); le16(out, 1); le16(out, channels); le32(out, rate);
        le32(out, rate * channels * 2L); le16(out, channels * 2); le16(out, 16);
        out.writeBytes("data"); le32(out, bytes);
    }
    private static void le16(RandomAccessFile out, int value) throws IOException { out.write(value & 255); out.write(value >>> 8 & 255); }
    private static void le32(RandomAccessFile out, long value) throws IOException { for (int i = 0; i < 4; i++) out.write((int) (value >>> (i * 8)) & 255); }
    private static int le16(RandomAccessFile in) throws IOException { return in.readUnsignedByte() | in.readUnsignedByte() << 8; }
    private static int le32(RandomAccessFile in) throws IOException { return le16(in) | le16(in) << 16; }
}
