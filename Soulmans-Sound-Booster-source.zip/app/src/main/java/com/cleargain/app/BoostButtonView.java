package com.cleargain.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

final class BoostButtonView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private boolean active;

    BoostButtonView(Context context) {
        super(context);
        setClickable(true);
        setActive(false);
    }

    void setActive(boolean active) {
        this.active = active;
        setContentDescription(active ? "Turn boost off" : "Turn boost on");
        invalidate();
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float x = getWidth() / 2f;
        float y = getHeight() / 2f;
        float radius = Math.min(x, y) - dp(5);

        paint.setShader(null);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(active ? 0x44ff3d27 : 0x44333e4c);
        canvas.drawCircle(x, y, radius, paint);
        paint.setColor(0xff090d18);
        canvas.drawCircle(x, y, radius - dp(7), paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(5));
        paint.setColor(active ? 0xffff492f : 0xff66717d);
        canvas.drawCircle(x, y, radius - dp(11), paint);
        paint.setStrokeWidth(dp(2));
        paint.setColor(active ? 0xffffc163 : 0xff8b929d);
        canvas.drawCircle(x, y, radius - dp(17), paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new RadialGradient(x, y, radius - dp(18),
                active ? new int[]{0xff382033, 0xff0c101b} : new int[]{0xff1d2733, 0xff0c101b},
                null, Shader.TileMode.CLAMP));
        canvas.drawCircle(x, y, radius - dp(19), paint);
        paint.setShader(null);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD_ITALIC));
        paint.setColor(active ? 0xffffc257 : 0xffeef4f6);
        paint.setTextSize(dp(28));
        canvas.drawText("BOOST", x, y + dp(3), paint);
        paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        paint.setTextSize(dp(11));
        paint.setColor(active ? 0xff7dffeb : 0xffaebdc5);
        canvas.drawText(active ? "ON" : "OFF", x, y + dp(22), paint);
    }
}
