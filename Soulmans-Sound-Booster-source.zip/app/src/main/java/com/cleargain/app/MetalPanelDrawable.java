package com.cleargain.app;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.Drawable;

/** Brushed aluminum inside a polished, beveled gold frame. Resolution independent. */
final class MetalPanelDrawable extends Drawable {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density, radius;
    private final boolean trim;
    private int alpha = 255;
    MetalPanelDrawable(Context context, float radiusDp, boolean trim) {
        density = context.getResources().getDisplayMetrics().density;
        radius = radiusDp * density; this.trim = trim;
    }
    @Override public void draw(Canvas canvas) {
        Rect bounds = getBounds(); if (bounds.isEmpty()) return;
        RectF outside = new RectF(bounds), face = new RectF(bounds);
        float edge = (trim ? 3.5f : 1.2f) * density;
        paint.setAlpha(alpha);
        paint.setShader(new LinearGradient(outside.left, outside.top, outside.right, outside.bottom,
                new int[]{0xff594018, 0xfff9d985, 0xffa2782c, 0xffffebad, 0xff7a561e},
                new float[]{0, .22f, .48f, .72f, 1}, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(outside, radius, radius, paint);
        face.inset(edge, edge);
        paint.setShader(new LinearGradient(face.left, face.top, face.right, face.top + Math.min(face.height(), 180 * density),
                new int[]{0xffc5c9cc, 0xfff4f5f4, 0xffaeb4b8, 0xffe2e5e5, 0xffbac0c4},
                new float[]{0, .25f, .5f, .72f, 1}, Shader.TileMode.MIRROR));
        canvas.drawRoundRect(face, Math.max(0, radius - edge), Math.max(0, radius - edge), paint);
        int save = canvas.save();
        Path clip = new Path(); clip.addRoundRect(face, Math.max(0, radius - edge), Math.max(0, radius - edge), Path.Direction.CW); canvas.clipPath(clip);
        paint.setShader(null); paint.setStrokeWidth(Math.max(.5f, .3f * density));
        for (float y = face.top; y < face.bottom; y += .9f * density) {
            paint.setColor(((int) ((y - face.top) / density) % 3 == 0) ? 0x18ffffff : 0x0b28323b);
            canvas.drawLine(face.left, y, face.right, y, paint);
        }
        canvas.restoreToCount(save);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(.75f * density); paint.setColor(0xfffff2c7);
        RectF highlight = new RectF(outside); highlight.inset(density, density);
        canvas.drawRoundRect(highlight, Math.max(0, radius - density), Math.max(0, radius - density), paint);
        paint.setStyle(Paint.Style.FILL); paint.setAlpha(255);
    }
    @Override public void getOutline(Outline outline) { outline.setRoundRect(getBounds(), radius); }
    @Override public void setAlpha(int value) { alpha = value; invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter filter) { paint.setColorFilter(filter); invalidateSelf(); }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
