package com.cleargain.app;

import androidx.media3.common.C;
import androidx.media3.common.audio.BaseAudioProcessor;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
final class SoundProcessor extends BaseAudioProcessor {
    static final class Settings {
        final float boost;final int[] eq;final boolean enabled;
        Settings(float boost,int[] eq,boolean enabled){this.boost=boost;this.eq=eq.clone();this.enabled=enabled;}
    }
    volatile Settings settings=new Settings(0,new int[7],false);
    volatile float[] spectrum=new float[32];
    volatile float[] waveform=new float[128];
    volatile long capturedAt;
    private Settings applied;
    private final DspEngine engine=new DspEngine();
    private int channels,rate,frames;
    private final float[] capture=new float[512];
    @Override public AudioFormat onConfigure(AudioFormat f) throws UnhandledAudioFormatException {
        if(f.encoding!=C.ENCODING_PCM_16BIT)throw new UnhandledAudioFormatException(f);
        channels=f.channelCount;rate=f.sampleRate;applied=null;return f;
    }
    @Override public void queueInput(ByteBuffer input) {
        Settings s=settings;
        if(applied!=s){engine.configure(rate,channels,s.boost,s.eq,s.enabled);applied=s;}
        ByteBuffer out=replaceOutputBuffer(input.remaining()).order(ByteOrder.nativeOrder());
        input.order(ByteOrder.nativeOrder());
        while(input.remaining()>=channels*2) {
            float mono=0;
            for(int c=0;c<channels;c++) {float y=engine.process(input.getShort()/32768f,c);mono+=y;out.putShort((short)Math.max(-32768,Math.min(32767,Math.round(y*32767))));}
            capture[frames++]=mono/channels;
            if(frames==capture.length) {frames=0;if(android.os.SystemClock.elapsedRealtime()-capturedAt>=33)analyse();}
        }
        out.flip();
    }
    private void analyse() {
        float[] wave=new float[128],bars=new float[32];
        for(int i=0;i<128;i++)wave[i]=capture[i*4];
        // Log-spaced Goertzel frequency analysis of the actual decoded music.
        for(int b=0;b<32;b++) {
            double freq=55*Math.pow(Math.min(16000,rate*.45)/55.0,b/31.0),k=2*Math.cos(2*Math.PI*freq/rate),q0,q1=0,q2=0;
            for(int n=0;n<512;n++){q0=capture[n]*(.5-.5*Math.cos(2*Math.PI*n/511))+k*q1-q2;q2=q1;q1=q0;}
            double mag=Math.sqrt(Math.max(0,q1*q1+q2*q2-k*q1*q2))/128;
            bars[b]=(float)Math.min(1,Math.log1p(mag*35)/3.58);
        }
        waveform=wave;spectrum=bars;capturedAt=android.os.SystemClock.elapsedRealtime();
    }
    @Override protected void onFlush(){frames=0;engine.reset();}
    @Override protected void onReset(){spectrum=new float[32];waveform=new float[128];applied=null;}
}
