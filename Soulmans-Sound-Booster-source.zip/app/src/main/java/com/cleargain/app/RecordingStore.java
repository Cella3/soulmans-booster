package com.cleargain.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

final class RecordingStore {
    private RecordingStore() {}

    static File directory(Context context) throws IOException {
        File directory = new File(context.getFilesDir(), "recordings");
        if (!directory.isDirectory() && !directory.mkdirs()) throw new IOException("Could not create the recordings folder");
        return directory;
    }

    static File draft(Context context, boolean microphone) throws IOException {
        String stamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(new Date());
        return new File(directory(context), "Soulmans-" + (microphone ? "Mic-" : "Phone-") + stamp + "-" + UUID.randomUUID().toString().substring(0, 8) + ".wav.part");
    }

    static File finish(File draft) throws IOException {
        File target = new File(draft.getParentFile(), draft.getName().substring(0, draft.getName().length() - 5));
        if (!draft.renameTo(target)) throw new IOException("Could not finish saving this take");
        return target;
    }

    static File[] takes(Context context) throws IOException {
        File[] files = directory(context).listFiles((folder, name) -> name.endsWith(".wav"));
        if (files == null) return new File[0];
        Arrays.sort(files, Comparator.comparingLong(File::lastModified).reversed());
        return files;
    }

    static void recover(Context context) {
        if (RecordingService.live != null) return;
        try {
            File[] drafts = directory(context).listFiles((folder, name) -> name.endsWith(".wav.part"));
            if (drafts != null) for (File draft : drafts) {
                try { if (draft.length() > 44) { PcmWaveWriter.repair(draft); finish(draft); } }
                catch (IOException ignored) { /* Keep the draft for recovery rather than deleting it. */ }
            }
        } catch (IOException ignored) {}
    }

    static void loadPad(SharedPreferences prefs, int pad, File file, long duration) {
        int milliseconds = (int) Math.min(Integer.MAX_VALUE, duration);
        prefs.edit().putString("pad_uri_" + pad, Uri.fromFile(file).toString())
                .putString("pad_name_" + pad, file.getName()).putInt("pad_duration_" + pad, milliseconds)
                .putInt("pad_start_" + pad, 0).putInt("pad_end_" + pad, milliseconds)
                .putInt("pad_pitch_" + pad, 0).putInt("pad_fade_in_" + pad, 0).putInt("pad_fade_out_" + pad, 0)
                .putInt("pad_echo_" + pad, 0).putBoolean("pad_loop_" + pad, false).putInt("pad_trigger_" + pad, 0).apply();
    }
}
