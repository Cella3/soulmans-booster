package com.cleargain.app;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.*;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;
import androidx.media3.common.*;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.media3.ui.PlayerView;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.Locale;

/** A movable media window controlling the existing playback session; no second decoder or queue. */
@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
public final class FloatingPlayerService extends Service {
    static final String OPEN = "com.cleargain.app.MINI_OPEN", CLOSE = "com.cleargain.app.MINI_CLOSE";
    static FloatingPlayerService live;
    private static final int NOTICE = 804, CYAN = MetalSkin.GOLD, WHITE = MetalSkin.INK, MUTED = MetalSkin.MUTED;
    private static final String CHANNEL = "mini-player";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private WindowManager manager;
    private AudioManager audio;
    private MediaController controller;
    private ListenableFuture<MediaController> connection;
    LinearLayout window;
    WindowManager.LayoutParams windowParams;
    private LinearLayout body;
    private FrameLayout display;
    private TextView title, clock, status, play, headerPlay, fold;
    private SeekBar seek, volume;
    private PlayerView videoView;
    private VideoGestureOverlay videoGesture;
    private MiniScopeView scope;
    private LinearLayout musicScene;
    private ReelToReelView reels;
    private Rect bounds;
    private boolean attached, destroyed, folded, video, seeking;
    private String notificationTitle = "";
    private final Runnable tick = new Runnable() {
        @Override public void run() { if (!destroyed) { refresh(); handler.postDelayed(this, 200); } }
    };
    private final Player.Listener listener = new Player.Listener() {
        @Override public void onEvents(Player player, Player.Events events) { refresh(); }
    };

    static boolean isOpen() { return live != null && !live.destroyed; }
    static void hide(Context context) { if (live != null) live.close(); else context.stopService(new Intent(context, FloatingPlayerService.class)); }

    @Override public void onCreate() {
        super.onCreate(); live = this; prefs = getSharedPreferences("settings", MODE_PRIVATE);
        manager = getSystemService(WindowManager.class); audio = getSystemService(AudioManager.class);
        getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel(CHANNEL, "Floating player", NotificationManager.IMPORTANCE_LOW));
    }
    @Override public int onStartCommand(Intent intent, int flags, int id) {
        if (intent == null || CLOSE.equals(intent.getAction())) { close(); return START_NOT_STICKY; }
        if (!Settings.canDrawOverlays(this)) { toast("Allow Display over other apps to open the mini player."); close(); return START_NOT_STICKY; }
        if (window != null) return START_NOT_STICKY;
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTICE, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        else startForeground(NOTICE, notification());
        try {
            buildWindow();
            connection = new MediaController.Builder(this, new SessionToken(this, new ComponentName(this, PlaybackService.class)))
                    .setListener(new MediaController.Listener() { @Override public void onDisconnected(MediaController controller) { if (!destroyed) close(); } }).buildAsync();
            connection.addListener(() -> {
                if (destroyed) return;
                try { controller = connection.get(); controller.addListener(listener); refresh(); }
                catch (Exception error) { toast("Could not connect the mini player. Reopen it from Now Playing."); close(); }
            }, runnable -> handler.post(runnable));
            handler.post(tick);
        } catch (RuntimeException error) { toast("Android could not display the mini player. Check Display over other apps permission."); close(); }
        return START_NOT_STICKY;
    }

    private void buildWindow() {
        bounds = screenBounds();
        window = new LinearLayout(this); window.setOrientation(LinearLayout.VERTICAL); window.setPadding(dp(6), dp(6), dp(6), dp(6));
        window.setBackground(new MetalPanelDrawable(this, 9, true)); window.setElevation(dp(12)); window.setClipToOutline(true);
        LinearLayout bar = row(); bar.setBackground(new MetalPanelDrawable(this, 5, false));
        TextView grip = text("Soulman's Media Player", 18, CYAN); grip.setTypeface(MetalSkin.nameplate(this)); grip.setPadding(dp(5), 0, 0, 0); grip.setSingleLine(true); grip.setAutoSizeTextTypeUniformWithConfiguration(10,18,1,android.util.TypedValue.COMPLEX_UNIT_SP);
        grip.setContentDescription("Drag title bar to move the mini player"); grip.setOnTouchListener(move(false)); bar.addView(grip, new LinearLayout.LayoutParams(0, -1, 1));
        headerPlay = control("▶", "Play", this::togglePlay); headerPlay.setVisibility(View.GONE); bar.addView(headerPlay, new LinearLayout.LayoutParams(dp(28), -1));
        fold = control("▁", "Collapse mini player", this::toggleFold); bar.addView(fold, new LinearLayout.LayoutParams(dp(28), -1));
        bar.addView(control("↗", "Return to full player", () -> openFull(0)), new LinearLayout.LayoutParams(dp(28), -1));
        bar.addView(control("×", "Close mini player; keep playback running", this::close), new LinearLayout.LayoutParams(dp(28), -1));
        window.addView(bar, new LinearLayout.LayoutParams(-1, dp(32)));
        body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); window.addView(body);
        title = text("Connecting to your music…", 10, WHITE); title.setSingleLine(true); title.setEllipsize(TextUtils.TruncateAt.MARQUEE); title.setMarqueeRepeatLimit(-1); title.setSelected(true); title.setPadding(dp(4), 0, dp(4), 0);
        body.addView(title, new LinearLayout.LayoutParams(-1, dp(24)));
        display = new FrameLayout(this); display.setBackground(edge(0xff06101c, 0xff345674)); display.setPadding(dp(1), dp(1), dp(1), dp(1)); display.setClipToOutline(true);
        musicScene = new LinearLayout(this); musicScene.setOrientation(LinearLayout.VERTICAL);
        reels = new ReelToReelView(this); musicScene.addView(reels, new LinearLayout.LayoutParams(-1,0,1));
        scope = new MiniScopeView(this); musicScene.addView(scope, new LinearLayout.LayoutParams(-1,dp(40)));
        display.addView(musicScene, new FrameLayout.LayoutParams(-1, -1));
        videoView = (PlayerView) LayoutInflater.from(this).inflate(R.layout.mini_video_player, display, false);
        videoView.setContentDescription("Mini video; pinch to zoom, drag to frame, double tap to reset"); videoView.setVisibility(View.GONE); display.addView(videoView);
        View frame = videoView.findViewById(androidx.media3.ui.R.id.exo_content_frame);
        if (frame instanceof ViewGroup) { videoGesture = new VideoGestureOverlay(this, frame, () -> {}); ((ViewGroup) frame).addView(videoGesture, new FrameLayout.LayoutParams(-1, -1)); }
        body.addView(display, new LinearLayout.LayoutParams(-1, dp(150)));
        LinearLayout readout = row(); clock = text("0:00 / 0:00", 9, CYAN); clock.setPadding(dp(4), 0, 0, 0); readout.addView(clock, new LinearLayout.LayoutParams(0, -1, 1));
        status = text("CONNECTING", 7, MUTED); status.setSingleLine(true); status.setEllipsize(TextUtils.TruncateAt.END); status.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL); status.setPadding(0, 0, dp(4), 0); readout.addView(status, new LinearLayout.LayoutParams(0, -1, 1));
        body.addView(readout, new LinearLayout.LayoutParams(-1, dp(18)));
        seek = slider("Mini player position"); seek.setMax(1000); body.addView(seek, new LinearLayout.LayoutParams(-1, dp(20)));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar view) { seeking = true; }
            @Override public void onProgressChanged(SeekBar view, int position, boolean user) { if (user && controller != null && controller.getDuration() > 0) clock.setText(time(controller.getDuration() * position / 1000) + " / " + time(controller.getDuration())); }
            @Override public void onStopTrackingTouch(SeekBar view) { if (controller != null && controller.getDuration() > 0 && controller.isCurrentMediaItemSeekable()) controller.seekTo(controller.getDuration() * view.getProgress() / 1000); seeking = false; }
        });
        LinearLayout transport = row();
        transport.addView(transport("|◀", "Previous track", () -> { if (controller != null) controller.seekToPrevious(); }), weight());
        play = transport("▶", "Play", this::togglePlay); play.setTextColor(CYAN); transport.addView(play, weight());
        transport.addView(transport("▶|", "Next track", () -> { if (controller != null) controller.seekToNext(); }), weight());
        transport.addView(transport("SOUND", "Open booster and equalizer", () -> openFull(2)), weight()); body.addView(transport, new LinearLayout.LayoutParams(-1, dp(38)));
        LinearLayout footer = row(); footer.addView(text("VOL", 8, MUTED), new LinearLayout.LayoutParams(dp(30), -1));
        volume = slider("Mini player device volume"); volume.setMax(audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)); volume.setEnabled(!audio.isVolumeFixed()); volume.setProgress(audio.getStreamVolume(AudioManager.STREAM_MUSIC)); footer.addView(volume, new LinearLayout.LayoutParams(0, -1, 1));
        volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar view) {}
            @Override public void onStopTrackingTouch(SeekBar view) {}
            @Override public void onProgressChanged(SeekBar view, int value, boolean user) { if (user) try { audio.setStreamVolume(AudioManager.STREAM_MUSIC, value, 0); } catch (SecurityException error) { toast("Use your phone's volume buttons for this output."); } }
        });
        TextView resize = text("◢", 19, CYAN); resize.setGravity(Gravity.CENTER); resize.setContentDescription("Drag corner sideways to resize mini player"); resize.setOnTouchListener(move(true)); footer.addView(resize, new LinearLayout.LayoutParams(dp(32), -1)); body.addView(footer, new LinearLayout.LayoutParams(-1, dp(26)));
        int width = clampWidth(dp(prefs.getFloat("mini_width", 320f)));
        windowParams = new WindowManager.LayoutParams(width, height(width), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT);
        windowParams.gravity = Gravity.TOP | Gravity.LEFT; windowParams.setTitle("Soulman's Media Player"); restorePosition();
        manager.addView(window, windowParams); attached = true;
    }

    private void refresh() {
        if (destroyed || window == null) return;
        if (!Settings.canDrawOverlays(this)) { close(); return; }
        if (controller == null) return;
        MediaItem item = controller.getCurrentMediaItem();
        boolean nextVideo = item != null && (controller.getCurrentTracks().isTypeSupported(C.TRACK_TYPE_VIDEO) || (item.localConfiguration != null && MusicStore.isVideo(item.localConfiguration.mimeType, item.localConfiguration.uri.toString())));
        if (nextVideo != video) { video = nextVideo; if (videoGesture != null) videoGesture.resetZoom(); resizeWindow(windowParams.width); }
        if (video && !folded) { musicScene.setVisibility(View.GONE); videoView.setVisibility(View.VISIBLE); if (videoView.getPlayer() != controller) videoView.setPlayer(controller); }
        else { videoView.setPlayer(null); videoView.setVisibility(View.GONE); musicScene.setVisibility(View.VISIBLE); }
        CharSequence name = controller.getMediaMetadata().title;
        String caption = item == null ? "Choose music or video in the full player" : name == null ? "Soulmans media" : name.toString(); title.setText(caption);
        if (!caption.equals(notificationTitle)) { notificationTitle = caption; getSystemService(NotificationManager.class).notify(NOTICE, notification()); }
        boolean playing = controller.isPlaying(); String state = item == null ? "NO TRACK" : controller.getPlayerError() != null ? "FILE ERROR" : controller.getPlaybackState() == Player.STATE_BUFFERING ? "LOADING" : playing ? "PLAYING" : "PAUSED";
        status.setText((video ? "VIDEO" : "AUDIO") + " · " + state + (item == null ? "" : " · " + (controller.getCurrentMediaItemIndex() + 1) + "/" + controller.getMediaItemCount()));
        String action = playing ? "Ⅱ" : "▶"; play.setText(action); headerPlay.setText(action); play.setContentDescription(playing ? "Pause" : "Play"); headerPlay.setContentDescription(playing ? "Pause" : "Play");
        long duration = controller.getDuration(); seek.setEnabled(duration > 0 && duration != C.TIME_UNSET && controller.isCurrentMediaItemSeekable());
        if (!seeking) { seek.setProgress(duration > 0 ? (int) (1000 * controller.getCurrentPosition() / duration) : 0); clock.setText(time(controller.getCurrentPosition()) + " / " + time(duration)); }
        scope.state(PlaybackService.live == null ? null : PlaybackService.live.processor, playing && !folded && !video);
        reels.state(item==null?"":item.mediaId, controller.getCurrentPosition(), duration, playing&&!folded&&!video, PlaybackService.live==null?null:PlaybackService.live.processor);
        if (!volume.isPressed()) volume.setProgress(audio.getStreamVolume(AudioManager.STREAM_MUSIC));
    }

    private void togglePlay() {
        if (controller == null) return;
        if (controller.getMediaItemCount() == 0) { openFull(1); return; }
        if (controller.getPlayWhenReady()) controller.pause();
        else { if (controller.getPlaybackState() == Player.STATE_ENDED) controller.seekToDefaultPosition(); controller.prepare(); controller.play(); }
    }
    private void toggleFold() {
        folded = !folded; body.setVisibility(folded ? View.GONE : View.VISIBLE); headerPlay.setVisibility(folded ? View.VISIBLE : View.GONE);
        fold.setText(folded ? "▣" : "▁"); fold.setContentDescription(folded ? "Expand mini player" : "Collapse mini player"); resizeWindow(windowParams.width); refresh();
    }
    private View.OnTouchListener move(boolean resize) {
        return new View.OnTouchListener() {
            float rawX, rawY; int x, y, width;
            @Override public boolean onTouch(View view, MotionEvent event) {
                if (windowParams == null) return false;
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: rawX = event.getRawX(); rawY = event.getRawY(); x = windowParams.x; y = windowParams.y; width = windowParams.width; return true;
                    case MotionEvent.ACTION_MOVE:
                        if (resize) resizeWindow(width + Math.round(event.getRawX() - rawX));
                        else { windowParams.x = x + Math.round(event.getRawX() - rawX); windowParams.y = y + Math.round(event.getRawY() - rawY); constrainPosition(); updateWindow(); } return true;
                    case MotionEvent.ACTION_UP: savePosition(); view.performClick(); return true;
                    case MotionEvent.ACTION_CANCEL: savePosition(); return true;
                    default: return true;
                }
            }
        };
    }
    private int height(int width) {
        if (folded) return dp(44);
        int media = video ? Math.round((width - dp(14)) * 9f / 16f) : Math.round((width-dp(14))*.36f)+dp(40);
        int available = Math.max(dp(30), bounds.height() - dp(170));
        return dp(170) + Math.min(media, available);
    }
    private int clampWidth(int width) { return Math.max(Math.min(dp(248), bounds.width()), Math.min(width, Math.min(dp(480), bounds.width()))); }
    private void resizeWindow(int width) {
        if (windowParams == null) return;
        windowParams.width = clampWidth(width); windowParams.height = height(windowParams.width);
        if (!folded) { LinearLayout.LayoutParams media = (LinearLayout.LayoutParams) display.getLayoutParams(); media.height = windowParams.height - dp(170); display.setLayoutParams(media); }
        constrainPosition(); updateWindow();
    }
    private void constrainPosition() {
        windowParams.x = Math.max(bounds.left, Math.min(windowParams.x, bounds.right - windowParams.width));
        windowParams.y = Math.max(bounds.top, Math.min(windowParams.y, bounds.bottom - windowParams.height));
    }
    private void updateWindow() { if (attached) try { manager.updateViewLayout(window, windowParams); } catch (RuntimeException error) { close(); } }
    private Rect screenBounds() {
        Rect screen;
        if (Build.VERSION.SDK_INT >= 30) {
            WindowMetrics metrics = manager.getMaximumWindowMetrics(); screen = new Rect(metrics.getBounds());
            Insets insets = metrics.getWindowInsets().getInsetsIgnoringVisibility(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            screen.left += insets.left; screen.top += insets.top; screen.right -= insets.right; screen.bottom -= insets.bottom;
        } else {
            android.util.DisplayMetrics metrics = new android.util.DisplayMetrics(); manager.getDefaultDisplay().getRealMetrics(metrics); screen = new Rect(0, dp(26), metrics.widthPixels, metrics.heightPixels - dp(48));
        }
        screen.inset(dp(6), dp(6)); return screen;
    }
    private void savePosition() {
        if (windowParams == null) return;
        prefs.edit().putFloat("mini_width", windowParams.width / getResources().getDisplayMetrics().density)
                .putFloat("mini_x", (windowParams.x - bounds.left) / (float) Math.max(1, bounds.width() - windowParams.width))
                .putFloat("mini_y", (windowParams.y - bounds.top) / (float) Math.max(1, bounds.height() - windowParams.height)).apply();
    }
    private void restorePosition() {
        windowParams.x = bounds.left + Math.round(prefs.getFloat("mini_x", .5f) * Math.max(0, bounds.width() - windowParams.width));
        windowParams.y = bounds.top + Math.round(prefs.getFloat("mini_y", .3f) * Math.max(0, bounds.height() - windowParams.height)); constrainPosition();
    }
    @Override public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration); if (!attached) return;
        savePosition(); bounds = screenBounds(); resizeWindow(dp(prefs.getFloat("mini_width", 320f))); restorePosition(); updateWindow();
    }
    private void openFull(int tab) {
        Intent intent = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("open_tab", tab);
        try { startActivity(intent); } catch (RuntimeException error) { toast("Open Soulmans from its app icon to return to the full player."); }
        close();
    }
    private Notification notification() {
        PendingIntent open = PendingIntent.getActivity(this, NOTICE, new Intent(this, MainActivity.class).putExtra("close_mini", true).putExtra("open_tab", 0), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        PendingIntent dismiss = PendingIntent.getService(this, NOTICE + 1, new Intent(this, FloatingPlayerService.class).setAction(CLOSE), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL).setSmallIcon(R.mipmap.ic_launcher).setContentTitle("Soulman's Media Player · mini")
                .setContentText(notificationTitle.isEmpty() ? "Drag the title bar to move · × closes the window" : notificationTitle)
                .setContentIntent(open).setOnlyAlertOnce(true).setOngoing(true).setCategory(Notification.CATEGORY_SERVICE)
                .addAction(new Notification.Action.Builder(null, "Close mini player", dismiss).build()).build();
    }
    private void close() { if (destroyed) return; removeWindow(); stopSelf(); }
    private void removeWindow() {
        if (videoView != null) videoView.setPlayer(null);
        if (attached) { savePosition(); attached = false; try { manager.removeViewImmediate(window); } catch (RuntimeException ignored) {} }
    }
    @Override public void onDestroy() {
        destroyed = true; handler.removeCallbacksAndMessages(null); removeWindow();
        if (controller != null) controller.removeListener(listener);
        if (connection != null) MediaController.releaseFuture(connection);
        stopForeground(STOP_FOREGROUND_REMOVE); if (live == this) live = null; super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
    private LinearLayout row() { LinearLayout view = new LinearLayout(this); view.setGravity(Gravity.CENTER_VERTICAL); return view; }
    private TextView text(String value, int size, int color) { TextView view = new TextView(this); view.setText(value); view.setTextSize(size); view.setTextColor(color); view.setTypeface(Typeface.MONOSPACE); view.setGravity(Gravity.CENTER_VERTICAL); return view; }
    private TextView control(String value, String description, Runnable action) {
        TextView view = text(value, 15, WHITE); view.setGravity(Gravity.CENTER); view.setContentDescription(description); view.setClickable(true); view.setFocusable(true); view.setOnClickListener(v -> action.run());
        view.setAccessibilityDelegate(new View.AccessibilityDelegate() { @Override public void onInitializeAccessibilityNodeInfo(View host, android.view.accessibility.AccessibilityNodeInfo info) { super.onInitializeAccessibilityNodeInfo(host, info); info.setClassName(Button.class.getName()); } }); return view;
    }
    private TextView transport(String value, String description, Runnable action) { TextView view = control(value, description, action); view.setTextSize(value.equals("SOUND") ? 9 : 16); MetalSkin.button(view); return view; }
    private LinearLayout.LayoutParams weight() { LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, -1, 1); params.setMargins(dp(2), dp(2), dp(2), dp(2)); return params; }
    private SeekBar slider(String description) { SeekBar bar = new SeekBar(this); bar.setPadding(dp(8), 0, dp(8), 0); bar.setContentDescription(description); bar.setProgressTintList(ColorStateList.valueOf(CYAN)); bar.setThumbTintList(ColorStateList.valueOf(CYAN)); bar.setProgressBackgroundTintList(ColorStateList.valueOf(0xff778188)); return bar; }
    private GradientDrawable panel() { GradientDrawable fill = gradient(0xff283c51, 0xff0c1422); fill.setCornerRadius(dp(9)); fill.setStroke(dp(1), 0xff59949f); return fill; }
    private GradientDrawable gradient(int a, int b) { return new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{a, b}); }
    private GradientDrawable edge(int fill, int stroke) { GradientDrawable shape = new GradientDrawable(); shape.setColor(fill); shape.setStroke(dp(1), stroke); shape.setCornerRadius(dp(4)); return shape; }
    private int dp(float size) { return Math.round(size * getResources().getDisplayMetrics().density); }
    private String time(long ms) { long seconds = Math.max(0, ms / 1000); return seconds >= 3600 ? String.format(Locale.US, "%d:%02d:%02d", seconds / 3600, seconds / 60 % 60, seconds % 60) : String.format(Locale.US, "%d:%02d", seconds / 60, seconds % 60); }
    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_LONG).show(); }
}
