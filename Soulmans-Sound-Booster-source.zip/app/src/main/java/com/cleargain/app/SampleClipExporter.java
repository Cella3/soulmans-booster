package com.cleargain.app;

import android.content.ContentResolver;
import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Decodes a bounded audio selection, applies sample edits, and writes a new PCM WAV. */
final class SampleClipExporter {
    static final int MAX_CLIP_MS=60_000;
    private SampleClipExporter() { }

    static long export(Context context,Uri source,Uri destination,int startMs,int endMs,float pitchSemitones,
            int fadeInMs,int fadeOutMs,int echoDelayMs,float echoAmount)throws Exception {
        if(endMs<=startMs)throw new IOException("Set an end point after the start point.");
        if(endMs-startMs>MAX_CLIP_MS)throw new IOException("Trim the sample to 60 seconds or less before saving it.");
        MediaExtractor extractor=new MediaExtractor();MediaCodec decoder=null;byte[] raw;
        int rate=0,channels=0,pcmEncoding=2;
        try {
            extractor.setDataSource(context,source,null);int audio=-1;
            for(int i=0;i<extractor.getTrackCount();i++){MediaFormat f=extractor.getTrackFormat(i);String mime=f.getString(MediaFormat.KEY_MIME);if(mime!=null&&mime.startsWith("audio/")){audio=i;break;}}
            if(audio<0)throw new IOException("This file has no readable audio track.");
            extractor.selectTrack(audio);MediaFormat format=extractor.getTrackFormat(audio);String mime=format.getString(MediaFormat.KEY_MIME);
            rate=format.containsKey(MediaFormat.KEY_SAMPLE_RATE)?format.getInteger(MediaFormat.KEY_SAMPLE_RATE):44100;
            channels=format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)?format.getInteger(MediaFormat.KEY_CHANNEL_COUNT):2;
            if(channels<1||channels>8||rate<8000||rate>192000)throw new IOException("The audio format is outside the supported sample export range.");
            decoder=MediaCodec.createDecoderByType(mime);decoder.configure(format,null,null,0);decoder.start();
            extractor.seekTo(startMs*1000L,MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            raw=decode(extractor,decoder,startMs*1000L,endMs*1000L,rate,channels);
        } finally {
            if(decoder!=null){try{decoder.stop();}catch(RuntimeException ignored){}decoder.release();}
            extractor.release();
        }
        int outputChannels=Math.min(channels,2),frames=raw.length/(outputChannels*2);
        if(frames==0)throw new IOException("No audio samples were found between those points.");
        short[] samples=new short[frames*outputChannels];ByteBuffer b=ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN);for(int i=0;i<samples.length;i++)samples[i]=b.getShort();
        short[] edited=SampleRenderMath.render(samples,outputChannels,rate,pitchSemitones,fadeInMs,fadeOutMs,echoDelayMs,echoAmount);
        try(OutputStream out=context.getContentResolver().openOutputStream(destination,"wt")) {
            if(out==null)throw new IOException("Android could not create the WAV file.");
            int bytes=edited.length*2;header(out,bytes,rate,outputChannels);
            byte[] block=new byte[32768];int used=0;
            for(short value:edited){block[used++]=(byte)value;block[used++]=(byte)(value>>>8);if(used==block.length){out.write(block);used=0;}}
            if(used>0)out.write(block,0,used);out.flush();
        }
        return (long)(edited.length/outputChannels)*1000/rate;
    }

    private static byte[] decode(MediaExtractor extractor,MediaCodec codec,long startUs,long endUs,int initialRate,int initialChannels)throws IOException {
        MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();ByteArrayOutputStream pcm=new ByteArrayOutputStream();
        boolean inputDone=false,outputDone=false;int rate=initialRate,channels=initialChannels,encoding=2;
        long maxBytes=(long)rate*Math.min(channels,2)*2*(MAX_CLIP_MS+2500)/1000;
        while(!outputDone){
            if(!inputDone){int inputIndex=codec.dequeueInputBuffer(10_000);if(inputIndex>=0){ByteBuffer input=codec.getInputBuffer(inputIndex);if(input==null)throw new IOException("Audio decoder input is unavailable.");int size=extractor.readSampleData(input,0);long time=extractor.getSampleTime();
                    if(size<0||time>=endUs){codec.queueInputBuffer(inputIndex,0,0,Math.max(0,time),MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputDone=true;}
                    else{codec.queueInputBuffer(inputIndex,0,size,Math.max(0,time),0);extractor.advance();}}}
            int outIndex=codec.dequeueOutputBuffer(info,10_000);
            if(outIndex==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){MediaFormat f=codec.getOutputFormat();if(f.containsKey(MediaFormat.KEY_SAMPLE_RATE))rate=f.getInteger(MediaFormat.KEY_SAMPLE_RATE);if(f.containsKey(MediaFormat.KEY_CHANNEL_COUNT))channels=f.getInteger(MediaFormat.KEY_CHANNEL_COUNT);if(f.containsKey(MediaFormat.KEY_PCM_ENCODING))encoding=f.getInteger(MediaFormat.KEY_PCM_ENCODING);continue;}
            if(outIndex>=0){ByteBuffer output=codec.getOutputBuffer(outIndex);if(output!=null&&info.size>0){output.position(info.offset);output.limit(info.offset+info.size);appendFrames(pcm,output,info.presentationTimeUs,rate,channels,encoding,startUs,endUs,maxBytes);}
                outputDone=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;codec.releaseOutputBuffer(outIndex,false);if(pcm.size()>=maxBytes)outputDone=true;}
        }
        return pcm.toByteArray();
    }

    private static void appendFrames(ByteArrayOutputStream pcm,ByteBuffer b,long presentationUs,int rate,int channels,int encoding,long startUs,long endUs,long maxBytes)throws IOException {
        int bytesPerSample=encoding==4?4:encoding==3?1:encoding==21?3:encoding==2?2:encoding==22?4:2;
        int frameBytes=bytesPerSample*channels;if(frameBytes<=0)return;int frames=b.remaining()/frameBytes;
        int outputChannels=Math.min(2,channels);byte[] frame=new byte[outputChannels*2];b.order(ByteOrder.LITTLE_ENDIAN);
        for(int i=0;i<frames;i++){
            long timestamp=presentationUs+(long)i*1_000_000L/rate;if(timestamp<startUs){b.position(b.position()+frameBytes);continue;}if(timestamp>=endUs)break;
            for(int c=0;c<outputChannels;c++){
                float value;
                if(encoding==4){value=b.getFloat();}
                else if(encoding==3){value=((b.get()&255)-128)/128f;}
                else if(encoding==21){int n=(b.get()&255)|((b.get()&255)<<8)|((b.get()&255)<<16);if((n&0x800000)!=0)n|=0xff000000;value=n/8388608f;}
                else if(encoding==22){value=b.getInt()/2147483648f;}
                else value=b.getShort()/32768f;
                int sample=(int)Math.max(-32768,Math.min(32767,Math.round(value*32767)));frame[c*2]=(byte)sample;frame[c*2+1]=(byte)(sample>>>8);
            }
            int skipped=channels-outputChannels;if(skipped>0)b.position(b.position()+skipped*bytesPerSample);
            if(pcm.size()+frame.length>maxBytes)throw new IOException("Trim the sample shorter before exporting it.");pcm.write(frame);
        }
    }

    private static void header(OutputStream out,int dataBytes,int rate,int channels)throws IOException {
        out.write(new byte[]{'R','I','F','F'});le32(out,36+dataBytes);out.write(new byte[]{'W','A','V','E','f','m','t',' '});le32(out,16);le16(out,1);le16(out,channels);le32(out,rate);le32(out,rate*channels*2);le16(out,channels*2);le16(out,16);out.write(new byte[]{'d','a','t','a'});le32(out,dataBytes);
    }
    private static void le16(OutputStream out,int value)throws IOException{out.write(value&255);out.write((value>>>8)&255);}
    private static void le32(OutputStream out,int value)throws IOException{out.write(value&255);out.write((value>>>8)&255);out.write((value>>>16)&255);out.write((value>>>24)&255);}
}
