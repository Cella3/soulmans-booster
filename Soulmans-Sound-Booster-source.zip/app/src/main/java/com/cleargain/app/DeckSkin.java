package com.cleargain.app;

import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;

final class DeckSkin {
    static final int BG=0xff080e0c,TEXT=0xffe9ddba,MUTED=0xffaeb9aa,GOLD=0xffe2bf66,GREEN=0xff93e86c;
    static void button(TextView view){
        float d=view.getResources().getDisplayMetrics().density;
        GradientDrawable face=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0xff394238,0xff172019,0xff080e0b});
        face.setCornerRadius(3*d);face.setStroke(Math.max(1,Math.round(d)),0xff9d8245);
        view.setBackground(face);view.setTextColor(GOLD);view.setShadowLayer(1,0,1,0xff000000);view.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));
    }
    static void slider(SeekBar view){view.setProgressTintList(ColorStateList.valueOf(GOLD));view.setThumbTintList(ColorStateList.valueOf(0xffcbd0c3));view.setProgressBackgroundTintList(ColorStateList.valueOf(0xff3b483c));}
    static void surface(View root){
        if(root instanceof TextView){TextView text=(TextView)root;String description=String.valueOf(text.getContentDescription());
            if(!description.startsWith("Sampler pad")){if(text.isClickable()&&!(text instanceof CompoundButton))button(text);else text.setTextColor(MUTED);}
            if(text instanceof CompoundButton){((CompoundButton)text).setButtonTintList(ColorStateList.valueOf(GOLD));}
        }
        if(root instanceof SeekBar)slider((SeekBar)root);
        if(root instanceof ViewGroup)for(int i=0;i<((ViewGroup)root).getChildCount();i++)surface(((ViewGroup)root).getChildAt(i));
    }
}
