package com.cleargain.app;

/** Local spectral-flux tempo and chroma key estimates. Ambiguous/silent material remains unknown. */
final class DjAnalysis {
    static final String[] KEYS={"C","C#","D","D#","E","F","F#","G","G#","A","A#","B"};
    record Result(float bpm,String key,float confidence,double firstBeatSeconds){}
    static Result analyze(DjPcm pcm){int rate=11025,n=Math.min(rate*90,(int)(pcm.frames*(long)rate/pcm.rate));float[] mono=new float[n];for(int i=0;i<n;i++)mono[i]=(pcm.interpolated(i*(double)pcm.rate/rate,0)+pcm.interpolated(i*(double)pcm.rate/rate,1))*.5f;return analyze(mono,rate);}
    static Result analyze(float[] mono,int rate){
        int size=2048,hop=256,windows=(mono.length-size)/hop;if(windows<rate/hop*4)return new Result(0,"Unknown",0,0);
        double[] chroma=new double[12],previous=new double[size/2],flux=new double[windows],re=new double[size],im=new double[size];double energy=0;
        for(int w=0;w<windows;w++){
            for(int i=0;i<size;i++){double value=mono[w*hop+i];energy+=value*value;re[i]=value*(.5-.5*Math.cos(2*Math.PI*i/(size-1)));im[i]=0;}fft(re,im);
            for(int bin=1;bin<size/2;bin++){double magnitude=Math.hypot(re[bin],im[bin]),frequency=bin*(double)rate/size;if(frequency>40&&frequency<6000){flux[w]+=Math.max(0,magnitude-previous[bin]);previous[bin]=magnitude;}if(frequency>=70&&frequency<4000){int note=(int)Math.round(69+12*Math.log(frequency/440)/Math.log(2));chroma[Math.floorMod(note,12)]+=Math.sqrt(magnitude);}}
        }
        if(energy/(windows*(double)size)<.000001)return new Result(0,"Unknown",0,0);
        double[] onset=new double[windows];double total=0;int strongest=0;
        for(int i=0;i<windows;i++){double avg=0;int count=0;for(int j=Math.max(0,i-12);j<=Math.min(windows-1,i+12);j++){avg+=flux[j];count++;}onset[i]=Math.max(0,flux[i]-avg/count);total+=onset[i]*onset[i];if(onset[i]>onset[strongest])strongest=i;}
        double fps=rate/(double)hop,best=0,weightedBest=0;int lagBest=0;
        // Weak dance-tempo prior resolves otherwise equal half/double-time autocorrelation peaks.
        // The original estimate remains editable: meter and musical beat are inherently ambiguous.
        for(int lag=(int)(fps*60/200);lag<=fps*60/60;lag++){double score=corr(onset,lag),tempo=60*fps/lag;
            double prior=Math.exp(-.5*Math.pow(Math.log(tempo/120)/.55,2)),weighted=score*(.75+.25*prior);
            if(weighted>weightedBest){weightedBest=weighted;best=score;lagBest=lag;}}
        double confidence=total==0?0:best/(total/windows);float bpm=confidence>.12&&lagBest>0?(float)(60*fps/lagBest):0;
        if(bpm>0&&lagBest>1){double a=corr(onset,lagBest-1),b=corr(onset,lagBest),c=corr(onset,lagBest+1),div=a-2*b+c;double correction=div==0?0:.5*(a-c)/div;bpm=(float)(60*fps/(lagBest+Math.max(-.5,Math.min(.5,correction))));}
        return new Result(bpm,key(chroma),(float)Math.min(1,confidence),strongest/fps);
    }
    private static double corr(double[] a,int lag){double n=0;for(int i=lag;i<a.length;i++)n+=a[i]*a[i-lag];return n/Math.max(1,a.length-lag);}
    static String key(double[] chroma){
        double[][] templates={{6.35,2.23,3.48,2.33,4.38,4.09,2.52,5.19,2.39,3.66,2.29,2.88},{6.33,2.68,3.52,5.38,2.60,3.53,2.54,4.75,3.98,2.69,3.34,3.17}};
        double mean=java.util.Arrays.stream(chroma).average().orElse(0),variance=0;for(double value:chroma)variance+=(value-mean)*(value-mean);if(variance<1e-9)return "Unknown";
        double best=-2,second=-2;int note=0,mode=0;
        for(int m=0;m<2;m++){double tm=java.util.Arrays.stream(templates[m]).average().orElse(0),tv=0;for(double v:templates[m])tv+=(v-tm)*(v-tm);
            for(int root=0;root<12;root++){double score=0;for(int i=0;i<12;i++)score+=(chroma[(i+root)%12]-mean)*(templates[m][i]-tm);score/=Math.sqrt(tv*variance);if(score>best){second=best;best=score;note=root;mode=m;}else second=Math.max(second,score);}
        }return best>.35&&best-second>.02?KEYS[note]+(mode==1?" minor":" major"):"Unknown";
    }
    private static void fft(double[] re,double[] im){int n=re.length;for(int i=1,j=0;i<n;i++){int bit=n>>1;for(; (j&bit)!=0;bit>>=1)j^=bit;j^=bit;if(i<j){double r=re[i];re[i]=re[j];re[j]=r;}}
        for(int len=2;len<=n;len*=2){double angle=-2*Math.PI/len;for(int start=0;start<n;start+=len){double wr=1,wi=0;for(int i=0;i<len/2;i++){int a=start+i,b=a+len/2;double tr=wr*re[b]-wi*im[b],ti=wr*im[b]+wi*re[b];re[b]=re[a]-tr;im[b]=im[a]-ti;re[a]+=tr;im[a]+=ti;double next=wr*Math.cos(angle)-wi*Math.sin(angle);wi=wr*Math.sin(angle)+wi*Math.cos(angle);wr=next;}}}
    }
}
