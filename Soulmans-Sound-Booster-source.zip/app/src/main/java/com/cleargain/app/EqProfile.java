package com.cleargain.app;

import android.content.SharedPreferences;

final class EqProfile {
    static final int[] HZ = {60, 150, 400, 1000, 2500, 6000, 12000};
    static final String[] LABELS = {"60", "150", "400", "1k", "2.5k", "6k", "12k"};
    static final String[] PRESETS = {"Flat", "Bass", "Vocal", "Bright", "Rock", "Electronic", "Acoustic"};
    private static final int[][] LEVELS = {
            {0, 0, 0, 0, 0, 0, 0},
            {5, 4, 2, 0, -1, -1, -2},
            {-2, -1, 1, 3, 2, 0, -1},
            {-2, -1, 0, 0, 2, 4, 5},
            {4, 3, -1, -2, 1, 3, 4},
            {5, 3, 0, -1, 1, 3, 3},
            {1, 1, 2, 2, 1, 2, 2}
    };

    private EqProfile() { }

    static void ensureDefaults(SharedPreferences prefs) {
        if (prefs.contains("eq_profile_version")) return;
        SharedPreferences.Editor edit = prefs.edit();
        edit.putInt("eq_profile_version", 1);
        edit.putString("eq_preset", "Bass");
        edit.putBoolean("eq_enabled", true);
        for (int i = 0; i < HZ.length; i++) edit.putInt("eq_" + i, LEVELS[1][i]);
        edit.apply();
    }

    static int[] levels(SharedPreferences prefs) {
        int[] result = new int[HZ.length];
        for (int i = 0; i < HZ.length; i++) {
            result[i] = Math.max(-6, Math.min(6, prefs.getInt("eq_" + i, 0)));
        }
        return result;
    }

    static int[] presetLevels(String name){for(int i=0;i<PRESETS.length;i++)if(PRESETS[i].equals(name))return LEVELS[i].clone();return LEVELS[0].clone();}

    static void setPreset(SharedPreferences prefs, String name) {
        int selected = 0;
        for (int i = 0; i < PRESETS.length; i++) {
            if (PRESETS[i].equals(name)) { selected = i; break; }
        }
        SharedPreferences.Editor edit = prefs.edit();
        edit.putString("eq_preset", PRESETS[selected]);
        edit.putBoolean("eq_enabled", selected != 0);
        for (int i = 0; i < HZ.length; i++) edit.putInt("eq_" + i, LEVELS[selected][i]);
        edit.apply();
    }

    static void setBand(SharedPreferences prefs, int index, int db) {
        if (index < 0 || index >= HZ.length) return;
        prefs.edit()
                .putInt("eq_" + index, Math.max(-6, Math.min(6, db)))
                .putString("eq_preset", "Custom")
                .putBoolean("eq_enabled", true)
                .apply();
    }

    static float levelAt(int[] levels, float frequencyHz) {
        if (frequencyHz <= HZ[0]) return levels[0];
        for (int i = 0; i < HZ.length - 1; i++) {
            if (frequencyHz <= HZ[i + 1]) {
                double low = Math.log(HZ[i]);
                double high = Math.log(HZ[i + 1]);
                double fraction = (Math.log(frequencyHz) - low) / (high - low);
                return (float) (levels[i] + fraction * (levels[i + 1] - levels[i]));
            }
        }
        return levels[levels.length - 1];
    }
}
