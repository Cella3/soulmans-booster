package com.cleargain.app;

import android.content.SharedPreferences;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

final class VideoClipPrefs {
    private VideoClipPrefs() {}

    static String key(String mediaId) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(mediaId.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder(digest.length * 2);
            for (byte value : digest) hex.append(String.format(java.util.Locale.ROOT, "%02x", value & 0xff));
            return hex.toString();
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("SHA-256 is unavailable", impossible);
        }
    }

    static long start(SharedPreferences prefs, String mediaId) {
        return prefs.getLong("video_clip_start_" + key(mediaId), 0);
    }

    static long end(SharedPreferences prefs, String mediaId, long fallbackMs) {
        return prefs.getLong("video_clip_end_" + key(mediaId), fallbackMs);
    }

    static boolean loops(SharedPreferences prefs, String mediaId) {
        return prefs.getBoolean("video_clip_loop_" + key(mediaId), false);
    }

    static void save(SharedPreferences prefs, String mediaId, long startMs, long endMs,
                     boolean loop, int quality, int type) {
        String key = key(mediaId);
        prefs.edit()
                .putLong("video_clip_start_" + key, startMs)
                .putLong("video_clip_end_" + key, endMs)
                .putBoolean("video_clip_loop_" + key, loop)
                .putInt("video_export_quality_" + key, quality)
                .putInt("video_export_type_" + key, type)
                .apply();
    }
}
