package com.cleargain.app;

import android.content.Context;
import android.graphics.*;
import android.os.SystemClock;
import android.view.View;

/** Compact oscilloscope driven by the player's decoded PCM, with no microphone access. */
final class MiniScopeView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private SoundProcessor source;
    private boolean playing;
    MiniScopeView(Context context) {
        super(context);
        setContentDescription("Live music waveform");
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }
    void state(SoundProcessor source, boolean playing) { this.source = source; this.playing = playing; invalidate(); }
    @Override protected void onDraw(Canvas canvas) {
        float width = getWidth(), height = getHeight(), center = height * .56f;
        paint.setStyle(Paint.Style.FILL); paint.setColor(0xff060e18); canvas.drawRect(0, 0, width, height, paint);
        paint.setColor(0xff142637); paint.setStrokeWidth(dp(.5f));
        for (int x = 0; x < width; x += dp(16)) canvas.drawLine(x, 0, x, height, paint);
        for (int y = 0; y < height; y += dp(12)) canvas.drawLine(0, y, width, y, paint);
        boolean active = playing && source != null && SystemClock.elapsedRealtime() - source.capturedAt < 600;
        if (active) {
            float[] bars = source.spectrum;
            paint.setColor(0x664e64a2);
            for (int i = 0; i < bars.length; i++) {
                float x = width * i / bars.length, barHeight = bars[i] * height * .65f;
                canvas.drawRect(x + dp(1), height - barHeight, x + width / bars.length - dp(1), height, paint);
            }
        }
        float[] wave = active ? source.waveform : null;
        path.reset();
        for (int i = 0; i < 128; i++) {
            float x = width * i / 127, y = center - (wave == null ? 0 : wave[i]) * height * .32f;
            if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
        }
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(5)); paint.setColor(0x2241e4f0); canvas.drawPath(path, paint);
        paint.setStrokeWidth(dp(1.3f)); paint.setColor(active ? 0xff55f5ec : 0xff365762); canvas.drawPath(path, paint);
        paint.setStyle(Paint.Style.FILL); paint.setTypeface(Typeface.MONOSPACE); paint.setTextSize(dp(7)); paint.setColor(0xff91abbf);
        canvas.drawText("WAVE / SPECTRUM", dp(6), dp(10), paint);
        String status = active ? "LIVE" : "STANDBY"; paint.setColor(active ? 0xff83ffb5 : 0xff657c8e);
        canvas.drawText(status, width - paint.measureText(status) - dp(6), dp(10), paint);
        if (playing && isShown()) postInvalidateDelayed(33);
    }
    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }
}
