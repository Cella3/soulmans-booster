package com.cleargain.app;

import android.content.Context;
import android.graphics.*;
import android.os.SystemClock;
import android.view.View;

/** Two analog needles show RMS and peak from real decoded samples. */
final class DeckMeterView extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private SoundProcessor source;private boolean playing;
    DeckMeterView(Context context){super(context);setBackground(new DeckPanelDrawable(context,3));setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
    void state(SoundProcessor source,boolean playing){this.source=source;this.playing=playing;invalidate();}
    @Override protected void onDraw(Canvas canvas){
        float rms=0,peak=0;
        if(playing&&source!=null&&SystemClock.elapsedRealtime()-source.capturedAt<600){for(float sample:source.waveform){rms+=sample*sample;peak=Math.max(peak,Math.abs(sample));}rms=(float)Math.sqrt(rms/source.waveform.length);}
        float d=getResources().getDisplayMetrics().density,w=getWidth(),h=getHeight();
        for(int meter=0;meter<2;meter++){
            float left=meter*w/2+6*d,right=(meter+1)*w/2-6*d,top=6*d,bottom=h-6*d;
            paint.setColor(0xffffebad);canvas.drawRoundRect(left,top,right,bottom,2*d,2*d,paint);
            float cx=(left+right)/2,cy=bottom-3*d,r=Math.min((right-left)*.44f,(bottom-top)*.75f);
            paint.setColor(0xff32392e);paint.setStrokeWidth(.7f*d);
            for(int tick=0;tick<=10;tick++){double angle=Math.toRadians(220+tick*10);float x=cx+(float)Math.cos(angle)*r,y=cy+(float)Math.sin(angle)*r;canvas.drawLine(x,y,cx+(float)Math.cos(angle)*(r-3*d),cy+(float)Math.sin(angle)*(r-3*d),paint);}
            float level=meter==0?rms:peak;float db=(float)(20*Math.log10(Math.max(.0001f,level)));float unit=Math.max(0,Math.min(1,(db+36)/36));double angle=Math.toRadians(220+100*unit);
            paint.setColor(0xff9e321d);paint.setStrokeWidth(1.2f*d);canvas.drawLine(cx,bottom-2*d,cx+(float)Math.cos(angle)*r,cy+(float)Math.sin(angle)*r,paint);
            paint.setColor(0xff283323);paint.setTypeface(Typeface.MONOSPACE);paint.setTextAlign(Paint.Align.CENTER);paint.setTextSize(7*d);canvas.drawText(meter==0?"VU / RMS":"VU / PEAK",cx,bottom-3*d,paint);
        }
        if(playing&&isShown())postInvalidateDelayed(33);
    }
}
