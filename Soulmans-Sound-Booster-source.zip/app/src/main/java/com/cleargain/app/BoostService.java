package com.cleargain.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.media.audiofx.Equalizer;
import android.media.audiofx.LoudnessEnhancer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

public final class BoostService extends Service {
    public static final String ACTION_APPLY = "com.cleargain.app.APPLY";
    public static final String ACTION_STOP = "com.cleargain.app.STOP";
    public static final String ACTION_STATE = "com.cleargain.app.STATE";
    private static final String CHANNEL = "boost";
    private static final int NOTIFICATION_ID = 1;

    private SharedPreferences prefs;
    private AudioManager audioManager;
    private LoudnessEnhancer loudness;
    private Equalizer equalizer;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private AudioDeviceCallback deviceCallback;
    private boolean started;

    @Override public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        EqProfile.ensureDefaults(prefs);
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        manager.createNotificationChannel(new NotificationChannel(
                CHANNEL, "Audio boost", NotificationManager.IMPORTANCE_LOW));
        deviceCallback = new AudioDeviceCallback() {
            @Override public void onAudioDevicesAdded(AudioDeviceInfo[] devices) { scheduleRebuild(); }
            @Override public void onAudioDevicesRemoved(AudioDeviceInfo[] devices) { scheduleRebuild(); }
        };
        audioManager.registerAudioDeviceCallback(deviceCallback, handler);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            prefs.edit().putBoolean("enabled", false).apply();
            sendState(false, false, false, false, "Boost is off.");
            finish();
            return START_NOT_STICKY;
        }
        if (!prefs.getBoolean("enabled", false)) {
            finish();
            return START_NOT_STICKY;
        }
        try {
            startForeground(NOTIFICATION_ID, notification());
            started = true;
            applyEffects();
        } catch (RuntimeException e) {
            prefs.edit().putBoolean("enabled", false).apply();
            sendState(false, false, false, false, "Could not start audio boost: " + e.getClass().getSimpleName());
            finish();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    private void scheduleRebuild() {
        if (!started) return;
        handler.removeCallbacks(rebuild);
        handler.postDelayed(rebuild, 650);
    }

    private final Runnable rebuild = () -> {
        if (started) {
            releaseEffects();
            applyEffects();
        }
    };

    private void applyEffects() {
        int gainDb = prefs.getInt("gain_db", 4);
        boolean eqWanted = prefs.getBoolean("eq_enabled", true);
        boolean loudnessOk = false;
        boolean eqOk = false;
        boolean fallback = false;

        if (loudness == null) {
            try { loudness = new LoudnessEnhancer(0); }
            catch (RuntimeException ignored) { loudness = null; }
        }
        if (loudness != null) {
            try {
                if (!loudness.hasControl()) throw new IllegalStateException("Effect owned by another app");
                loudness.setTargetGain(gainDb * 100);
                loudness.setEnabled(gainDb > 0);
                loudnessOk = true;
            } catch (RuntimeException e) {
                loudness.release();
                loudness = null;
            }
        }

        if (eqWanted || !loudnessOk) {
            if (equalizer == null) {
                try { equalizer = new Equalizer(0, 0); }
                catch (RuntimeException ignored) { equalizer = null; }
            }
            if (equalizer != null) {
                try {
                    if (!equalizer.hasControl()) throw new IllegalStateException("EQ owned by another app");
                    fallback = !loudnessOk;
                    short[] range = equalizer.getBandLevelRange();
                    short count = equalizer.getNumberOfBands();
                    int[] levels = EqProfile.levels(prefs);
                    for (short band = 0; band < count; band++) {
                        float frequencyHz = equalizer.getCenterFreq(band) / 1000f;
                        int adjustment = eqWanted
                                ? Math.round(EqProfile.levelAt(levels, frequencyHz) * 100f) : 0;
                        int value = adjustment + (fallback ? gainDb * 100 : 0);
                        value = Math.max(range[0], Math.min(range[1], value));
                        equalizer.setBandLevel(band, (short) value);
                    }
                    equalizer.setEnabled(true);
                    eqOk = true;
                } catch (RuntimeException e) {
                    equalizer.release();
                    equalizer = null;
                    fallback = false;
                }
            }
        } else if (equalizer != null) {
            equalizer.release();
            equalizer = null;
        }

        if (!loudnessOk && !eqOk) {
            prefs.edit().putBoolean("enabled", false).apply();
            sendState(false, false, false, false,
                    "This audio route rejected global boost. Try another output device.");
            finish();
            return;
        }

        String message;
        if (fallback) message = "BOOST ON · EQ fallback";
        else if (eqWanted && !eqOk) message = "BOOST ON · EQ unavailable";
        else message = "BOOST ON · supported media audio";
        sendState(true, loudnessOk, eqOk, fallback, message);
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(
                NOTIFICATION_ID, notification());
    }

    private void sendState(boolean active, boolean loudnessOk, boolean eqOk,
                           boolean fallback, String message) {
        Intent state = new Intent(ACTION_STATE).setPackage(getPackageName());
        state.putExtra("active", active);
        state.putExtra("loudness", loudnessOk);
        state.putExtra("eq", eqOk);
        state.putExtra("fallback", fallback);
        state.putExtra("message", message);
        if (eqOk && equalizer != null) {
            int count = equalizer.getNumberOfBands();
            int[] centers = new int[count];
            for (short band = 0; band < count; band++) centers[band] = equalizer.getCenterFreq(band);
            state.putExtra("centers", centers);
        }
        sendBroadcast(state);
    }

    private Notification notification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent off = new Intent(this, BoostService.class).setAction(ACTION_STOP);
        PendingIntent stop = PendingIntent.getService(this, 1, off,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(com.cleargain.app.R.drawable.ic_volume)
                .setContentTitle("Soulman's Media Player")
                .setContentText("Boost +" + prefs.getInt("gain_db", 4) + " dB")
                .setContentIntent(content)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(
                        com.cleargain.app.R.drawable.ic_volume, "Turn off", stop).build())
                .build();
    }

    private void releaseEffects() {
        if (loudness != null) {
            try { loudness.setEnabled(false); } catch (RuntimeException ignored) { }
            loudness.release();
            loudness = null;
        }
        if (equalizer != null) {
            try { equalizer.setEnabled(false); } catch (RuntimeException ignored) { }
            equalizer.release();
            equalizer = null;
        }
    }

    private void finish() {
        started = false;
        handler.removeCallbacks(rebuild);
        releaseEffects();
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE);
        else stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() {
        started = false;
        handler.removeCallbacks(rebuild);
        releaseEffects();
        if (deviceCallback != null) audioManager.unregisterAudioDeviceCallback(deviceCallback);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
