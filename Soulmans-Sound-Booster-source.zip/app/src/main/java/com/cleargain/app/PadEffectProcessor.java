package com.cleargain.app;

import androidx.media3.common.C;
import androidx.media3.common.audio.BaseAudioProcessor;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Per-pad echo. Clip fades and pitch are applied by the pad transport. */
@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
final class PadEffectProcessor extends BaseAudioProcessor {
    volatile int delayMs;
    volatile float amount;
    private int channels,rate,delayFrames,cursor;
    private float[][] ring;
    private int configuredDelay=-1;

    void settings(int delayMs,float amount){this.delayMs=Math.max(0,Math.min(600,delayMs));this.amount=Math.max(0,Math.min(.7f,amount));}

    @Override public AudioFormat onConfigure(AudioFormat format)throws UnhandledAudioFormatException {
        if(format.encoding!=C.ENCODING_PCM_16BIT)throw new UnhandledAudioFormatException(format);
        channels=format.channelCount;rate=format.sampleRate;configuredDelay=-1;return format;
    }
    @Override public void queueInput(ByteBuffer input){
        int requested=delayMs;float wet=amount;
        if(requested!=configuredDelay){configuredDelay=requested;delayFrames=requested==0?0:Math.max(1,rate*requested/1000);ring=delayFrames==0?null:new float[channels][delayFrames];cursor=0;}
        ByteBuffer out=replaceOutputBuffer(input.remaining()).order(ByteOrder.nativeOrder());input.order(ByteOrder.nativeOrder());
        while(input.remaining()>=channels*2){
            for(int c=0;c<channels;c++){
                float dry=input.getShort()/32768f;float echo=ring==null?0:ring[c][cursor];float mixed=dry+echo*wet;
                if(ring!=null)ring[c][cursor]=Math.max(-1f,Math.min(1f,dry+echo*.48f));
                out.putShort((short)Math.max(-32768,Math.min(32767,Math.round(mixed*32767))));
            }
            if(ring!=null&&++cursor==delayFrames)cursor=0;
        }
        out.flip();
    }
    @Override protected void onFlush(){cursor=0;if(ring!=null)for(float[] channel:ring)java.util.Arrays.fill(channel,0);}
    @Override protected void onReset(){ring=null;delayFrames=0;configuredDelay=-1;}
}
