package com.cleargain.app;

import android.content.Context;
import android.media.*;
import android.net.Uri;
import java.io.*;
import java.nio.*;
import java.util.function.BooleanSupplier;

/** Decode the phone's supported audio codecs, including the audio stream of video files. */
final class DjDecoder {
    static DjPcm decode(Context context,String uri,BooleanSupplier cancelled,int limitSeconds)throws IOException{
        File file=File.createTempFile("dj-",".pcm",context.getCacheDir());MediaExtractor extractor=new MediaExtractor();MediaCodec codec=null;
        int rate=44100,channels=2,encoding=AudioFormat.ENCODING_PCM_16BIT;long written=0;boolean success=false;
        try(OutputStream output=new BufferedOutputStream(new FileOutputStream(file),65536)){
            extractor.setDataSource(context,Uri.parse(uri),null);int selected=-1;MediaFormat format=null;
            for(int i=0;i<extractor.getTrackCount();i++){MediaFormat f=extractor.getTrackFormat(i);String mime=f.getString(MediaFormat.KEY_MIME);if(mime!=null&&mime.startsWith("audio/")){selected=i;format=f;break;}}
            if(selected<0)throw new IOException("This file has no supported audio stream");extractor.selectTrack(selected);
            rate=format.getInteger(MediaFormat.KEY_SAMPLE_RATE);channels=format.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            String mime=format.getString(MediaFormat.KEY_MIME);
            if("audio/raw".equals(mime)){
                if(format.containsKey(MediaFormat.KEY_PCM_ENCODING))encoding=format.getInteger(MediaFormat.KEY_PCM_ENCODING);
                ByteBuffer raw=ByteBuffer.allocateDirect(262144);while(!cancelled.getAsBoolean()){
                    raw.clear();int size=extractor.readSampleData(raw,0);if(size<0)break;raw.position(0);raw.limit(size);written+=write(output,raw,channels,encoding);
                    if(limitSeconds>0&&written/4L>=rate*(long)limitSeconds)break;checkSpace(file,written);extractor.advance();
                }
            }else{
                codec=MediaCodec.createDecoderByType(mime);codec.configure(format,null,null,0);codec.start();MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();boolean inputDone=false,done=false;long lastOutput=android.os.SystemClock.elapsedRealtime();
                while(!done&&!cancelled.getAsBoolean()){
                    if(!inputDone){int index=codec.dequeueInputBuffer(10000);if(index>=0){ByteBuffer input=codec.getInputBuffer(index);int size=extractor.readSampleData(input,0);long time=extractor.getSampleTime();if(size<0||(limitSeconds>0&&time>=limitSeconds*1000000L)){codec.queueInputBuffer(index,0,0,Math.max(0,time),MediaCodec.BUFFER_FLAG_END_OF_STREAM);inputDone=true;}else{codec.queueInputBuffer(index,0,size,Math.max(0,time),0);extractor.advance();}}}
                    int index=codec.dequeueOutputBuffer(info,10000);
                    if(index==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED){MediaFormat f=codec.getOutputFormat();rate=f.getInteger(MediaFormat.KEY_SAMPLE_RATE);channels=f.getInteger(MediaFormat.KEY_CHANNEL_COUNT);if(f.containsKey(MediaFormat.KEY_PCM_ENCODING))encoding=f.getInteger(MediaFormat.KEY_PCM_ENCODING);}
                    if(index>=0){ByteBuffer buffer=codec.getOutputBuffer(index);if(buffer!=null&&info.size>0){buffer.position(info.offset);buffer.limit(info.offset+info.size);written+=write(output,buffer,channels,encoding);lastOutput=android.os.SystemClock.elapsedRealtime();}done=(info.flags&MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0;codec.releaseOutputBuffer(index,false);checkSpace(file,written);}
                    if(android.os.SystemClock.elapsedRealtime()-lastOutput>30000)throw new IOException("Audio decoder timed out");
                }
            }
            if(cancelled.getAsBoolean())throw new IOException("Loading cancelled");output.flush();success=true;
        }catch(RuntimeException error){throw new IOException("Cannot decode this format on this phone",error);}
        finally{if(codec!=null){try{codec.stop();}catch(RuntimeException ignored){}codec.release();}extractor.release();if(!success)file.delete();}
        try{return new DjPcm(file,rate);}catch(IOException e){file.delete();throw e;}
    }
    private static void checkSpace(File file,long written)throws IOException{if(written>512L*1024*1024)throw new IOException("DJ deck limit: 512 MB of decoded audio per track");if(file.getUsableSpace()<16L*1024*1024)throw new IOException("Free some phone storage before loading a DJ deck");}
    private static int write(OutputStream out,ByteBuffer b,int channels,int encoding)throws IOException{
        b.order(ByteOrder.LITTLE_ENDIAN);int bytes=encoding==4||encoding==22?4:encoding==21?3:encoding==3?1:2;if(channels<1||channels>8)throw new IOException("Unsupported channel layout");int frames=b.remaining()/(channels*bytes);byte[] converted=new byte[frames*4];
        for(int i=0;i<frames;i++){float l=0,r=0;for(int ch=0;ch<channels;ch++){float v;
            if(encoding==4)v=b.getFloat();else if(encoding==3)v=((b.get()&255)-128)/128f;else if(encoding==22)v=b.getInt()/2147483648f;else if(encoding==21){int n=(b.get()&255)|((b.get()&255)<<8)|(b.get()<<16);v=n/8388608f;}else v=b.getShort()/32768f;
            if(ch==0)l=v;if(ch==1)r=v;
        }if(channels==1)r=l;int a=Math.max(-32768,Math.min(32767,Math.round(l*32767))),c=Math.max(-32768,Math.min(32767,Math.round(r*32767)));converted[i*4]=(byte)a;converted[i*4+1]=(byte)(a>>>8);converted[i*4+2]=(byte)c;converted[i*4+3]=(byte)(c>>>8);}
        out.write(converted);return converted.length;
    }
}
