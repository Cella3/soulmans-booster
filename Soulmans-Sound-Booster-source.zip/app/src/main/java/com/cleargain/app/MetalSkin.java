package com.cleargain.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

final class MetalSkin {
    static final int INK = 0xff222a32, MUTED = 0xff4d5961, GOLD = 0xff836027, LIGHT_GOLD = 0xffefcf83;
    static Typeface nameplate(Context context) {
        try { return new Typeface.Builder(context.getAssets(), "fonts/CormorantGaramond.ttf").setWeight(600).build(); }
        catch (RuntimeException unavailable) { return Typeface.create("serif", Typeface.BOLD); }
    }
    static void button(TextView view) {
        view.setTextColor(INK); view.setBackground(new MetalPanelDrawable(view.getContext(), 9, true));
        view.setShadowLayer(.6f, 0, 1, 0xaaffffff);
    }
    /** Only the full player's surface is reskinned; the sample pads retain their color identities. */
    static void playerSurface(View root) {
        if (root instanceof TextView) {
            TextView view = (TextView) root;
            String description = view.getContentDescription() == null ? "" : view.getContentDescription().toString();
            if (!description.startsWith("Sampler pad")) {
                if (view.isClickable() && !(view instanceof CheckBox)) button(view);
                else view.setTextColor(MUTED);
            }
        }
        if (root instanceof SeekBar) {
            SeekBar view = (SeekBar) root;
            view.setProgressTintList(ColorStateList.valueOf(GOLD)); view.setThumbTintList(ColorStateList.valueOf(GOLD));
            view.setProgressBackgroundTintList(ColorStateList.valueOf(0xff778188));
        }
        if (root instanceof ViewGroup) for (int i = 0; i < ((ViewGroup) root).getChildCount(); i++) playerSurface(((ViewGroup) root).getChildAt(i));
    }
}
