package com.cleargain.app;

import android.content.Context;
import android.graphics.*;
import android.view.View;

final class VisualizerView extends View {
    private final Paint p=new Paint(3);
    private final Path path=new Path();
    private final float[] smooth=new float[32];
    private int style;
    private boolean playing;
    private SoundProcessor source;
    VisualizerView(Context c){super(c);setContentDescription("Music reactive visualizer");setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
    void state(SoundProcessor s,boolean playing,int style){source=s;this.playing=playing;this.style=style;invalidate();}
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);float w=getWidth(),h=getHeight();
        boolean active=playing&&source!=null&&android.os.SystemClock.elapsedRealtime()-source.capturedAt<600;
        float[] bars=active?source.spectrum:new float[32];float level=0;
        for(int i=0;i<32;i++){smooth[i]+=(bars[i]-smooth[i])*.25f;level+=smooth[i]/32;}
        p.setStyle(Paint.Style.FILL);
        if(style==0){
            float bw=w/32;
            for(int i=0;i<32;i++){p.setColor(Color.HSVToColor(220,new float[]{175+i*4, .8f,1}));float height=Math.max(2,smooth[i]*h*.88f);c.drawRoundRect(i*bw+2,h-height,(i+1)*bw-2,h,4,4,p);}
        }else if(style==1){
            float[] wave=active?source.waveform:new float[128];p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);
            for(int layer=0;layer<3;layer++){p.setColor(new int[]{0xee35e5f7,0xbb976bff,0x99ff57af}[layer]);path.reset();for(int i=0;i<128;i++){float x=w*i/127,y=h/2+wave[i]*h*(.40f-layer*.075f)+layer*4;if(i==0)path.moveTo(x,y);else path.lineTo(x,y);}c.drawPath(path,p);}
        }else if(style==2){
            float r=Math.min(w,h)*(.25f+level*.18f),cx=w/2,cy=h/2;
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);
            for(int i=0;i<64;i++){float angle=(float)(i*Math.PI/32),a=r,b=r+smooth[i%32]*Math.min(w,h)*.35f;p.setColor(Color.HSVToColor(new float[]{175+i*2.6f,.75f,1}));c.drawLine(cx+(float)Math.cos(angle)*a,cy+(float)Math.sin(angle)*a,cx+(float)Math.cos(angle)*b,cy+(float)Math.sin(angle)*b,p);}
            p.setColor(0xaa6cf4ff);c.drawCircle(cx,cy,r,p);
        }else {
            p.setStyle(Paint.Style.STROKE);
            for(int i=0;i<5;i++){p.setStrokeWidth(2+level*8);p.setColor(Color.HSVToColor((int)(100+level*100),new float[]{180+i*25,.7f,1}));float gap=10+i*10+level*30;c.drawRoundRect(gap,gap,w-gap,h-gap,24,24,p);}
        }
        if(playing&&isShown())postInvalidateDelayed(33);
    }
}
