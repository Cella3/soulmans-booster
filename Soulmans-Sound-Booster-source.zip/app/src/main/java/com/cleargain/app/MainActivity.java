package com.cleargain.app;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private static final int WHITE = 0xfff5f8fa;
    private static final int MUTED = 0xffa8bac7;
    private static final int RED = 0xffff4938;
    private static final int CYAN = 0xff26dcf8;

    private SharedPreferences prefs;
    private AudioManager audio;
    private BoostButtonView boostButton;
    private SeekBar volumeSeek;
    private TextView gainValue;
    private TextView volumeValue;
    private TextView status;
    private EqBandView eqView;
    private final TextView[] presetChips = new TextView[EqProfile.PRESETS.length];

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            boolean active = intent.getBooleanExtra("active", false);
            boostButton.setActive(active);
            String message = intent.getStringExtra("message");
            if (message != null) status.setText(message);
            status.setTextColor(active ? 0xffa3f7ed : 0xffffb1a5);
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        EqProfile.ensureDefaults(prefs);
        audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(0xff080a10);
        buildScreen();
    }

    @Override protected void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter(BoostService.ACTION_STATE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(stateReceiver, filter);
        refreshVolume();
        boostButton.setActive(prefs.getBoolean("enabled", false));
        if (prefs.getBoolean("enabled", false)) startEffects();
    }

    @Override protected void onPause() {
        unregisterReceiver(stateReceiver);
        super.onPause();
    }

    private void buildScreen() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xff080a10);
        setContentView(root);

        ImageView background = new ImageView(this);
        background.setImageResource(R.drawable.hero_background);
        background.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(background, new FrameLayout.LayoutParams(-1, -1));

        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x71070a13, 0x00101622, 0x29080c17, 0x77050910}));
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.brand_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setContentDescription("Soulmans Sound Booster");
        FrameLayout.LayoutParams logoParams = new FrameLayout.LayoutParams(-1, dp(133), Gravity.TOP);
        logoParams.leftMargin = dp(7);
        logoParams.rightMargin = dp(7);
        logoParams.topMargin = dp(29);
        root.addView(logo, logoParams);

        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        int panelHeight = Math.min(dp(410), (int) (screenHeight * 0.49f));
        ScrollView panel = new ScrollView(this);
        panel.setFillViewport(false);
        panel.setVerticalScrollBarEnabled(false);
        panel.setBackground(panelBackground());
        panel.setClipToOutline(true);
        panel.setElevation(dp(12));
        FrameLayout.LayoutParams panelParams = new FrameLayout.LayoutParams(-1, panelHeight, Gravity.BOTTOM);
        panelParams.leftMargin = dp(10);
        panelParams.rightMargin = dp(10);
        panelParams.bottomMargin = dp(10);
        root.addView(panel, panelParams);

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.VERTICAL);
        controls.setPadding(dp(16), dp(68), dp(16), dp(13));
        panel.addView(controls);

        gainValue = label("+" + prefs.getInt("gain_db", 4) + " dB", 16, 0xffffc55d);
        controls.addView(row("BOOST", gainValue));
        SeekBar gainSeek = slider(RED);
        gainSeek.setContentDescription("Extra boost in decibels");
        gainSeek.setMax(12);
        gainSeek.setProgress(prefs.getInt("gain_db", 4));
        controls.addView(gainSeek, new LinearLayout.LayoutParams(-1, dp(37)));
        gainSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                gainValue.setText("+" + value + " dB");
                if (fromUser) {
                    prefs.edit().putInt("gain_db", value).apply();
                    if (prefs.getBoolean("enabled", false)) startEffects();
                }
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });

        volumeValue = label("", 13, CYAN);
        controls.addView(row("MEDIA", volumeValue));
        volumeSeek = slider(CYAN);
        volumeSeek.setContentDescription("Phone and Bluetooth media volume");
        int minVolume = Build.VERSION.SDK_INT >= 28
                ? audio.getStreamMinVolume(AudioManager.STREAM_MUSIC) : 0;
        int maxVolume = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        volumeSeek.setMax(Math.max(1, maxVolume - minVolume));
        controls.addView(volumeSeek, new LinearLayout.LayoutParams(-1, dp(36)));
        volumeSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                volumeValue.setText((value + minVolume) + " / " + maxVolume);
                if (fromUser) {
                    try { audio.setStreamVolume(AudioManager.STREAM_MUSIC, value + minVolume, 0); }
                    catch (SecurityException e) { status.setText("Android blocked this volume change."); }
                }
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { }
            @Override public void onStopTrackingTouch(SeekBar bar) { }
        });

        LinearLayout presets = new LinearLayout(this);
        presets.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams presetRowParams = new LinearLayout.LayoutParams(-1, dp(38));
        presetRowParams.topMargin = dp(5);
        controls.addView(presets, presetRowParams);
        for (int i = 0; i < EqProfile.PRESETS.length; i++) {
            final String name = EqProfile.PRESETS[i];
            TextView chip = label(name.toUpperCase(), 11, WHITE);
            chip.setGravity(Gravity.CENTER);
            chip.setClickable(true);
            chip.setContentDescription(name + " equalizer preset");
            LinearLayout.LayoutParams chipParams = new LinearLayout.LayoutParams(0, -1, 1f);
            chipParams.leftMargin = dp(2);
            chipParams.rightMargin = dp(2);
            presets.addView(chip, chipParams);
            presetChips[i] = chip;
            chip.setOnClickListener(view -> {
                EqProfile.setPreset(prefs, name);
                eqView.setLevels(EqProfile.levels(prefs));
                refreshPresets();
                if (prefs.getBoolean("enabled", false)) startEffects();
            });
        }
        refreshPresets();

        TextView eqTitle = label("7-BAND EQ", 12, 0xffd8edf3);
        LinearLayout.LayoutParams eqTitleParams = new LinearLayout.LayoutParams(-1, -2);
        eqTitleParams.topMargin = dp(8);
        controls.addView(eqTitle, eqTitleParams);
        eqView = new EqBandView(this);
        eqView.setLevels(EqProfile.levels(prefs));
        eqView.setOnChange((index, db) -> {
            EqProfile.setBand(prefs, index, db);
            refreshPresets();
            if (prefs.getBoolean("enabled", false)) startEffects();
        });
        controls.addView(eqView, new LinearLayout.LayoutParams(-1, dp(111)));

        status = label(prefs.getBoolean("enabled", false) ? "Starting boost…" : "BOOST OFF · tap the big button", 12,
                prefs.getBoolean("enabled", false) ? 0xffa3f7ed : MUTED);
        status.setGravity(Gravity.CENTER_HORIZONTAL);
        controls.addView(status, new LinearLayout.LayoutParams(-1, -2));
        TextView caution = label("Start low. High boost can distort sound.", 10, MUTED);
        caution.setGravity(Gravity.CENTER_HORIZONTAL);
        controls.addView(caution, new LinearLayout.LayoutParams(-1, -2));

        boostButton = new BoostButtonView(this);
        boostButton.setActive(prefs.getBoolean("enabled", false));
        FrameLayout.LayoutParams buttonParams = new FrameLayout.LayoutParams(
                dp(143), dp(143), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        buttonParams.bottomMargin = panelHeight - dp(62) + dp(10);
        root.addView(boostButton, buttonParams);
        boostButton.setOnClickListener(view -> toggleBoost());
    }

    private void toggleBoost() {
        boolean enabled = !prefs.getBoolean("enabled", false);
        prefs.edit().putBoolean("enabled", enabled).apply();
        boostButton.setActive(enabled);
        if (enabled) {
            status.setText("Starting boost…");
            status.setTextColor(0xffa3f7ed);
            if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
            }
            startEffects();
        } else {
            stopService(new Intent(this, BoostService.class));
            status.setText("BOOST OFF · tap the big button");
            status.setTextColor(MUTED);
        }
    }

    private void startEffects() {
        Intent intent = new Intent(this, BoostService.class).setAction(BoostService.ACTION_APPLY);
        try { startForegroundService(intent); }
        catch (RuntimeException e) {
            prefs.edit().putBoolean("enabled", false).apply();
            boostButton.setActive(false);
            status.setText("Android blocked the boost service.");
            status.setTextColor(0xffffb1a5);
        }
    }

    private void refreshVolume() {
        int min = Build.VERSION.SDK_INT >= 28
                ? audio.getStreamMinVolume(AudioManager.STREAM_MUSIC) : 0;
        volumeSeek.setEnabled(!audio.isVolumeFixed());
        volumeSeek.setProgress(audio.getStreamVolume(AudioManager.STREAM_MUSIC) - min);
    }

    private void refreshPresets() {
        String selected = prefs.getString("eq_preset", "Bass");
        for (int i = 0; i < presetChips.length; i++) {
            TextView chip = presetChips[i];
            if (chip == null) continue;
            boolean active = EqProfile.PRESETS[i].equals(selected);
            GradientDrawable shape = new GradientDrawable();
            shape.setColor(active ? 0xff3b1820 : 0xff16202d);
            shape.setCornerRadius(dp(13));
            shape.setStroke(dp(1), active ? 0xffff5e3c : 0xff536578);
            chip.setBackground(shape);
            chip.setTextColor(active ? 0xffffc05c : WHITE);
        }
    }

    private LinearLayout row(String title, TextView value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView left = label(title, 15, WHITE);
        left.setTypeface(null, 1);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(value);
        return row;
    }

    private TextView label(String text, float size, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setFontFeatureSettings("kern");
        return view;
    }

    private SeekBar slider(int accent) {
        SeekBar bar = new SeekBar(this);
        bar.setProgressTintList(ColorStateList.valueOf(accent));
        bar.setThumbTintList(ColorStateList.valueOf(accent));
        bar.setProgressBackgroundTintList(ColorStateList.valueOf(0xff3b4857));
        return bar;
    }

    private GradientDrawable panelBackground() {
        GradientDrawable shape = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xe9141b28, 0xf208101c});
        shape.setCornerRadius(dp(26));
        shape.setStroke(dp(1), 0xff475768);
        return shape;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
