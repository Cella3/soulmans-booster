package com.cleargain.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.*;
import android.view.*;
import android.widget.*;
import androidx.media3.common.*;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;
import com.google.common.util.concurrent.ListenableFuture;
import org.json.JSONArray;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
public final class MainActivity extends Activity {
    private static final int WHITE=0xfff4f4ff,MUTED=0xffa0aac5,CYAN=0xff38e5ed,PINK=0xffee62bb,BG=0xff090d1a;
    private static final int FILES=10,FOLDER=11,PAD=20,EXPORT_PAD=21,EXPORT_VIDEO=22,CAPTURE_PHONE=23,EXPORT_RECORDING=24,OVERLAY_PERMISSION=25,RECORD_PERMISSION=60;
    private static final int[] PAD_COLORS={0xffff4d91,0xff38e5ed,0xffffbf4d,0xffb47cff};
    private SharedPreferences prefs;
    private MusicStore store;
    private MediaController controller;
    private ListenableFuture<MediaController> future;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private FrameLayout root,content;
    private LinearLayout nav;
    private int tab=0,libraryTab=0,pendingPad=-1;
    private String shownUri="!",search="";
    private boolean dragging,visible,importing;
    private TextView title,artist,time,play,repeat,shuffle,playStatus,importStatus,pitchLabel,fullScreenButton,videoClipButton;
    private SeekBar seek,pitchSlider;
    private ImageView cover;
    private View coverFade;
    private PlayerView videoView,saverVideo;
    private VideoGestureOverlay playerGesture,saverGesture;
    private WaveformView waveform;
    private WaveformControls waveformControls;
    private ReelToReelView reelDeck;
    private String waveformUri="!";
    private float[] waveformPeaks;
    private Bitmap currentArt;
    private VisualizerView visual;
    private final TextView[] padButtons=new TextView[4];
    private ListView libraryList;
    private Dialog saver;
    private AlertDialog padEditor;
    private AlertDialog recordingDialog;
    private TextView recordButton,recordingTime,recordingStatus,recordingPause,recordingSave;
    private ProgressBar recordingMeter;
    private Bundle pendingRecording;
    private String pendingRecordingExport="";
    private boolean pendingMiniPlayer;
    private AlertDialog videoExportDialog;
    private VideoClipExporter videoExporter;
    private TextView videoExportStatus;
    private SeekBar videoExportProgress;
    private String pendingVideoSource="";
    private long pendingVideoStart,pendingVideoEnd;
    private int pendingVideoQuality,pendingVideoType;
    private final Runnable videoExportTick=new Runnable(){public void run(){if(videoExporter==null)return;int value=videoExporter.progressPercent();if(videoExportProgress!=null&&value>=0)videoExportProgress.setProgress(value);if(videoExportStatus!=null)videoExportStatus.setText(value<0?"Preparing your video…":"Encoding clip · "+value+"%");handler.postDelayed(this,300);}};
    private VisualizerView saverVisual;
    private ImageView saverArt;
    private TextView saverTitle;
    private long touched=SystemClock.elapsedRealtime();
    private final Runnable tick=new Runnable(){public void run(){if(visible){refresh();handler.postDelayed(this,250);}}};
    private final Player.Listener listener=new Player.Listener(){
        @Override public void onEvents(Player player,Player.Events events){refresh();}
        @Override public void onMediaItemTransition(MediaItem item,int reason){shownUri="!";refresh();if(tab==1)loadLibrary();}
    };

    @Override public void onCreate(Bundle state){
        super.onCreate(state);prefs=getSharedPreferences("settings",MODE_PRIVATE);store=MusicStore.get(this);EqProfile.ensureDefaults(prefs);
        setVolumeControlStream(AudioManager.STREAM_MUSIC);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        if(state!=null){tab=state.getInt("tab",0);libraryTab=state.getInt("library_tab",0);pendingPad=state.getInt("pending_pad",-1);pendingRecording=state.getBundle("pending_recording");pendingRecordingExport=state.getString("recording_export","");if(state.getBoolean("recording_dialog_open",false))getIntent().putExtra("open_recorder",true);}
        worker.execute(()->RecordingStore.recover(this));
        if(state==null&&getIntent().hasExtra("open_tab"))tab=Math.max(0,Math.min(2,getIntent().getIntExtra("open_tab",0)));
        pendingMiniPlayer=state!=null&&state.getBoolean("pending_mini",false);
        if(getIntent().getBooleanExtra("close_mini",false)){FloatingPlayerService.hide(this);getIntent().removeExtra("close_mini");}
        buildShell();
    }
    @Override protected void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);b.putInt("tab",tab);b.putInt("library_tab",libraryTab);b.putInt("pending_pad",pendingPad);b.putBundle("pending_recording",pendingRecording);b.putString("recording_export",pendingRecordingExport);b.putBoolean("pending_mini",pendingMiniPlayer);b.putBoolean("recording_dialog_open",recordingDialog!=null&&recordingDialog.isShowing());}
    @Override protected void onStart(){
        super.onStart();visible=true;touched=SystemClock.elapsedRealtime();
        future=new MediaController.Builder(this,new SessionToken(this,new ComponentName(this,PlaybackService.class))).buildAsync();
        ListenableFuture<MediaController> connecting=future;
        connecting.addListener(()->{try{if(!visible||future!=connecting)return;controller=connecting.get();controller.addListener(listener);refresh();if(tab==1)loadLibrary();}catch(Exception e){toast("Couldn’t connect to the player. Reopen the app.");}},r->handler.post(r));handler.post(tick);
    }
    @Override protected void onStop(){visible=false;handler.removeCallbacks(tick);closeSaver();if(reelDeck!=null)reelDeck.pauseAnimation();if(videoView!=null)videoView.setPlayer(null);if(PlaybackService.live!=null)PlaybackService.live.saveQueue();if(controller!=null)controller.removeListener(listener);if(future!=null)MediaController.releaseFuture(future);controller=null;super.onStop();}
    @Override protected void onResume(){super.onResume();if(pendingMiniPlayer&&Settings.canDrawOverlays(this)){pendingMiniPlayer=false;launchMiniPlayer();}}
    @Override protected void onDestroy(){if(recordingDialog!=null)recordingDialog.dismiss();worker.shutdown();super.onDestroy();}
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);if(intent.getBooleanExtra("close_mini",false)){FloatingPlayerService.hide(this);intent.removeExtra("close_mini");}if(intent.hasExtra("open_tab")){closeSaver();showTab(Math.max(0,Math.min(2,intent.getIntExtra("open_tab",0))));}if(intent.getBooleanExtra("open_recorder",false)&&RecordingService.live!=null)showRecordingSession();}
    @Override public boolean dispatchTouchEvent(MotionEvent event){touched=SystemClock.elapsedRealtime();return super.dispatchTouchEvent(event);}

    private void buildShell(){
        root=new FrameLayout(this);root.setBackgroundColor(BG);setContentView(root);
        LinearLayout shell=column();root.addView(shell,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout header=row();header.setPadding(dp(18),dp(8),dp(18),dp(8));header.setBackground(new MetalPanelDrawable(this,8,true));
        LinearLayout inscription=column();TextView brand=label("Soulman's Media Player",29,MetalSkin.INK);brand.setTypeface(MetalSkin.nameplate(this));brand.setSingleLine(true);brand.setAutoSizeTextTypeUniformWithConfiguration(19,29,1,android.util.TypedValue.COMPLEX_UNIT_SP);inscription.addView(brand,new LinearLayout.LayoutParams(-1,dp(34)));TextView sub=label("SILVER & GOLD  /  PRECISION SOUND",8,MetalSkin.GOLD);sub.setLetterSpacing(.08f);inscription.addView(sub);header.addView(inscription,new LinearLayout.LayoutParams(0,-2,1));
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.app_icon_excited);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);logo.setContentDescription("Soulman's excited smiling face");header.addView(logo,new LinearLayout.LayoutParams(dp(54),dp(54)));shell.addView(header);
        content=new FrameLayout(this);shell.addView(content,new LinearLayout.LayoutParams(-1,0,1));
        nav=row();nav.setPadding(dp(12),dp(6),dp(12),dp(8));nav.setBackground(new MetalPanelDrawable(this,8,true));shell.addView(nav);
        for(int i=0;i<3;i++){final int n=i;TextView b=button(new String[]{"NOW PLAYING","LIBRARY","SOUND"}[i],()->showTab(n));b.setTextSize(11);nav.addView(b,weight(52));}showTab(tab);
    }
    private void showTab(int n){
        if(videoView!=null)videoView.setPlayer(null);
        tab=n;shownUri="!";waveformUri="!";waveformPeaks=null;content.removeAllViews();title=null;artist=null;seek=null;cover=null;coverFade=null;videoView=null;playerGesture=null;waveform=null;waveformControls=null;visual=null;play=null;playStatus=null;pitchSlider=null;pitchLabel=null;fullScreenButton=null;videoClipButton=null;libraryList=null;importStatus=null;recordButton=null;Arrays.fill(padButtons,null);
        reelDeck=null;for(int i=0;i<3;i++){TextView t=(TextView)nav.getChildAt(i);t.setTextColor(i==tab?MetalSkin.GOLD:MetalSkin.MUTED);t.setBackground(new MetalPanelDrawable(this,14,i==tab));}
        if(n==0)buildPlayer();else if(n==1)buildLibrary();else buildSound();refresh();
    }
    private LinearLayout scrolling(){ScrollView s=new ScrollView(this);s.setFillViewport(true);s.setVerticalScrollBarEnabled(false);content.addView(s,new FrameLayout.LayoutParams(-1,-1));LinearLayout body=column();body.setPadding(dp(18),dp(8),dp(18),dp(20));s.addView(body);return body;}
    private void buildPlayer(){
        LinearLayout body=scrolling();body.setBackground(new MetalPanelDrawable(this,12,true));LinearLayout top=row();top.addView(label("SIGNATURE TAPE DECK",10,CYAN),new LinearLayout.LayoutParams(0,-2,1));videoClipButton=button("CLIP ↗",this::openCurrentVideoClipEditor);videoClipButton.setVisibility(View.GONE);top.addView(videoClipButton,new LinearLayout.LayoutParams(dp(78),dp(42)));fullScreenButton=button("VISUALS ↗",this::openSaver);top.addView(fullScreenButton,new LinearLayout.LayoutParams(dp(116),dp(42)));body.addView(top);
        TextView mini=button("MINI PLAYER ↘  ·  FLOAT OVER OTHER APPS",this::openMiniPlayer);mini.setTextColor(CYAN);mini.setContentDescription("Open floating mini player");LinearLayout.LayoutParams miniParams=new LinearLayout.LayoutParams(-1,dp(44));miniParams.setMargins(0,0,0,dp(8));body.addView(mini,miniParams);
        FrameLayout art=new FrameLayout(this);art.setBackground(new MetalPanelDrawable(this,14,true));art.setPadding(dp(3),dp(3),dp(3),dp(3));art.setClipToOutline(true);
        int width=getResources().getDisplayMetrics().widthPixels;int h=Math.min(dp(160),Math.round((width-dp(36))*.44f));body.addView(art,new LinearLayout.LayoutParams(-1,h));
        cover=new ImageView(this);cover.setImageResource(R.drawable.speaker_blast);cover.setScaleType(ImageView.ScaleType.FIT_CENTER);cover.setContentDescription("Album art, or Soulmans speaker-blast portrait");art.addView(cover,new FrameLayout.LayoutParams(-1,-1));
        coverFade=new View(this);coverFade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0x00101929,0x00101929,0xe6090d1a}));art.addView(coverFade,new FrameLayout.LayoutParams(-1,-1));
        visual=new VisualizerView(this);FrameLayout.LayoutParams vp=new FrameLayout.LayoutParams(-1,dp(100),Gravity.BOTTOM);vp.setMargins(dp(16),0,dp(16),dp(14));art.addView(visual,vp);
        videoView=new PlayerView(this);videoView.setUseController(false);videoView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);videoView.setBackgroundColor(0xff000000);videoView.setContentDescription("Video preview; pinch to zoom, drag to frame, double tap to reset");videoView.setVisibility(View.GONE);art.addView(videoView,new FrameLayout.LayoutParams(-1,-1));playerGesture=addVideoGestures(videoView,false);
        reelDeck=new ReelToReelView(this);LinearLayout.LayoutParams reelParams=new LinearLayout.LayoutParams(-1,dp(166));reelParams.topMargin=dp(8);body.addView(reelDeck,reelParams);
        title=label("Your music. Your rules.",25,WHITE);title.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);margin(body,title,14);
        artist=label("Add files or a folder to start listening",13,MUTED);body.addView(artist);
        seek=slider(CYAN);seek.setMax(1000);seek.setContentDescription("Track position");body.addView(seek,new LinearLayout.LayoutParams(-1,dp(42)));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){dragging=true;}public void onProgressChanged(SeekBar s,int p,boolean user){if(user&&controller!=null&&controller.getDuration()>0)time.setText(clock(controller.getDuration()*p/1000)+"  /  "+clock(controller.getDuration()));}public void onStopTrackingTouch(SeekBar s){if(controller!=null&&controller.getDuration()>0)controller.seekTo(controller.getDuration()*s.getProgress()/1000);dragging=false;}});
        time=label("0:00  /  0:00",11,MUTED);time.setGravity(Gravity.RIGHT);body.addView(time);
        waveform=new WaveformView(this);waveform.setVisibility(View.GONE);waveform.setSeekListener(fraction->{if(controller!=null&&controller.getDuration()>0&&controller.isCurrentMediaItemSeekable())controller.seekTo((long)(controller.getDuration()*fraction));});body.addView(waveform,new LinearLayout.LayoutParams(-1,dp(76)));
        waveformControls=new WaveformControls(this,waveform.viewport(),waveform::position,"FULL SONG");waveformControls.setVisibility(View.GONE);body.addView(waveformControls,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout transport=row();shuffle=button("⇄",()->{if(ready())controller.setShuffleModeEnabled(!controller.getShuffleModeEnabled());});shuffle.setContentDescription("Shuffle");transport.addView(shuffle,weight(58));
        TextView prev=button("❮❮",()->{if(ready())controller.seekToPrevious();});prev.setContentDescription("Previous track");transport.addView(prev,weight(58));
        play=button("▶",this::togglePlay);play.setTextSize(27);play.setTextColor(BG);play.setBackground(shape(CYAN,CYAN,30));play.setContentDescription("Play or pause");transport.addView(play,new LinearLayout.LayoutParams(dp(74),dp(64)));
        TextView next=button("❯❯",()->{if(ready())controller.seekToNext();});next.setContentDescription("Next track");transport.addView(next,weight(58));
        repeat=button("↻",()->{if(ready())controller.setRepeatMode((controller.getRepeatMode()+1)%3);});repeat.setContentDescription("Repeat mode");transport.addView(repeat,weight(58));margin(body,transport,7);
        playStatus=label("",11,MUTED);playStatus.setGravity(Gravity.CENTER);margin(body,playStatus,7);
        LinearLayout ph=row();ph.addView(label("MPC SAMPLE DECK",11,PINK),new LinearLayout.LayoutParams(0,-2,1));ph.addView(button("STOP ALL",()->{if(PlaybackService.live!=null)PlaybackService.live.stopPads();refresh();}),new LinearLayout.LayoutParams(dp(92),dp(40)));margin(body,ph,12);
        LinearLayout recordActions=row();recordButton=button("● RECORD",()->showRecordingOptions(-1));recordButton.setTextColor(PINK);recordActions.addView(recordButton,weight(44));recordActions.addView(button("EDIT PADS",this::choosePadToEdit),weight(44));recordActions.addView(button("SAVED TAKES",this::showSavedTakes),weight(44));margin(body,recordActions,5);
        final boolean[] gateClickSuppressed=new boolean[4];
        for(int rowIndex=0;rowIndex<2;rowIndex++){LinearLayout pads=row();for(int col=0;col<2;col++){final int index=rowIndex*2+col;TextView pad=button("",()->{if(prefs.getInt("pad_trigger_"+index,0)==2&&gateClickSuppressed[index]){gateClickSuppressed[index]=false;return;}tapPad(index);});pad.setTextSize(13);pad.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));pad.setMaxLines(3);pad.setEllipsize(TextUtils.TruncateAt.END);pad.setOnLongClickListener(v->{padOptions(index);return true;});pad.setOnTouchListener((v,event)->{if(prefs.getInt("pad_trigger_"+index,0)!=2)return false;if(event.getAction()==MotionEvent.ACTION_DOWN){gateClickSuppressed[index]=true;if(prefs.getString("pad_uri_"+index,"").isEmpty())selectPadFile(index);else if(PlaybackService.live!=null)PlaybackService.live.triggerPad(index);return true;}if(event.getAction()==MotionEvent.ACTION_UP||event.getAction()==MotionEvent.ACTION_CANCEL){if(PlaybackService.live!=null)PlaybackService.live.stopPad(index);pad.performClick();refresh();return true;}return true;});padButtons[index]=pad;LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(0,dp(82),1);pp.setMargins(dp(3),dp(3),dp(3),dp(3));pads.addView(pad,pp);}body.addView(pads);}
        TextView hint=label("Tap to fire • hold to edit • RECORD samples phone audio or your mic",10,MUTED);hint.setGravity(Gravity.CENTER);margin(body,hint,6);
        LinearLayout imports=row();imports.addView(button("＋ FILES",()->pickFiles(FILES)),weight(46));imports.addView(button("＋ FOLDER",this::pickFolder),weight(46));margin(body,imports,14);
        MetalSkin.playerSurface(body);title.setTextColor(MetalSkin.INK);waveform.setBackground(shape(0xff101c26,0xffa18748,10));
    }
    private boolean ready(){if(controller==null){toast("Player is connecting…");return false;}return true;}
    private void togglePlay(){if(!ready())return;if(controller.getMediaItemCount()==0){showTab(1);return;}if(controller.isPlaying())controller.pause();else{notifications();if(controller.getPlaybackState()==Player.STATE_ENDED)controller.seekToDefaultPosition();controller.prepare();controller.play();}}
    private void notifications(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED&&!prefs.getBoolean("asked_notifications",false)){prefs.edit().putBoolean("asked_notifications",true).apply();requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},42);}}
    private void openMiniPlayer(){
        if(!Settings.canDrawOverlays(this)){
            new AlertDialog.Builder(this).setTitle("FLOATING MINI PLAYER").setMessage("Allow Display over other apps for Soulmans. The mini player shows a live music waveform or video, and you can drag its title bar to move it. Return here after enabling the switch.").setPositiveButton("OPEN ANDROID SETTINGS",(d,w)->{pendingMiniPlayer=true;try{startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())),OVERLAY_PERMISSION);}catch(ActivityNotFoundException error){pendingMiniPlayer=false;toast("Display over other apps settings are unavailable on this device.");}}).setNegativeButton("CANCEL",null).show();return;
        }
        launchMiniPlayer();
    }
    private void launchMiniPlayer(){
        pendingMiniPlayer=false;closeSaver();if(videoView!=null)videoView.setPlayer(null);
        try{startForegroundService(new Intent(this,FloatingPlayerService.class).setAction(FloatingPlayerService.OPEN));moveTaskToBack(true);}catch(RuntimeException error){toast("The mini player could not start. Check Display over other apps in Android settings.");}
    }
    private void tapPad(int i){if(prefs.getString("pad_uri_"+i,"").isEmpty()){selectPadFile(i);}else if(PlaybackService.live!=null){int trigger=prefs.getInt("pad_trigger_"+i,0);if(trigger==2){if(PlaybackService.live.padPlaying(i))PlaybackService.live.stopPad(i);else PlaybackService.live.triggerPad(i);}else PlaybackService.live.triggerPad(i);refresh();}}
    private void selectPadFile(int index){pendingPad=index;pickFiles(PAD);}
    private void padOptions(int i){openPadEditor(i);}
    private void choosePadToEdit(){
        String[] choices=new String[4];
        for(int i=0;i<4;i++){String name=prefs.getString("pad_name_"+i,"");choices[i]=String.format(Locale.US,"PAD %02d  ·  %s",i+1,name.isEmpty()?"LOAD SAMPLE":name);}
        new AlertDialog.Builder(this).setTitle("Choose an MPC pad").setItems(choices,(dialog,index)->openPadEditor(index)).setNegativeButton("CLOSE",null).show();
    }

    private void openPadEditor(int index){
        final int pad=index;String uri=prefs.getString("pad_uri_"+pad,"");
        if(uri.isEmpty()){new AlertDialog.Builder(this).setTitle("MPC Pad "+(pad+1)).setMessage("Load a file or record phone audio / microphone into this pad.").setNegativeButton("CLOSE",null).setNeutralButton("RECORD",(d,w)->showRecordingOptions(pad)).setPositiveButton("LOAD SAMPLE",(d,w)->selectPadFile(pad)).show();return;}
        worker.execute(()->{long measured=sampleDuration(Uri.parse(uri));runOnUiThread(()->{if(isDestroyed())return;int duration=(int)Math.min(Integer.MAX_VALUE,Math.max(measured,prefs.getInt("pad_duration_"+pad,0)));if(duration>0)prefs.edit().putInt("pad_duration_"+pad,duration).apply();showPadEditor(pad,duration);});});
    }
    private void showPadEditor(int pad,int duration){
        LinearLayout body=column();body.setPadding(dp(18),dp(4),dp(18),dp(8));
        TextView file=label("PAD "+String.format(Locale.US,"%02d",pad+1)+"  ·  "+prefs.getString("pad_name_"+pad,"Audio sample"),15,CYAN);file.setMaxLines(2);file.setEllipsize(TextUtils.TruncateAt.END);margin(body,file,5);
        LinearLayout fileActions=row();fileActions.addView(button("LOAD FILE",()->{if(PlaybackService.live!=null)PlaybackService.live.stopPad(pad);selectPadFile(pad);}),weight(42));fileActions.addView(button("RECORD NEW TAKE",()->{if(padEditor!=null)padEditor.dismiss();showRecordingOptions(pad);}),weight(42));body.addView(fileActions);

        int savedStart=Math.max(0,Math.min(duration,prefs.getInt("pad_start_"+pad,0)));
        int savedEnd=prefs.getInt("pad_end_"+pad,duration);if(savedEnd<=0||savedEnd>duration)savedEnd=duration;
        final int[] positions={savedStart,savedEnd};final TextView rangeLabel=label("IN  "+sampleClock(positions[0])+"       OUT  "+sampleClock(positions[1])+" / "+sampleClock(duration),12,WHITE);margin(body,rangeLabel,13);
        SampleWaveformView sampleWave=new SampleWaveformView(this);sampleWave.viewport().setDuration(duration);sampleWave.setSelection(duration==0?0:positions[0]/(float)duration,duration==0?1:positions[1]/(float)duration);body.addView(sampleWave,new LinearLayout.LayoutParams(-1,dp(76)));body.addView(new WaveformControls(this,sampleWave.viewport(),()->duration==0?0:positions[0]/(double)duration,"FULL FILE"),new LinearLayout.LayoutParams(-1,-2));loadSampleWaveform(pad,sampleWave);
        final SeekBar start=slider(PINK),end=slider(CYAN);start.setMax(1000);end.setMax(1000);start.setProgress(duration==0?0:Math.round(positions[0]*1000f/duration));end.setProgress(duration==0?1000:Math.round(positions[1]*1000f/duration));start.setEnabled(duration>0);end.setEnabled(duration>0);
        heading(body,"START / END","Choose the playable slice of the original sample");body.addView(start,new LinearLayout.LayoutParams(-1,dp(42)));body.addView(end,new LinearLayout.LayoutParams(-1,dp(42)));
        Runnable updateRange=()->{rangeLabel.setText("IN  "+sampleClock(positions[0])+"       OUT  "+sampleClock(positions[1])+" / "+sampleClock(duration));sampleWave.setSelection(duration==0?0:positions[0]/(float)duration,duration==0?1:positions[1]/(float)duration);};
        start.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar s,int value,boolean user){if(user){positions[0]=duration*value/1000;if(positions[0]>=positions[1]){positions[0]=Math.max(0,positions[1]-Math.min(25,duration));s.setProgress(duration==0?0:Math.round(positions[0]*1000f/duration));}updateRange.run();}}});
        end.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar s,int value,boolean user){if(user){positions[1]=duration*value/1000;if(positions[1]<=positions[0]){positions[1]=Math.min(duration,positions[0]+Math.min(25,duration));s.setProgress(duration==0?1000:Math.round(positions[1]*1000f/duration));}updateRange.run();}}});

        CheckBox loop=new CheckBox(this);loop.setText("LOOP THIS CLIP");loop.setTextColor(WHITE);loop.setButtonTintList(ColorStateList.valueOf(CYAN));loop.setChecked(prefs.getBoolean("pad_loop_"+pad,false));margin(body,loop,8);
        heading(body,"PAD TRIGGER","Choose what a press does");Spinner trigger=new Spinner(this);trigger.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"One-shot · retrigger on press","Toggle · press to start or stop","Gate · play only while held"}));trigger.setSelection(Math.max(0,Math.min(2,prefs.getInt("pad_trigger_"+pad,0))));body.addView(trigger,new LinearLayout.LayoutParams(-1,dp(48)));

        heading(body,"PITCH","Semitones · saved to this pad");TextView pitchLabel=label(""+prefs.getInt("pad_pitch_"+pad,0)+" st",12,MUTED);body.addView(pitchLabel);SeekBar pitch=slider(PINK);pitch.setMax(24);pitch.setProgress(Math.max(0,Math.min(24,prefs.getInt("pad_pitch_"+pad,0)+12)));body.addView(pitch,new LinearLayout.LayoutParams(-1,dp(40)));pitch.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar s,int v,boolean u){if(u)pitchLabel.setText((v-12)+" st");}});

        heading(body,"ENVELOPE","Fade in and out, up to 5 seconds each");LinearLayout fadeRow=row();SeekBar fadeIn=slider(CYAN),fadeOut=slider(PINK);fadeIn.setMax(1000);fadeOut.setMax(1000);fadeIn.setProgress(prefs.getInt("pad_fade_in_"+pad,0)/5);fadeOut.setProgress(prefs.getInt("pad_fade_out_"+pad,0)/5);fadeRow.addView(fadeIn,new LinearLayout.LayoutParams(0,dp(42),1));fadeRow.addView(fadeOut,new LinearLayout.LayoutParams(0,dp(42),1));body.addView(fadeRow);LinearLayout fadeCaptions=row();fadeCaptions.addView(label("IN  "+fadeIn.getProgress()*5+" ms",11,CYAN),new LinearLayout.LayoutParams(0,-2,1));fadeCaptions.addView(label("OUT  "+fadeOut.getProgress()*5+" ms",11,PINK),new LinearLayout.LayoutParams(0,-2,1));body.addView(fadeCaptions);
        TextView inValue=(TextView)fadeCaptions.getChildAt(0),outValue=(TextView)fadeCaptions.getChildAt(1);fadeIn.setOnSeekBarChangeListener(valueListener(v->inValue.setText("IN  "+v*5+" ms")));fadeOut.setOnSeekBarChangeListener(valueListener(v->outValue.setText("OUT  "+v*5+" ms")));

        heading(body,"ECHO","Wet mix and delay time");TextView echoValue=label("Echo  "+prefs.getInt("pad_echo_"+pad,0)+"%",11,MUTED);body.addView(echoValue);SeekBar echo=slider(PINK);echo.setMax(70);echo.setProgress(prefs.getInt("pad_echo_"+pad,0));body.addView(echo,new LinearLayout.LayoutParams(-1,dp(38)));echo.setOnSeekBarChangeListener(valueListener(v->echoValue.setText("Echo  "+v+"%")));
        TextView delayValue=label("Delay  "+prefs.getInt("pad_echo_delay_"+pad,220)+" ms",11,MUTED);body.addView(delayValue);SeekBar delay=slider(CYAN);delay.setMax(520);delay.setProgress(Math.max(0,Math.min(520,prefs.getInt("pad_echo_delay_"+pad,220)-80)));body.addView(delay,new LinearLayout.LayoutParams(-1,dp(38)));delay.setOnSeekBarChangeListener(valueListener(v->delayValue.setText("Delay  "+(v+80)+" ms")));
        margin(body,label("Export writes a separate PCM WAV copy; the loaded source stays unchanged. Trim to 60 seconds or less.",10,MUTED),10);
        LinearLayout exports=row();exports.addView(button("PREVIEW SLICE",()->{savePadSettings(pad,duration,positions[0],positions[1],loop.isChecked(),trigger.getSelectedItemPosition(),pitch.getProgress()-12,fadeIn.getProgress()*5,fadeOut.getProgress()*5,echo.getProgress(),delay.getProgress()+80);if(PlaybackService.live!=null)PlaybackService.live.triggerPad(pad);}),weight(48));exports.addView(button("SAVE NEW WAV",()->{savePadSettings(pad,duration,positions[0],positions[1],loop.isChecked(),trigger.getSelectedItemPosition(),pitch.getProgress()-12,fadeIn.getProgress()*5,fadeOut.getProgress()*5,echo.getProgress(),delay.getProgress()+80);savePadAsWav(pad);}),weight(48));margin(body,exports,14);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.addView(body);AlertDialog dialog=new AlertDialog.Builder(this).setTitle("MPC · SAMPLE "+String.format(Locale.US,"%02d",pad+1)).setView(scroll).setNegativeButton("DONE",(d,w)->{savePadSettings(pad,duration,positions[0],positions[1],loop.isChecked(),trigger.getSelectedItemPosition(),pitch.getProgress()-12,fadeIn.getProgress()*5,fadeOut.getProgress()*5,echo.getProgress(),delay.getProgress()+80);refresh();}).create();padEditor=dialog;dialog.setOnDismissListener(d->{if(padEditor==dialog)padEditor=null;});dialog.show();
    }
    private void buildLibrary(){
        LinearLayout body=column();body.setPadding(dp(16),dp(8),dp(16),0);content.addView(body,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout actions=row();actions.addView(button("＋ FILES",()->pickFiles(FILES)),weight(46));actions.addView(button("＋ FOLDER",this::pickFolder),weight(46));actions.addView(button("•••",this::libraryOptions),new LinearLayout.LayoutParams(dp(48),dp(46)));body.addView(actions);
        importStatus=label(importing?"Importing media…":"Local files • hold a track for options",11,MUTED);margin(body,importStatus,8);
        EditText filter=new EditText(this);filter.setSingleLine(true);filter.setTextColor(WHITE);filter.setHintTextColor(MUTED);filter.setTextSize(14);filter.setHint("Search audio and video");filter.setText(search);filter.setContentDescription("Search audio and video");body.addView(filter,new LinearLayout.LayoutParams(-1,dp(48)));
        filter.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){search=s.toString();loadLibrary();}public void afterTextChanged(Editable e){}});
        LinearLayout tabs=row();String[] labels={"TRACKS","LISTS","HISTORY","QUEUE"};for(int i=0;i<4;i++){final int n=i;TextView b=button(labels[i],()->{libraryTab=n;showTab(1);});b.setTextSize(10);b.setTextColor(i==libraryTab?CYAN:MUTED);tabs.addView(b,weight(44));}body.addView(tabs);
        libraryList=new ListView(this);libraryList.setDivider(new android.graphics.drawable.ColorDrawable(0xff242b40));libraryList.setDividerHeight(dp(1));body.addView(libraryList,new LinearLayout.LayoutParams(-1,0,1));loadLibrary();
    }
    private void libraryOptions(){new AlertDialog.Builder(this).setTitle("Your library").setItems(new String[]{"Save queue as playlist","New empty playlist","Rescan saved folders","Clear listening history"},(d,w)->{
        if(w==0)savePlaylist(queueUris());else if(w==1)savePlaylist(new ArrayList<>());else if(w==2)rescanFolders();else new AlertDialog.Builder(this).setMessage("Clear recent plays and play counts?").setNegativeButton("Cancel",null).setPositiveButton("Clear",(a,b)->{store.clearHistory();loadLibrary();}).show();}).show();}
    private void loadLibrary(){
        if(libraryList==null)return;
        List<String> primary=new ArrayList<>(),secondary=new ArrayList<>();List<Runnable> clicks=new ArrayList<>(),menus=new ArrayList<>();String term=search.toLowerCase(Locale.ROOT);
        if(libraryTab==1){
            primary.add("＋ Save queue as a playlist");secondary.add("Keep this listening order for later");clicks.add(()->savePlaylist(queueUris()));menus.add(()->savePlaylist(queueUris()));
            for(Map.Entry<Long,String> entry:store.playlists().entrySet())if(entry.getValue().toLowerCase(Locale.ROOT).contains(term)){
                long id=entry.getKey();String name=entry.getValue();List<Track> tracks=store.playlist(id);primary.add(name);secondary.add(tracks.size()+" tracks • tap to open");clicks.add(()->openPlaylist(id,name));menus.add(()->playlistOptions(id,name));
            }
        }else{
            List<Track> tracks=libraryTab==2?store.history():libraryTab==3?queueTracks():store.tracks();
            for(int i=0;i<tracks.size();i++){
                Track t=tracks.get(i);final int index=i;if(!(t.title+" "+t.artist).toLowerCase(Locale.ROOT).contains(term))continue;
                primary.add(t.isVideo()?"▶  "+t.title:t.title);String meta=(t.isVideo()?"VIDEO · ":"")+t.artist+" · "+clock(t.duration);
                if(libraryTab==2)meta+=" · "+android.text.format.DateFormat.format("MMM d, h:mm a",t.lastPlayed);else meta+=" · "+t.plays+" plays";secondary.add(meta);
                clicks.add(()->{if(libraryTab==3){if(ready()){controller.seekTo(index,0);controller.prepare();controller.play();showTab(0);}}else playTracks(tracks,index);});menus.add(()->trackOptions(t,libraryTab==3?index:-1));
            }
        }
        if(primary.isEmpty()){primary.add("No media here yet");secondary.add("Add audio or video files, choose a folder, or try another search.");clicks.add(()->pickFiles(FILES));menus.add(()->{});}
        libraryList.setAdapter(new BaseAdapter(){public int getCount(){return primary.size();}public Object getItem(int p){return primary.get(p);}public long getItemId(int p){return p;}public View getView(int p,View v,android.view.ViewGroup parent){LinearLayout outer=column();outer.setPadding(dp(8),dp(14),dp(8),dp(14));TextView top=label(primary.get(p),15,WHITE);top.setMaxLines(1);top.setEllipsize(TextUtils.TruncateAt.END);outer.addView(top);TextView sub=label(secondary.get(p),11,MUTED);sub.setMaxLines(2);outer.addView(sub);return outer;}});
        libraryList.setOnItemClickListener((p,v,i,id)->clicks.get(i).run());libraryList.setOnItemLongClickListener((p,v,i,id)->{menus.get(i).run();return true;});
    }
    private void playTracks(List<Track> tracks,int index){if(!ready()||tracks.isEmpty())return;List<MediaItem> items=new ArrayList<>();for(Track t:tracks)items.add(t.item());controller.setMediaItems(items,index,0);controller.prepare();notifications();controller.play();showTab(0);}
    private List<String> queueUris(){List<String> q=new ArrayList<>();if(controller!=null)for(int i=0;i<controller.getMediaItemCount();i++)q.add(controller.getMediaItemAt(i).mediaId);return q;}
    private List<Track> queueTracks(){List<Track> tracks=new ArrayList<>();for(String uri:queueUris()){Track t=store.track(uri);if(t!=null)tracks.add(t);}return tracks;}
    private void savePlaylist(List<String> uris){nameDialog("Playlist name","",name->{store.createPlaylist(name,uris);toast("Playlist saved");loadLibrary();});}
    private void openPlaylist(long id,String name){List<Track> tracks=store.playlist(id);String[] names=new String[tracks.size()+1];names[0]="▶ Play all · "+tracks.size()+" tracks";for(int i=0;i<tracks.size();i++)names[i+1]=tracks.get(i).title;
        new AlertDialog.Builder(this).setTitle(name).setItems(names,(d,w)->{if(!tracks.isEmpty())playTracks(tracks,Math.max(0,w-1));else toast("Hold a track in your library to add it here.");}).setNeutralButton("Manage",(d,w)->playlistOptions(id,name)).setNegativeButton("Close",null).show();}
    private void playlistOptions(long id,String name){new AlertDialog.Builder(this).setTitle(name).setItems(new String[]{"Rename","Remove a track","Append current queue","Delete playlist"},(d,w)->{
        if(w==0)nameDialog("Rename playlist",name,value->{store.renamePlaylist(id,value);loadLibrary();});
        else if(w==1){List<Track> tracks=store.playlist(id);String[] names=new String[tracks.size()];for(int i=0;i<names.length;i++)names[i]=tracks.get(i).title;new AlertDialog.Builder(this).setTitle("Remove from playlist").setItems(names,(a,b)->{store.removePlaylistEntry(id,b);loadLibrary();}).show();}
        else if(w==2){for(String uri:queueUris())store.addToPlaylist(id,uri);loadLibrary();toast("Queue appended");}
        else new AlertDialog.Builder(this).setMessage("Delete playlist “"+name+"”?").setNegativeButton("Cancel",null).setPositiveButton("Delete",(a,b)->{store.deletePlaylist(id);loadLibrary();}).show();}).show();}
    private void trackOptions(Track t,int queueIndex){
        String[] options=queueIndex>=0?new String[]{"Add to playlist","Move up","Move down","Remove from queue"}:new String[]{"Play next","Add to queue","Add to playlist","Remove from library"};
        new AlertDialog.Builder(this).setTitle(t.title).setItems(options,(d,w)->{
            if(queueIndex>=0){if(w==0)addToPlaylist(t);else if(ready()){if(w==1&&queueIndex>0)controller.moveMediaItem(queueIndex,queueIndex-1);if(w==2&&queueIndex<controller.getMediaItemCount()-1)controller.moveMediaItem(queueIndex,queueIndex+1);if(w==3)controller.removeMediaItem(queueIndex);loadLibrary();}}
            else if(w==2)addToPlaylist(t);else if(w==3)new AlertDialog.Builder(this).setMessage("Remove this track from the library and playlists? The original file stays on your phone.").setNegativeButton("Cancel",null).setPositiveButton("Remove",(a,b)->{if(controller!=null)for(int i=controller.getMediaItemCount()-1;i>=0;i--)if(controller.getMediaItemAt(i).mediaId.equals(t.uri))controller.removeMediaItem(i);store.removeTrack(t.uri);loadLibrary();}).show();
            else if(ready()){if(w==0)controller.addMediaItem(Math.min(controller.getMediaItemCount(),Math.max(0,controller.getCurrentMediaItemIndex()+1)),t.item());else controller.addMediaItem(t.item());toast("Added to queue");loadLibrary();}
        }).show();
    }
    private void addToPlaylist(Track t){Map<Long,String> lists=store.playlists();List<Long> ids=new ArrayList<>(lists.keySet());List<String> names=new ArrayList<>(lists.values());names.add("＋ New playlist");new AlertDialog.Builder(this).setTitle("Add to playlist").setItems(names.toArray(new String[0]),(d,w)->{if(w==ids.size())savePlaylist(Collections.singletonList(t.uri));else{store.addToPlaylist(ids.get(w),t.uri);toast("Added to playlist");}}).show();}
    interface NameResult{void accept(String name);}
    private void nameDialog(String heading,String initial,NameResult result){EditText input=new EditText(this);input.setSingleLine(true);input.setText(initial);input.setPadding(dp(20),dp(12),dp(20),dp(12));AlertDialog d=new AlertDialog.Builder(this).setTitle(heading).setView(input).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();d.setOnShowListener(x->d.getButton(-1).setOnClickListener(v->{String name=input.getText().toString().trim();if(name.isEmpty()){input.setError("Enter a name");return;}result.accept(name);d.dismiss();}));d.show();}
    private void buildSound(){
        LinearLayout body=scrolling();heading(body,"SHAPE YOUR SOUND","Optional effects for music in this player");
        Switch boost=new Switch(this);boost.setText("BOOST");boost.setTextColor(WHITE);boost.setChecked(prefs.getBoolean("player_boost",false));body.addView(boost,new LinearLayout.LayoutParams(-1,dp(48)));boost.setOnCheckedChangeListener((v,on)->{prefs.edit().putBoolean("player_boost",on).apply();sound();});
        TextView gain=label("Extra gain  +"+prefs.getInt("gain_db",4)+" dB",14,CYAN);body.addView(gain);SeekBar gb=slider(PINK);gb.setMax(12);gb.setProgress(prefs.getInt("gain_db",4));gb.setContentDescription("Boost gain in decibels");body.addView(gb,new LinearLayout.LayoutParams(-1,dp(44)));onSlider(gb,value->{prefs.edit().putInt("gain_db",value).apply();gain.setText("Extra gain  +"+value+" dB");sound();});
        body.addView(label("Start low. Extra gain can distort loud recordings.",11,MUTED));
        Switch eq=new Switch(this);eq.setText("7-BAND EQUALIZER");eq.setTextColor(WHITE);eq.setChecked(prefs.getBoolean("player_eq",false));margin(body,eq,18);eq.setOnCheckedChangeListener((v,on)->{prefs.edit().putBoolean("player_eq",on).apply();sound();});
        Spinner presets=new Spinner(this);List<String> presetNames=new ArrayList<>(Arrays.asList(EqProfile.PRESETS));presetNames.add("Custom");ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,presetNames);presets.setAdapter(adapter);String selected=prefs.getString("eq_preset","Bass");presets.setSelection(Math.max(0,presetNames.indexOf(selected)));body.addView(presets,new LinearLayout.LayoutParams(-1,dp(48)));
        EqBandView bands=new EqBandView(this);bands.setLevels(EqProfile.levels(prefs));body.addView(bands,new LinearLayout.LayoutParams(-1,dp(154)));bands.setOnChange((i,db)->{EqProfile.setBand(prefs,i,db);prefs.edit().putBoolean("player_eq",true).apply();eq.setChecked(true);presets.setSelection(presetNames.size()-1);sound();});
        presets.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){boolean first=true;public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int i,long id){if(first){first=false;return;}if(i<EqProfile.PRESETS.length){EqProfile.setPreset(prefs,EqProfile.PRESETS[i]);bands.setLevels(EqProfile.levels(prefs));prefs.edit().putBoolean("player_eq",true).apply();eq.setChecked(true);sound();}}});
        heading(body,"TRACK PITCH","Saved for each track • tempo stays the same");pitchLabel=label("Choose a track first",14,CYAN);body.addView(pitchLabel);pitchSlider=slider(CYAN);pitchSlider.setMax(48);pitchSlider.setProgress(24);pitchSlider.setContentDescription("Pitch from minus twelve to plus twelve semitones");body.addView(pitchSlider,new LinearLayout.LayoutParams(-1,dp(46)));onSlider(pitchSlider,value->{float semitones=(value-24)/2f;if(PlaybackService.live!=null)PlaybackService.live.pitch(semitones);pitchLabel.setText(String.format(Locale.US,"%+.1f semitones",semitones));});body.addView(button("RESET PITCH",()->{if(PlaybackService.live!=null)PlaybackService.live.pitch(0);pitchSlider.setProgress(24);shownUri="!";refresh();}));
        heading(body,"SAMPLE MIX","Four independent samples layered over your song");TextView mix=label("Sample volume  "+prefs.getInt("pad_volume",65)+"%",13,MUTED);body.addView(mix);SeekBar mv=slider(PINK);mv.setMax(100);mv.setProgress(prefs.getInt("pad_volume",65));mv.setContentDescription("Sample volume");body.addView(mv,new LinearLayout.LayoutParams(-1,dp(44)));onSlider(mv,v->{prefs.edit().putInt("pad_volume",v).apply();if(PlaybackService.live!=null)PlaybackService.live.padVolume(v);mix.setText("Sample volume  "+v+"%");});
        heading(body,"VISUALS","Music-reactive animation over your artwork");Spinner style=new Spinner(this);style.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Neon spectrum","Electric waveform","Orbital pulse","Artwork glow"}));style.setSelection(prefs.getInt("visual_style",0));body.addView(style,new LinearLayout.LayoutParams(-1,dp(48)));style.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int i,long id){prefs.edit().putInt("visual_style",i).apply();}});
        body.addView(button("OPEN FLOATING MINI PLAYER",this::openMiniPlayer));
        Switch auto=new Switch(this);auto.setText("Fullscreen visuals after 15 seconds");auto.setTextSize(13);auto.setTextColor(WHITE);auto.setChecked(prefs.getBoolean("auto_visuals",false));body.addView(auto,new LinearLayout.LayoutParams(-1,dp(52)));auto.setOnCheckedChangeListener((v,on)->prefs.edit().putBoolean("auto_visuals",on).apply());body.addView(button("OPEN FULLSCREEN VISUALS",this::openSaver));
        heading(body,"PHONE VOLUME","Phone speaker or the connected Bluetooth output");AudioManager audio=(AudioManager)getSystemService(AUDIO_SERVICE);SeekBar volume=slider(CYAN);volume.setMax(audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC));volume.setProgress(audio.getStreamVolume(AudioManager.STREAM_MUSIC));volume.setEnabled(!audio.isVolumeFixed());volume.setContentDescription("Device media volume");body.addView(volume,new LinearLayout.LayoutParams(-1,dp(48)));onSlider(volume,v->{try{audio.setStreamVolume(AudioManager.STREAM_MUSIC,v,0);}catch(SecurityException e){toast("Android blocked this volume change.");}});
        TextView other=button(prefs.getBoolean("enabled",false)?"OTHER APPS BOOST: ON":"OTHER APPS BOOST: OFF",this::toggleGlobal);margin(body,other,12);body.addView(label("Experimental device boost. Pauses this player; support depends on your phone and audio route. Player playback turns it off.",11,MUTED));
    }
    private void toggleGlobal(){boolean on=!prefs.getBoolean("enabled",false);if(on&&controller!=null)controller.pause();prefs.edit().putBoolean("enabled",on).apply();try{if(on){notifications();startForegroundService(new Intent(this,BoostService.class).setAction(BoostService.ACTION_APPLY));}else stopService(new Intent(this,BoostService.class));}catch(RuntimeException e){prefs.edit().putBoolean("enabled",false).apply();toast("Device-wide boost is unavailable.");}showTab(2);}
    private void sound(){if(PlaybackService.live!=null)PlaybackService.live.applySound();}
    private void pickFiles(int request){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType(request==PAD?"audio/*":"*/*").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_ALLOW_MULTIPLE,request==FILES).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);if(request==FILES)i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"audio/*","video/*"});try{startActivityForResult(i,request);}catch(ActivityNotFoundException e){toast("Install or enable Android’s Files app to choose media.");}}
    private void pickFolder(){try{startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION),FOLDER);}catch(ActivityNotFoundException e){toast("Folder selection is unavailable on this device.");}}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
        if(request==OVERLAY_PERMISSION){if(pendingMiniPlayer){pendingMiniPlayer=false;if(Settings.canDrawOverlays(this))launchMiniPlayer();else toast("Enable Display over other apps for Soulmans, then tap Mini Player again.");}return;}
        if(request==CAPTURE_PHONE){if(result==RESULT_OK&&data!=null)startRecording(result,data);else{pendingRecording=null;toast("Phone audio recording was cancelled.");}return;}
        if(result!=RESULT_OK||data==null)return;
        if(request==EXPORT_RECORDING){Uri destination=data.getData();if(destination!=null&&!pendingRecordingExport.isEmpty())exportRecording(destination);return;}
        if(request==EXPORT_PAD){Uri destination=data.getData();int index=pendingPad;if(destination==null||index<0||index>3)return;try{getContentResolver().takePersistableUriPermission(destination,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(SecurityException ignored){}exportPad(index,destination);return;}
        if(request==EXPORT_VIDEO){Uri destination=data.getData();if(destination==null||pendingVideoSource.isEmpty())return;try{getContentResolver().takePersistableUriPermission(destination,Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);}catch(SecurityException ignored){}exportVideoClip(destination);return;}
        List<Uri> uris=new ArrayList<>();if(data.getClipData()!=null)for(int i=0;i<data.getClipData().getItemCount();i++)uris.add(data.getClipData().getItemAt(i).getUri());else if(data.getData()!=null)uris.add(data.getData());if(uris.isEmpty())return;
        for(Uri uri:uris)try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(SecurityException e){toast("This provider cannot keep file access. Please select it using Android Files.");return;}
        if(request==PAD){int index=pendingPad;if(index<0||index>3)return;Uri uri=uris.get(0);if(PlaybackService.live!=null)PlaybackService.live.stopPad(index);worker.execute(()->{String name=store.displayName(uri);long duration=sampleDuration(uri);prefs.edit().putString("pad_uri_"+index,uri.toString()).putString("pad_name_"+index,name).putInt("pad_duration_"+index,(int)Math.min(Integer.MAX_VALUE,duration)).putInt("pad_start_"+index,0).putInt("pad_end_"+index,(int)Math.min(Integer.MAX_VALUE,duration)).putInt("pad_pitch_"+index,0).putInt("pad_fade_in_"+index,0).putInt("pad_fade_out_"+index,0).putInt("pad_echo_"+index,0).apply();runOnUiThread(()->{if(!isDestroyed()){toast("Sample "+(index+1)+" loaded · "+(duration>0?sampleClock(duration):"duration unavailable"));refresh();openPadEditor(index);}});});return;}
        if(request==FOLDER){rememberFolder(uris.get(0));importFiles(uris,true);}else if(request==FILES)importFiles(uris,false);
    }
    private void rememberFolder(Uri uri){try{JSONArray a=new JSONArray(prefs.getString("folders","[]"));for(int i=0;i<a.length();i++)if(a.getString(i).equals(uri.toString()))return;a.put(uri.toString());prefs.edit().putString("folders",a.toString()).apply();}catch(Exception ignored){}}
    private void rescanFolders(){List<Uri> uris=new ArrayList<>();try{JSONArray a=new JSONArray(prefs.getString("folders","[]"));for(int i=0;i<a.length();i++)uris.add(Uri.parse(a.getString(i)));}catch(Exception ignored){}if(uris.isEmpty())pickFolder();else importFiles(uris,true);}
    private void importFiles(List<Uri> selected,boolean folders){
        if(importing){toast("An import is already running.");return;}importing=true;showTab(1);setImport("Finding media files…");
        worker.execute(()->{int failed=0,done=0;List<Uri> files=new ArrayList<>();List<Track> added=new ArrayList<>();
            for(Uri u:selected){try{if(folders)files.addAll(store.folder(u,n->{if(n%50==0)runOnUiThread(()->setImport("Found "+n+" media files…"));}));else files.add(u);}catch(RuntimeException e){failed++;}}
            for(Uri uri:new LinkedHashSet<>(files)){try{added.add(store.importTrack(uri));}catch(Exception e){failed++;}done++;final int count=done;if(done%5==0)runOnUiThread(()->setImport("Reading "+count+" / "+files.size()+" files…"));}
            final int bad=failed;runOnUiThread(()->{importing=false;if(isDestroyed())return;if(controller!=null&&controller.getMediaItemCount()==0&&!added.isEmpty()){List<MediaItem> items=new ArrayList<>();for(Track t:added)items.add(t.item());controller.setMediaItems(items);controller.prepare();}setImport(added.size()+" media files available"+(bad>0?" · "+bad+" unavailable (try selecting again)":""));loadLibrary();toast(added.isEmpty()?"No readable audio or video found in this selection.":"Added "+added.size()+" media files");});
        });
    }
    private void setImport(String s){if(importStatus!=null)importStatus.setText(s);}
    private void refresh(){
        if(isDestroyed())return;updateRecordingUi();PlaybackService service=PlaybackService.live;boolean playing=controller!=null&&controller.isPlaying();MediaItem item=controller==null?null:controller.getCurrentMediaItem();String uri=item==null?"":item.mediaId;
        Track activeTrack=uri.isEmpty()?null:store.track(uri);boolean video=activeTrack!=null&&activeTrack.isVideo();
        if(fullScreenButton!=null)fullScreenButton.setText(video?"FULLSCREEN ↗":"VISUALS ↗");if(videoClipButton!=null)videoClipButton.setVisibility(video?View.VISIBLE:View.GONE);
        if(reelDeck!=null){reelDeck.setVisibility(video?View.GONE:View.VISIBLE);reelDeck.state(uri,controller==null?0:controller.getCurrentPosition(),controller==null?0:controller.getDuration(),playing,service==null?null:service.processor);}
        if(title!=null){title.setText(item==null?"Your music. Your rules.":controller.getMediaMetadata().title);artist.setText(item==null?"Add files or a folder to start listening":controller.getMediaMetadata().artist);}
        if(videoView!=null){Player output=FloatingPlayerService.isOpen()?null:controller;if(videoView.getPlayer()!=output)videoView.setPlayer(output);videoView.setVisibility(video?View.VISIBLE:View.GONE);}
        if(cover!=null)cover.setVisibility(video?View.GONE:View.VISIBLE);
        if(coverFade!=null)coverFade.setVisibility(video?View.GONE:View.VISIBLE);
        if(seek!=null&&controller!=null){long duration=controller.getDuration();seek.setEnabled(duration>0&&controller.isCurrentMediaItemSeekable());if(!dragging){seek.setProgress(duration>0?(int)(1000*controller.getCurrentPosition()/duration):0);time.setText(clock(controller.getCurrentPosition())+"  /  "+clock(duration));}}
        if(play!=null){play.setText(playing?"Ⅱ":"▶");play.setContentDescription(playing?"Pause":"Play");shuffle.setTextColor(controller!=null&&controller.getShuffleModeEnabled()?MetalSkin.GOLD:MetalSkin.MUTED);int mode=controller==null?0:controller.getRepeatMode();repeat.setText(mode==Player.REPEAT_MODE_ONE?"↻ 1":"↻");repeat.setTextColor(mode!=0?MetalSkin.GOLD:MetalSkin.MUTED);repeat.setContentDescription("Repeat "+(mode==0?"off":mode==1?"one track":"all tracks"));}
        if(playStatus!=null){String status=service==null?"Connecting…":service.message;if(status.isEmpty()){if(item==null)status="OFFLINE PLAYER · NO ADS";else if(controller.getPlaybackState()==Player.STATE_BUFFERING)status="Loading media…";else status=(video?"VIDEO · ":"")+(playing?"PLAYING":"PAUSED")+" · "+(controller.getCurrentMediaItemIndex()+1)+" / "+controller.getMediaItemCount()+(prefs.getBoolean("player_boost",false)?" · BOOST +"+prefs.getInt("gain_db",4)+" dB":"");}playStatus.setText(status);}
        for(int i=0;i<4;i++)if(padButtons[i]!=null){boolean active=service!=null&&service.padPlaying(i);String name=prefs.getString("pad_name_"+i,"");int accent=PAD_COLORS[i];String mode=prefs.getBoolean("pad_loop_"+i,false)?"LOOP":new String[]{"SHOT","TOGGLE","GATE"}[Math.max(0,Math.min(2,prefs.getInt("pad_trigger_"+i,0)))];padButtons[i].setText(String.format(Locale.US,"%02d   %s\n%s\n%s",i+1,active?"■":"●",name.isEmpty()?"LOAD SAMPLE":name,mode));padButtons[i].setContentDescription("Sampler pad "+(i+1)+", "+(name.isEmpty()?"choose an audio file":name)+", "+mode+(active?", playing":""));padButtons[i].setBackground(shape(active?0xff292e45:0xff161b2d,accent,17));padButtons[i].setTextColor(active?WHITE:accent);}
        if(!uri.equals(shownUri)){shownUri=uri;loadArt(uri);if(pitchSlider!=null){Track t=store.track(uri);pitchSlider.setEnabled(t!=null);pitchSlider.setProgress(t==null?24:Math.round(t.pitch*2+24));pitchLabel.setText(t==null?"Choose a track first":String.format(Locale.US,"%+.1f semitones · %s",t.pitch,t.title));}}
        if(waveform!=null){boolean isWave=activeTrack!=null&&activeTrack.isWave();waveform.setVisibility(isWave?View.VISIBLE:View.GONE);if(waveformControls!=null)waveformControls.setVisibility(isWave?View.VISIBLE:View.GONE);if(isWave&&!uri.equals(waveformUri))loadWaveform(uri);if(isWave&&controller!=null&&controller.getDuration()>0){waveform.viewport().setDuration(controller.getDuration());waveform.setPosition((float)controller.getCurrentPosition()/controller.getDuration());}}
        if(pitchSlider!=null)pitchSlider.setEnabled(item!=null);
        if(visual!=null){visual.setVisibility(!video&&playing&&SystemClock.elapsedRealtime()-touched>4000?View.VISIBLE:View.INVISIBLE);visual.state(service==null?null:service.processor,playing,prefs.getInt("visual_style",0));}
        if(saverVisual!=null){saverVisual.state(service==null?null:service.processor,playing,prefs.getInt("visual_style",0));saverTitle.setText(item==null?"Soulman's Media Player":String.valueOf(controller.getMediaMetadata().title));}
        if(playing&&!video&&tab==0&&saver==null&&RecordingService.live==null&&!FloatingPlayerService.isOpen()&&prefs.getBoolean("auto_visuals",false)&&SystemClock.elapsedRealtime()-touched>15000)openSaver();
    }
    private void loadWaveform(String uri){
        waveformUri=uri;waveformPeaks=null;if(waveform!=null){waveform.viewport().fullSong();waveform.viewport().setDuration(0);waveform.setMessage("READING PCM WAV…");}if(worker.isShutdown())return;
        worker.execute(()->{float[] peaks=null;try{peaks=WavWaveformReader.read(getContentResolver(),Uri.parse(uri),WaveformViewport.PEAK_BINS);}catch(Exception ignored){}float[] result=peaks;runOnUiThread(()->{if(isDestroyed()||!uri.equals(shownUri))return;waveformPeaks=result;if(waveform!=null)waveform.setWaveform(result);});});
    }
    private void loadSampleWaveform(int pad,SampleWaveformView view){
        String source=prefs.getString("pad_uri_"+pad,"");view.setMessage("READING WAV PEAKS…");if(source.isEmpty()||worker.isShutdown())return;
        worker.execute(()->{float[] peaks=null;try{peaks=WavWaveformReader.read(getContentResolver(),Uri.parse(source),WaveformViewport.PEAK_BINS);}catch(Exception ignored){}float[] result=peaks;runOnUiThread(()->{if(isDestroyed()||!source.equals(prefs.getString("pad_uri_"+pad,"")))return;view.setWaveform(result);});});
    }
    private void loadArt(String uri){
        currentArt=null;if(cover!=null)cover.setImageResource(R.drawable.speaker_blast);if(saverArt!=null)saverArt.setImageResource(R.drawable.speaker_blast);if(uri.isEmpty()||worker.isShutdown())return;
        worker.execute(()->{Bitmap art=null;MediaMetadataRetriever r=new MediaMetadataRetriever();try{r.setDataSource(this,Uri.parse(uri));byte[] bytes=r.getEmbeddedPicture();if(bytes!=null){BitmapFactory.Options o=new BitmapFactory.Options();o.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(bytes,0,bytes.length,o);o.inSampleSize=1;while(o.outWidth/o.inSampleSize>1200||o.outHeight/o.inSampleSize>1200)o.inSampleSize*=2;o.inJustDecodeBounds=false;art=BitmapFactory.decodeByteArray(bytes,0,bytes.length,o);}}catch(Exception ignored){}finally{try{r.release();}catch(Exception ignored){}}Bitmap result=art;runOnUiThread(()->{if(isDestroyed()||!uri.equals(shownUri))return;currentArt=result;if(result!=null){if(cover!=null)cover.setImageBitmap(result);if(saverArt!=null)saverArt.setImageBitmap(result);}});});
    }
    private void openSaver(){
        if(saver!=null)return;
        FloatingPlayerService.hide(this);
        MediaItem current=controller==null?null:controller.getCurrentMediaItem();Track active=current==null?null:store.track(current.mediaId);
        if(active!=null&&active.isVideo()){openVideoFullscreen(active);return;}
        saver=new Dialog(this,android.R.style.Theme_Material_NoActionBar_Fullscreen);FrameLayout scene=new FrameLayout(this);scene.setBackgroundColor(BG);
        saverArt=new ImageView(this);saverArt.setScaleType(ImageView.ScaleType.CENTER_CROP);if(currentArt!=null)saverArt.setImageBitmap(currentArt);else saverArt.setImageResource(R.drawable.speaker_blast);scene.addView(saverArt,new FrameLayout.LayoutParams(-1,-1));View shade=new View(this);shade.setBackgroundColor(0x96090d1a);scene.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        saverVisual=new VisualizerView(this);scene.addView(saverVisual,new FrameLayout.LayoutParams(-1,-1));LinearLayout captions=column();captions.setPadding(dp(24),dp(24),dp(24),dp(28));saverTitle=label("Soulmans",25,WHITE);captions.addView(saverTitle);captions.addView(label("Tap anywhere to return",12,CYAN));scene.addView(captions,new FrameLayout.LayoutParams(-1,-2,Gravity.BOTTOM));scene.setOnClickListener(v->closeSaver());saver.setContentView(scene);saver.setOnDismissListener(d->{saver=null;saverVisual=null;saverArt=null;saverTitle=null;touched=SystemClock.elapsedRealtime();});saver.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);saver.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);saver.show();refresh();
    }
    private void openVideoFullscreen(Track track){
        saver=new Dialog(this,android.R.style.Theme_Material_NoActionBar_Fullscreen);FrameLayout scene=new FrameLayout(this);scene.setBackgroundColor(0xff000000);
        if(videoView!=null)videoView.setPlayer(null);
        saverVideo=new PlayerView(this);saverVideo.setPlayer(controller);saverVideo.setUseController(true);saverVideo.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);scene.addView(saverVideo,new FrameLayout.LayoutParams(-1,-1));saverGesture=addVideoGestures(saverVideo,true);
        TextView close=button("×  BACK TO PLAYER",this::closeSaver);FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(-2,dp(48),Gravity.TOP|Gravity.END);cp.setMargins(0,dp(16),dp(16),0);scene.addView(close,cp);
        TextView caption=label(track.title,14,WHITE);caption.setMaxLines(1);caption.setEllipsize(TextUtils.TruncateAt.END);caption.setBackgroundColor(0x99090d1a);caption.setPadding(dp(18),dp(12),dp(18),dp(12));FrameLayout.LayoutParams titleParams=new FrameLayout.LayoutParams(-1,-2,Gravity.TOP|Gravity.START);titleParams.setMargins(dp(16),dp(16),dp(120),0);scene.addView(caption,titleParams);
        TextView clip=button("VIDEO LOOP & EXPORT",()->{closeSaver();handler.postDelayed(()->openVideoClipEditor(track),180);});FrameLayout.LayoutParams ep=new FrameLayout.LayoutParams(-2,dp(48),Gravity.BOTTOM|Gravity.END);ep.setMargins(0,0,dp(16),dp(22));scene.addView(clip,ep);
        TextView hint=label("PINCH TO ZOOM  ·  DRAG TO FRAME  ·  DOUBLE TAP TO RESET",11,CYAN);hint.setBackgroundColor(0x99090d1a);hint.setPadding(dp(14),dp(12),dp(14),dp(12));FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.START);hp.setMargins(dp(16),0,dp(16),dp(22));scene.addView(hint,hp);
        saver.setContentView(scene);saver.setOnDismissListener(d->{if(saverVideo!=null)saverVideo.setPlayer(null);saverVideo=null;saverGesture=null;saver=null;if(videoView!=null&&controller!=null)videoView.setPlayer(controller);touched=SystemClock.elapsedRealtime();refresh();});saver.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);saver.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);saver.show();
    }
    private VideoGestureOverlay addVideoGestures(PlayerView playerView,boolean fullscreen){
        View frame=playerView.findViewById(androidx.media3.ui.R.id.exo_content_frame);
        if(!(frame instanceof ViewGroup))return null;
        VideoGestureOverlay layer=new VideoGestureOverlay(this,frame,()->{
            if(fullscreen){if(playerView.isControllerFullyVisible())playerView.hideController();else playerView.showController();}
            else openSaver();
        });
        ((ViewGroup)frame).addView(layer,new FrameLayout.LayoutParams(-1,-1));
        return layer;
    }
    private void openCurrentVideoClipEditor(){
        MediaItem item=controller==null?null:controller.getCurrentMediaItem();Track track=item==null?null:store.track(item.mediaId);
        if(track==null||!track.isVideo()){toast("Play a video first to set loop points and export a clip.");return;}
        long duration=controller.getDuration();if(duration<=0||duration==C.TIME_UNSET)duration=track.duration;
        if(duration>0){showVideoClipEditor(track,duration);return;}
        worker.execute(()->{long measured=sampleDuration(Uri.parse(track.uri));runOnUiThread(()->{if(!isDestroyed()){if(measured>0)showVideoClipEditor(track,measured);else toast("This video’s duration could not be read.");}});});
    }
    private void openVideoClipEditor(Track track){
        if(controller==null||controller.getCurrentMediaItem()==null||!track.uri.equals(controller.getCurrentMediaItem().mediaId)){toast("Start this video first, then open its clip tools.");return;}
        openCurrentVideoClipEditor();
    }
    private void showVideoClipEditor(Track track,long duration){
        String mediaId=track.uri,key=VideoClipPrefs.key(mediaId);
        long[] range=VideoClipMath.normalize(VideoClipPrefs.start(prefs,mediaId),VideoClipPrefs.end(prefs,mediaId,duration),duration);
        LinearLayout form=column();form.setPadding(dp(18),dp(4),dp(18),dp(8));
        TextView rangeTitle=label("TRIM POINTS",12,CYAN);rangeTitle.setLetterSpacing(.10f);form.addView(rangeTitle);
        TextView inText=label("IN   "+sampleClock(range[0]),13,WHITE);margin(form,inText,7);
        SeekBar inBar=slider(CYAN);inBar.setMax(1000);inBar.setProgress(VideoClipMath.toProgress(range[0],duration));inBar.setContentDescription("Video loop start point");form.addView(inBar,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView outText=label("OUT   "+sampleClock(range[1]),13,WHITE);margin(form,outText,7);
        SeekBar outBar=slider(PINK);outBar.setMax(1000);outBar.setProgress(VideoClipMath.toProgress(range[1],duration));outBar.setContentDescription("Video loop end point");form.addView(outBar,new LinearLayout.LayoutParams(-1,dp(42)));
        Runnable updateLabels=()->{inText.setText("IN   "+sampleClock(range[0]));outText.setText("OUT   "+sampleClock(range[1]));};
        inBar.setOnSeekBarChangeListener(valueListener(value->{long gap=Math.min(1000,duration);range[0]=VideoClipMath.fromProgress(value,duration);if(range[0]+gap>range[1])range[1]=Math.min(duration,range[0]+gap);inBar.setProgress(VideoClipMath.toProgress(range[0],duration));outBar.setProgress(VideoClipMath.toProgress(range[1],duration));updateLabels.run();}));
        outBar.setOnSeekBarChangeListener(valueListener(value->{long gap=Math.min(1000,duration);range[1]=VideoClipMath.fromProgress(value,duration);if(range[1]<range[0]+gap)range[0]=Math.max(0,range[1]-gap);range[1]=Math.max(range[1],range[0]+gap);outBar.setProgress(VideoClipMath.toProgress(range[1],duration));inBar.setProgress(VideoClipMath.toProgress(range[0],duration));updateLabels.run();}));
        LinearLayout markers=row();TextView setIn=button("IN ← PLAYHEAD",()->{long gap=Math.min(1000,duration);range[0]=Math.min(duration-gap,Math.max(0,controller.getCurrentPosition()));if(range[0]+gap>range[1])range[1]=Math.min(duration,range[0]+gap);inBar.setProgress(VideoClipMath.toProgress(range[0],duration));outBar.setProgress(VideoClipMath.toProgress(range[1],duration));updateLabels.run();});markers.addView(setIn,new LinearLayout.LayoutParams(0,dp(44),1));TextView setOut=button("OUT ← PLAYHEAD",()->{long gap=Math.min(1000,duration);range[1]=Math.min(duration,Math.max(0,controller.getCurrentPosition()));if(range[1]<range[0]+gap)range[0]=Math.max(0,range[1]-gap);range[1]=Math.max(range[1],range[0]+gap);inBar.setProgress(VideoClipMath.toProgress(range[0],duration));outBar.setProgress(VideoClipMath.toProgress(range[1],duration));updateLabels.run();});LinearLayout.LayoutParams outParams=new LinearLayout.LayoutParams(0,dp(44),1);outParams.leftMargin=dp(8);markers.addView(setOut,outParams);margin(form,markers,8);
        Switch loop=new Switch(this);loop.setText("Loop between IN and OUT");loop.setTextColor(WHITE);loop.setTextSize(14);loop.setChecked(VideoClipPrefs.loops(prefs,mediaId));margin(form,loop,9);
        heading(form,"EXPORT VIDEO","Save a separate trimmed clip; your source stays untouched");
        Spinner quality=new Spinner(this);quality.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Original size · high quality","1080p · high quality","720p · balanced","480p · smaller file"}));quality.setSelection(Math.max(0,Math.min(3,prefs.getInt("video_export_quality_"+key,0))));form.addView(quality,new LinearLayout.LayoutParams(-1,dp(48)));
        Spinner type=new Spinner(this);type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"MP4 · widest compatibility","3GP · older phones"}));type.setSelection(Math.max(0,Math.min(1,prefs.getInt("video_export_type_"+key,0))));form.addView(type,new LinearLayout.LayoutParams(-1,dp(48)));
        form.addView(label("MP4 and 3GP export as H.264 video with AAC audio. Available encoders can vary by phone.",11,MUTED));
        TextView preview=button("PREVIEW LOOP RANGE",()->{if(controller==null||controller.getCurrentMediaItem()==null||!mediaId.equals(controller.getCurrentMediaItem().mediaId)){toast("This video is no longer playing.");return;}VideoClipPrefs.save(prefs,mediaId,range[0],range[1],loop.isChecked(),quality.getSelectedItemPosition(),type.getSelectedItemPosition());controller.seekTo(range[0]);controller.play();});
        form.addView(preview,new LinearLayout.LayoutParams(-1,dp(46)));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.addView(form);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("VIDEO LOOP & EXPORT").setView(scroll).setNegativeButton("CLOSE",null).setPositiveButton("SAVE LOOP",null).setNeutralButton("EXPORT CLIP",null).create();
        dialog.setOnShowListener(ignored->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{VideoClipPrefs.save(prefs,mediaId,range[0],range[1],loop.isChecked(),quality.getSelectedItemPosition(),type.getSelectedItemPosition());toast("Video loop points saved.");dialog.dismiss();});dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{VideoClipPrefs.save(prefs,mediaId,range[0],range[1],loop.isChecked(),quality.getSelectedItemPosition(),type.getSelectedItemPosition());pendingVideoSource=mediaId;pendingVideoStart=range[0];pendingVideoEnd=range[1];pendingVideoQuality=quality.getSelectedItemPosition();pendingVideoType=type.getSelectedItemPosition();dialog.dismiss();openVideoExportPicker(track);});});
        dialog.show();
    }
    private void openVideoExportPicker(Track track){
        String extension=pendingVideoType==1?"3gp":"mp4",mime=pendingVideoType==1?"video/3gpp":"video/mp4";
        String name=track.title.replaceAll("[\\\\/:*?\"<>|]","_").trim();if(name.isEmpty())name="Soulmans-Video";
        Intent create=new Intent(Intent.ACTION_CREATE_DOCUMENT).setType(mime).addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,name+"-clip."+extension).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try{startActivityForResult(create,EXPORT_VIDEO);}catch(ActivityNotFoundException e){toast("Android Files is needed to save a video clip.");}
    }
    private void exportVideoClip(Uri destination){
        if(videoExporter!=null){toast("A video export is already running.");return;}
        LinearLayout view=column();view.setPadding(dp(20),dp(8),dp(20),dp(14));videoExportStatus=label("Preparing your video…",13,CYAN);view.addView(videoExportStatus);videoExportProgress=slider(PINK);videoExportProgress.setMax(100);videoExportProgress.setProgress(0);view.addView(videoExportProgress,new LinearLayout.LayoutParams(-1,dp(48)));
        videoExportDialog=new AlertDialog.Builder(this).setTitle("EXPORTING CLIP").setView(view).setNegativeButton("CANCEL EXPORT",null).create();videoExportDialog.setCancelable(false);videoExportDialog.show();videoExportDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v->{if(videoExporter!=null)videoExporter.cancel();finishVideoExportUi();toast("Video export cancelled.");});
        try{videoExporter=VideoClipExporter.start(this,Uri.parse(pendingVideoSource),destination,pendingVideoStart,pendingVideoEnd,pendingVideoQuality,pendingVideoType,new VideoClipExporter.Listener(){public void onFinished(String name){finishVideoExportUi();if(!isDestroyed())toast("Saved video clip"+(name==null||name.isEmpty()?"":" · "+name));}public void onFailed(String reason){finishVideoExportUi();if(!isDestroyed())toast("Video export failed: "+reason);}});handler.post(videoExportTick);}
        catch(Exception e){finishVideoExportUi();toast("Could not start video export: "+(e.getMessage()==null?"encoder unavailable":e.getMessage()));}
    }
    private void finishVideoExportUi(){handler.removeCallbacks(videoExportTick);if(videoExportDialog!=null){videoExportDialog.dismiss();videoExportDialog=null;}videoExportStatus=null;videoExportProgress=null;videoExporter=null;}
    private void closeSaver(){if(saver!=null)saver.dismiss();}
    private interface IntValue{void set(int v);}
    private void onSlider(SeekBar s,IntValue callback){s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar s,int v,boolean user){if(user)callback.set(v);}});}
    private SeekBar.OnSeekBarChangeListener valueListener(IntValue callback){return new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}public void onProgressChanged(SeekBar s,int v,boolean user){if(user)callback.set(v);}};}
    private void savePadSettings(int pad,int duration,int start,int end,boolean loop,int trigger,int pitch,int fadeIn,int fadeOut,int echo,int delay){
        if(duration>0){start=Math.max(0,Math.min(duration,start));end=Math.max(start+1,Math.min(duration,end));}
        prefs.edit().putInt("pad_duration_"+pad,duration).putInt("pad_start_"+pad,start).putInt("pad_end_"+pad,end).putBoolean("pad_loop_"+pad,loop).putInt("pad_trigger_"+pad,trigger).putInt("pad_pitch_"+pad,pitch).putInt("pad_fade_in_"+pad,fadeIn).putInt("pad_fade_out_"+pad,fadeOut).putInt("pad_echo_"+pad,echo).putInt("pad_echo_delay_"+pad,delay).apply();
        if(PlaybackService.live!=null)PlaybackService.live.stopPad(pad);
    }
    private long sampleDuration(Uri uri){MediaMetadataRetriever retriever=new MediaMetadataRetriever();try{retriever.setDataSource(this,uri);String d=retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);return d==null?0:Long.parseLong(d);}catch(Exception ignored){return 0;}finally{try{retriever.release();}catch(Exception ignored){}}}
    private String sampleClock(long milliseconds){if(milliseconds<0)milliseconds=0;long tenths=milliseconds/100;return String.format(Locale.US,"%d:%02d.%d",tenths/600,tenths/10%60,tenths%10);}
    private void savePadAsWav(int pad){
        int start=prefs.getInt("pad_start_"+pad,0),end=prefs.getInt("pad_end_"+pad,0);if(end<=start){toast("This file’s duration could not be read; choose another audio file.");return;}if(end-start>SampleClipExporter.MAX_CLIP_MS){toast("Move the sample end point so the clip is 60 seconds or shorter.");return;}
        pendingPad=pad;Intent create=new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("audio/wav").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,"Soulmans-Sample-"+(pad+1)+".wav").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);try{startActivityForResult(create,EXPORT_PAD);}catch(ActivityNotFoundException e){toast("Android Files is needed to save the WAV clip.");}
    }
    private void exportPad(int pad,Uri destination){
        String sourceText=prefs.getString("pad_uri_"+pad,"");if(sourceText.isEmpty())return;
        if(PlaybackService.live!=null)PlaybackService.live.stopPad(pad);toast("Rendering your edited WAV sample…");
        int start=prefs.getInt("pad_start_"+pad,0),end=prefs.getInt("pad_end_"+pad,0),pitch=prefs.getInt("pad_pitch_"+pad,0),fadeIn=prefs.getInt("pad_fade_in_"+pad,0),fadeOut=prefs.getInt("pad_fade_out_"+pad,0),echo=prefs.getInt("pad_echo_"+pad,0),delay=prefs.getInt("pad_echo_delay_"+pad,220);
        worker.execute(()->{try{long duration=SampleClipExporter.export(this,Uri.parse(sourceText),destination,start,end,pitch,fadeIn,fadeOut,delay,echo/100f);String name=store.displayName(destination);prefs.edit().putString("pad_uri_"+pad,destination.toString()).putString("pad_name_"+pad,name).putInt("pad_duration_"+pad,(int)duration).putInt("pad_start_"+pad,0).putInt("pad_end_"+pad,(int)duration).putInt("pad_pitch_"+pad,0).putInt("pad_fade_in_"+pad,0).putInt("pad_fade_out_"+pad,0).putInt("pad_echo_"+pad,0).apply();runOnUiThread(()->{if(isDestroyed())return;if(padEditor!=null)padEditor.dismiss();toast("Saved a new WAV clip · source file left unchanged");refresh();});}catch(Exception e){runOnUiThread(()->{if(!isDestroyed())toast("Couldn’t render this sample: "+(e.getMessage()==null?"audio codec unavailable":e.getMessage()));});}});
    }
    private void showRecordingOptions(int selectedPad) {
        if (RecordingService.live != null && RecordingService.live.isActive()) { showRecordingSession(); return; }
        LinearLayout form = column(); form.setPadding(dp(18), 0, dp(18), dp(12));
        heading(form, "RECORD FROM", "Choose the audio input for your sample");
        boolean phoneSupported = Build.VERSION.SDK_INT >= 29;
        Spinner source = recordingSpinner(form, phoneSupported ? new String[]{"Phone audio · playing media", "Microphone · surrounding sound"} : new String[]{"Microphone · surrounding sound"});
        source.setContentDescription("Recording source");
        source.setSelection(phoneSupported ? Math.min(1, prefs.getInt("record_source", 0)) : 0);
        TextView sourceHelp = label("", 12, MUTED); margin(form, sourceHelp, 7);
        source.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(AdapterView<?> parent) {}
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                boolean phone = phoneSupported && position == 0;
                sourceHelp.setText(phone ? "Records media and game audio from apps that allow capture. Android asks permission for each session. Only audio is saved; protected apps and calls may be silent."
                        : "Records your microphone. Use headphones when music is playing to reduce speaker bleed. Microphone access is requested when you start." + (phoneSupported ? "" : " Phone audio capture requires Android 10 or newer."));
            }
        });
        heading(form, "SAVE TO PAD", "The new take loads here; earlier recorded takes remain in Saved Takes");
        String[] pads = new String[4]; int destination = selectedPad;
        if (destination < 0) { destination = Math.max(0, Math.min(3, prefs.getInt("record_pad", 0))); for (int i = 0; i < 4; i++) if (prefs.getString("pad_uri_" + i, "").isEmpty()) { destination = i; break; } }
        for (int i = 0; i < 4; i++) pads[i] = "PAD " + (i + 1) + " · " + prefs.getString("pad_name_" + i, "Empty pad");
        Spinner pad = recordingSpinner(form, pads); pad.setSelection(destination); pad.setContentDescription("Recording destination pad");
        heading(form, "WAV QUALITY", "16-bit WAV · stereo phone audio / mono microphone");
        Spinner quality = recordingSpinner(form, new String[]{"44.1 kHz · CD quality", "48 kHz · studio / video"}); quality.setSelection(prefs.getInt("record_rate", 44100) == 48000 ? 1 : 0); quality.setContentDescription("Recording quality");
        heading(form, "STOP AFTER", "Save automatically at this length, or stop earlier");
        Spinner length = recordingSpinner(form, new String[]{"15 seconds", "30 seconds", "60 seconds", "5 minutes · trim afterward"}); length.setSelection(Math.max(0, Math.min(3, prefs.getInt("record_length_choice", 2)))); length.setContentDescription("Maximum recording length");
        heading(form, "COUNT-IN", "Optional time to get ready");
        Spinner countIn = recordingSpinner(form, new String[]{"Start immediately", "3-second countdown"}); countIn.setSelection(prefs.getBoolean("record_count_in", false) ? 1 : 0); countIn.setContentDescription("Recording countdown");
        margin(form, label("Takes stay on this phone. Save an original WAV from Saved Takes, or use the pad editor to trim, loop, pitch, fade and echo it.", 11, MUTED), 14);
        ScrollView scroll = new ScrollView(this); scroll.addView(form);
        new AlertDialog.Builder(this).setTitle("SAMPLER · RECORD AUDIO").setView(scroll).setNegativeButton("CANCEL", null)
                .setPositiveButton("START RECORDING", (dialog, which) -> {
                    Bundle options = new Bundle(); options.putInt("source", phoneSupported ? source.getSelectedItemPosition() : 1);
                    options.putInt("pad", pad.getSelectedItemPosition()); options.putInt("rate", quality.getSelectedItemPosition() == 0 ? 44100 : 48000);
                    options.putInt("max_ms", new int[]{15000, 30000, 60000, 300000}[length.getSelectedItemPosition()]);
                    options.putInt("count_in_ms", countIn.getSelectedItemPosition() == 0 ? 0 : 3000);
                    prefs.edit().putInt("record_source", options.getInt("source")).putInt("record_pad", options.getInt("pad"))
                            .putInt("record_rate", options.getInt("rate")).putInt("record_length_choice", length.getSelectedItemPosition())
                            .putBoolean("record_count_in", countIn.getSelectedItemPosition() != 0).apply();
                    pendingRecording = options; requestRecordingPermission();
                }).show();
    }

    private Spinner recordingSpinner(LinearLayout form, String[] choices) {
        Spinner spinner = new Spinner(this); spinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, choices));
        form.addView(spinner, new LinearLayout.LayoutParams(-1, dp(48))); return spinner;
    }

    private void requestRecordingPermission() {
        boolean audio = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        boolean notification = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
        if (!audio || !notification) {
            prefs.edit().putBoolean("asked_notifications", true).apply();
            requestPermissions(Build.VERSION.SDK_INT >= 33 ? new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS} : new String[]{Manifest.permission.RECORD_AUDIO}, RECORD_PERMISSION);
        } else authorizeRecordingSource();
    }

    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        if (request != RECORD_PERMISSION) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) authorizeRecordingSource();
        else { pendingRecording = null; toast("Allow audio recording permission to use the sampler recorder. You can enable it in this app's Android permissions."); }
    }

    private void authorizeRecordingSource() {
        if (pendingRecording == null) return;
        if (pendingRecording.getInt("source") == 0) {
            if (Build.VERSION.SDK_INT < 29) { pendingRecording = null; toast("Phone audio recording requires Android 10 or newer."); return; }
            MediaProjectionManager manager = getSystemService(MediaProjectionManager.class);
            try {
                Intent consent = Build.VERSION.SDK_INT >= 34 ? manager.createScreenCaptureIntent(android.media.projection.MediaProjectionConfig.createConfigForDefaultDisplay()) : manager.createScreenCaptureIntent();
                startActivityForResult(consent, CAPTURE_PHONE);
            } catch (RuntimeException error) { pendingRecording = null; toast("Android could not open the phone audio capture prompt."); }
        } else startRecording(0, null);
    }

    private void startRecording(int projectionResult, Intent projectionData) {
        if (pendingRecording == null) { toast("Choose your recording options again."); return; }
        if (RecordingService.live != null && RecordingService.live.isActive()) { pendingRecording = null; showRecordingSession(); return; }
        if (PlaybackService.live != null) PlaybackService.live.stopPad(pendingRecording.getInt("pad"));
        Intent capture = new Intent(this, RecordingService.class).setAction(RecordingService.START).putExtras(pendingRecording);
        if (projectionData != null) capture.putExtra("projection_result", projectionResult).putExtra("projection_data", projectionData);
        pendingRecording = null;
        try { startForegroundService(capture); closeSaver(); showRecordingSession(); }
        catch (RuntimeException error) { toast("Recording could not start: " + error.getMessage()); }
    }

    private void showRecordingSession() {
        if (recordingDialog != null && recordingDialog.isShowing()) return;
        LinearLayout form = column(); form.setPadding(dp(18), dp(8), dp(18), dp(14));
        recordingStatus = label("Preparing audio input…", 15, CYAN); margin(form, recordingStatus, 4);
        recordingTime = label("0:00.0", 32, PINK); margin(form, recordingTime, 15);
        recordingMeter = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal); recordingMeter.setMax(100);
        recordingMeter.setProgressTintList(ColorStateList.valueOf(CYAN)); recordingMeter.setProgressBackgroundTintList(ColorStateList.valueOf(0xff333d56));
        recordingMeter.setContentDescription("Recording input level"); form.addView(recordingMeter, new LinearLayout.LayoutParams(-1, dp(28)));
        margin(form, label("You can switch to another app while recording. Pause skips incoming audio; SAVE / STOP writes the take and loads your pad.", 12, MUTED), 12);
        LinearLayout controls = row();
        recordingPause = button("PAUSE", () -> { RecordingService service = RecordingService.live; if (service != null) service.togglePause(); }); controls.addView(recordingPause, weight(48));
        recordingSave = button("SAVE / STOP", () -> { RecordingService service = RecordingService.live; if (service != null) service.stop(false); }); controls.addView(recordingSave, weight(48)); margin(form, controls, 18);
        margin(form, button("DISCARD TAKE", () -> new AlertDialog.Builder(this).setMessage("Discard this unsaved recording?").setNegativeButton("KEEP", null)
                .setPositiveButton("DISCARD", (dialog, which) -> { RecordingService service = RecordingService.live; if (service != null) service.stop(true); }).show()), 8);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("SAMPLER · LIVE RECORDING").setView(form).setNegativeButton("HIDE", null).create();
        recordingDialog = dialog; dialog.setOnDismissListener(ignored -> { if (recordingDialog == dialog) { recordingDialog = null; recordingTime = null; recordingStatus = null; recordingPause = null; recordingSave = null; recordingMeter = null; } });
        dialog.show(); updateRecordingUi();
    }

    private void updateRecordingUi() {
        String completion = prefs.getString("recording_completion_id", "");
        if (visible && !completion.isEmpty() && !completion.equals(prefs.getString("recording_seen_id", ""))) {
            prefs.edit().putString("recording_seen_id", completion).apply();
            if (recordingDialog != null) recordingDialog.dismiss();
            toast(prefs.getString("recording_completion_message", "Recording ended."));
            if (prefs.getBoolean("recording_completion_saved", false)) openPadEditor(prefs.getInt("recording_completion_pad", 0));
            getIntent().removeExtra("open_recorder"); return;
        }
        RecordingService service = RecordingService.live;
        boolean active = service != null && service.isActive();
        if (recordButton != null) recordButton.setText(active ? "● REC " + clock(service.durationMs) : "● RECORD");
        if (active && getIntent().getBooleanExtra("open_recorder", false)) { getIntent().removeExtra("open_recorder"); showRecordingSession(); }
        if (recordingDialog == null) return;
        if (recordingPause != null) { recordingPause.setEnabled(active && !service.saving); recordingPause.setText(active && service.paused ? "RESUME" : "PAUSE"); }
        if (recordingSave != null) recordingSave.setEnabled(active && !service.saving);
        if (!active) return;
        recordingTime.setText(sampleClock(service.durationMs) + " / " + clock(service.maxMs)); recordingMeter.setProgress(service.level);
        String status = service.saving ? "Saving your take…" : service.countInRemainingMs > 0 ? "Starts in " + ((service.countInRemainingMs + 999) / 1000) + "…" : service.paused ? "PAUSED · incoming audio is skipped"
                : (service.source == 0 ? "PHONE AUDIO · stereo" : "MICROPHONE · mono") + " · PAD " + (service.pad + 1);
        if (!service.saving && !service.paused && service.durationMs > 3000 && !service.hasSignal)
            status += service.source == 0 ? "\nNo signal yet. Play media; this app may block capture." : "\nNo signal yet. Check the microphone input.";
        recordingStatus.setText(status);
    }

    private void showSavedTakes() {
        worker.execute(() -> {
            try {
                File[] files = RecordingStore.takes(this); String[] labels = new String[files.length];
                for (int i = 0; i < files.length; i++) labels[i] = files[i].getName().replace("Soulmans-", "").replace(".wav", "") + "\n" + sampleClock(PcmWaveWriter.durationMs(files[i]));
                runOnUiThread(() -> { if (isDestroyed()) return;
                    if (files.length == 0) { toast("No recorded takes yet. Tap RECORD to sample phone audio or your mic."); return; }
                    new AlertDialog.Builder(this).setTitle("SAVED WAV TAKES").setItems(labels, (dialog, index) -> savedTakeActions(files[index])).setNegativeButton("CLOSE", null).show();
                });
            } catch (IOException error) { runOnUiThread(() -> { if (!isDestroyed()) toast("Could not read saved takes: " + error.getMessage()); }); }
        });
    }

    private void savedTakeActions(File file) {
        new AlertDialog.Builder(this).setTitle(file.getName()).setItems(new String[]{"Load into PAD 1", "Load into PAD 2", "Load into PAD 3", "Load into PAD 4", "Save original WAV to Files"}, (dialog, index) -> {
            if (index == 4) { saveRecordingOriginal(file); return; }
            RecordingService service = RecordingService.live;
            if (service != null && service.isActive() && service.pad == index) { toast("That pad is receiving a recording. Save it first or choose another pad."); return; }
            try { if (PlaybackService.live != null) PlaybackService.live.stopPad(index); RecordingStore.loadPad(prefs, index, file, PcmWaveWriter.durationMs(file)); refresh(); openPadEditor(index); }
            catch (IOException error) { toast("This take could not be opened: " + error.getMessage()); }
        }).setNegativeButton("CLOSE", null).show();
    }

    private void saveRecordingOriginal(File file) {
        pendingRecordingExport = Uri.fromFile(file).toString();
        Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("audio/wav").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE, file.getName());
        try { startActivityForResult(create, EXPORT_RECORDING); }
        catch (ActivityNotFoundException error) { toast("Android Files is needed to save the WAV take."); }
    }

    private void exportRecording(Uri destination) {
        String source = pendingRecordingExport; pendingRecordingExport = "";
        worker.execute(() -> {
            try (InputStream input = getContentResolver().openInputStream(Uri.parse(source)); OutputStream output = getContentResolver().openOutputStream(destination, "w")) {
                if (input == null || output == null) throw new IOException("This file location is unavailable");
                byte[] buffer = new byte[65536]; int count; while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
                runOnUiThread(() -> { if (!isDestroyed()) toast("Original WAV saved. The take is still in Saved Takes."); });
            } catch (IOException error) { runOnUiThread(() -> { if (!isDestroyed()) toast("Could not save the WAV take: " + error.getMessage()); }); }
        });
    }

    private void heading(LinearLayout body,String text,String sub){TextView t=label(text,13,CYAN);t.setLetterSpacing(.1f);margin(body,t,22);margin(body,label(sub,11,MUTED),5);}
    private LinearLayout column(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout row(){LinearLayout v=new LinearLayout(this);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private TextView label(String text,float size,int color){TextView t=new TextView(this);t.setText(text);t.setTextSize(size);t.setTextColor(color);t.setFontFeatureSettings("kern");return t;}
    private TextView button(String text,Runnable action){TextView t=label(text,12,WHITE);t.setGravity(Gravity.CENTER);t.setPadding(dp(6),dp(8),dp(6),dp(8));t.setMinHeight(dp(44));t.setBackground(shape(0xff191f32,0xff333d56,14));t.setClickable(true);t.setFocusable(true);t.setOnClickListener(v->action.run());t.setAccessibilityDelegate(new View.AccessibilityDelegate(){@Override public void onInitializeAccessibilityNodeInfo(View host,android.view.accessibility.AccessibilityNodeInfo info){super.onInitializeAccessibilityNodeInfo(host,info);info.setClassName(Button.class.getName());}});return t;}
    private SeekBar slider(int color){SeekBar s=new SeekBar(this);s.setProgressTintList(ColorStateList.valueOf(color));s.setThumbTintList(ColorStateList.valueOf(color));s.setProgressBackgroundTintList(ColorStateList.valueOf(0xff323c55));return s;}
    private GradientDrawable shape(int fill,int line,int radius){GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setCornerRadius(dp(radius));d.setStroke(dp(1),line);return d;}
    private LinearLayout.LayoutParams weight(int h){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(h),1);p.setMargins(dp(3),0,dp(3),0);return p;}
    private void margin(LinearLayout parent,View child,int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(top);parent.addView(child,p);}
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private static String clock(long ms){if(ms<0)ms=0;long sec=ms/1000;return sec>=3600?String.format(Locale.US,"%d:%02d:%02d",sec/3600,(sec/60)%60,sec%60):String.format(Locale.US,"%d:%02d",sec/60,sec%60);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
