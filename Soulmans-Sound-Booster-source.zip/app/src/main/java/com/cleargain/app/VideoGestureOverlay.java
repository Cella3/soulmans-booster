package com.cleargain.app;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.*;
import androidx.media3.ui.PlayerView;
import android.widget.FrameLayout;

/** Gesture coordinates belong to a stationary overlay, never the transformed picture. */
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
final class VideoGestureOverlay extends View {
    private final View picture;
    private final Runnable tapAction,doubleTapAction;
    private float pinchSpan,pinchFocusX,pinchFocusY;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private Runnable pendingTap;
    private float zoom=1,offsetX,offsetY,lastX,lastY,downX,downY;
    private long lastTapAt;
    private boolean manipulated;
    VideoGestureOverlay(Context c,View picture,Runnable tap){this(c,picture,tap,tap);}
    VideoGestureOverlay(Context c,View picture,Runnable tap,Runnable doubleTap){
        super(c);this.picture=picture;tapAction=tap;doubleTapAction=doubleTap;
        setClickable(true);setContentDescription("Pinch to zoom video, drag to pan, double tap for fullscreen");
        picture.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->applyFrame());
    }
    static VideoGestureOverlay attach(Context c,PlayerView player,Runnable tap,Runnable doubleTap){
        View picture=player.getVideoSurfaceView();if(picture==null)return null;
        if(picture instanceof TextureView)VideoColor.attach((TextureView)picture);
        if(picture.getParent() instanceof android.view.ViewGroup)((android.view.ViewGroup)picture.getParent()).setClipChildren(false);
        player.setClipChildren(true);
        VideoGestureOverlay layer=new VideoGestureOverlay(c,picture,tap,doubleTap);
        player.getOverlayFrameLayout().addView(layer,new FrameLayout.LayoutParams(-1,-1));return layer;
    }
    float zoom(){return zoom;}
    float panX(){return getWidth()==0?0:offsetX/getWidth();}
    float panY(){return getHeight()==0?0:offsetY/getHeight();}
    void restore(float z,float x,float y){zoom=Math.max(1,Math.min(10,z));post(()->{offsetX=x*getWidth();offsetY=y*getHeight();applyFrame();});}
    void resetZoom(){zoom=1;offsetX=offsetY=0;applyFrame();}
    private void disallow(boolean value){if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(value);}
    public boolean onTouchEvent(MotionEvent e){
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN: pinchSpan=0;downX=lastX=e.getX();downY=lastY=e.getY();manipulated=false;disallow(zoom>1);break;
            case MotionEvent.ACTION_POINTER_DOWN: manipulated=true;disallow(true);cancelTap();pinchSpan=span(e);pinchFocusX=(e.getX(0)+e.getX(1))/2-getWidth()/2f;pinchFocusY=(e.getY(0)+e.getY(1))/2-getHeight()/2f;break;
            case MotionEvent.ACTION_POINTER_UP:
                pinchSpan=0;int remaining=e.getActionIndex()==0?1:0;lastX=e.getX(remaining);lastY=e.getY(remaining);break;
            case MotionEvent.ACTION_MOVE:
                if(e.getPointerCount()>=2){
                    float next=span(e),fx=(e.getX(0)+e.getX(1))/2-getWidth()/2f,fy=(e.getY(0)+e.getY(1))/2-getHeight()/2f;
                    if(pinchSpan>6&&next>6){float before=zoom;zoom=Math.max(1,Math.min(10,zoom*next/pinchSpan));float ratio=zoom/before;offsetX=fx-(pinchFocusX-offsetX)*ratio;offsetY=fy-(pinchFocusY-offsetY)*ratio;manipulated=true;applyFrame();}
                    pinchSpan=next;pinchFocusX=fx;pinchFocusY=fy;
                }else if(zoom>1){
                    if(Math.hypot(e.getX()-downX,e.getY()-downY)>ViewConfiguration.get(getContext()).getScaledTouchSlop())manipulated=true;
                    offsetX+=e.getX()-lastX;offsetY+=e.getY()-lastY;applyFrame();
                }
                lastX=e.getX();lastY=e.getY();break;
            case MotionEvent.ACTION_UP:
                disallow(false);
                if(!manipulated&&Math.hypot(e.getX()-downX,e.getY()-downY)<ViewConfiguration.get(getContext()).getScaledTouchSlop()){
                    if(lastTapAt>0&&e.getEventTime()-lastTapAt<ViewConfiguration.getDoubleTapTimeout()){cancelTap();lastTapAt=0;doubleTapAction.run();}
                    else{lastTapAt=e.getEventTime();pendingTap=()->{pendingTap=null;tapAction.run();};handler.postDelayed(pendingTap,ViewConfiguration.getDoubleTapTimeout());}
                    performClick();
                }break;
            case MotionEvent.ACTION_CANCEL:disallow(false);cancelTap();break;
        }return true;
    }
    private float span(MotionEvent e){return (float)Math.hypot(e.getX(1)-e.getX(0),e.getY(1)-e.getY(0));}
    private void cancelTap(){if(pendingTap!=null)handler.removeCallbacks(pendingTap);pendingTap=null;}
    private void applyFrame(){
        float mx=Math.max(0,(picture.getWidth()*zoom-getWidth())/2f),my=Math.max(0,(picture.getHeight()*zoom-getHeight())/2f);
        offsetX=Math.max(-mx,Math.min(mx,offsetX));offsetY=Math.max(-my,Math.min(my,offsetY));
        picture.setPivotX(picture.getWidth()/2f);picture.setPivotY(picture.getHeight()/2f);
        picture.setScaleX(zoom);picture.setScaleY(zoom);picture.setTranslationX(offsetX);picture.setTranslationY(offsetY);
    }
    protected void onSizeChanged(int w,int h,int oldW,int oldH){super.onSizeChanged(w,h,oldW,oldH);if(oldW>0)offsetX*=w/(float)oldW;if(oldH>0)offsetY*=h/(float)oldH;applyFrame();}
    public boolean performClick(){super.performClick();return true;}
    protected void onDetachedFromWindow(){cancelTap();super.onDetachedFromWindow();}
}
