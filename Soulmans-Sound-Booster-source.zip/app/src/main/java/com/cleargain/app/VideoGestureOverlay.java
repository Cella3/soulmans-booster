package com.cleargain.app;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/** Transparent gesture layer for pinch-to-zoom video framing and drag-to-pan. */
final class VideoGestureOverlay extends View {
    private final View frame;
    private final Runnable tapAction;
    private final ScaleGestureDetector scaleDetector;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable pendingTap;
    private float zoom = 1f, offsetX, offsetY, lastX, lastY;
    private long lastTapAt;
    private boolean scaled, dragged;

    VideoGestureOverlay(Context context, View videoFrame, Runnable tapAction) {
        super(context);
        frame = videoFrame;
        this.tapAction = tapAction;
        setBackgroundColor(0x00000000);
        setClickable(true);
        setContentDescription("Pinch to zoom, drag to move the video, double tap to reset");
        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {
                float previous = zoom;
                zoom = Math.max(1f, Math.min(5f, zoom * detector.getScaleFactor()));
                float ratio = zoom / previous;
                float focusX = detector.getFocusX() - frame.getWidth() / 2f;
                float focusY = detector.getFocusY() - frame.getHeight() / 2f;
                offsetX = focusX - (focusX - offsetX) * ratio;
                offsetY = focusY - (focusY - offsetY) * ratio;
                scaled = true;
                dragged = true;
                applyFrame();
                return true;
            }
        });
        scaleDetector.setQuickScaleEnabled(false);
    }

    void resetZoom() {
        zoom = 1f;
        offsetX = 0f;
        offsetY = 0f;
        applyFrame();
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastX = event.getX();
                lastY = event.getY();
                scaled = false;
                dragged = false;
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                scaled = true;
                dragged = true;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (event.getPointerCount() == 1 && zoom > 1f) {
                    float dx = event.getX() - lastX;
                    float dy = event.getY() - lastY;
                    if (Math.abs(dx) + Math.abs(dy) > dp(2)) dragged = true;
                    offsetX += dx;
                    offsetY += dy;
                    applyFrame();
                }
                lastX = event.getX();
                lastY = event.getY();
                return true;
            case MotionEvent.ACTION_UP:
                if (!scaled && !dragged) handleTap(event.getX(), event.getY(), event.getEventTime());
                performClick();
                return true;
            case MotionEvent.ACTION_CANCEL:
                if (pendingTap != null) handler.removeCallbacks(pendingTap);
                return true;
            default:
                return true;
        }
    }

    private void handleTap(float x, float y, long eventTime) {
        if (eventTime - lastTapAt < 320) {
            if (pendingTap != null) handler.removeCallbacks(pendingTap);
            pendingTap = null;
            lastTapAt = 0;
            if (zoom == 1f) setZoomAt(2f, x, y); else resetZoom();
            return;
        }
        lastTapAt = eventTime;
        pendingTap = () -> {
            pendingTap = null;
            tapAction.run();
        };
        handler.postDelayed(pendingTap, 320);
    }

    private void setZoomAt(float nextZoom, float focusX, float focusY) {
        float previous = zoom;
        zoom = nextZoom;
        float ratio = zoom / previous;
        float x = focusX - frame.getWidth() / 2f;
        float y = focusY - frame.getHeight() / 2f;
        offsetX = x - (x - offsetX) * ratio;
        offsetY = y - (y - offsetY) * ratio;
        applyFrame();
    }

    private void applyFrame() {
        if (frame.getWidth() == 0 || frame.getHeight() == 0) {
            frame.post(this::applyFrame);
            return;
        }
        float maxX = frame.getWidth() * (zoom - 1f) / 2f;
        float maxY = frame.getHeight() * (zoom - 1f) / 2f;
        offsetX = Math.max(-maxX, Math.min(maxX, offsetX));
        offsetY = Math.max(-maxY, Math.min(maxY, offsetY));
        frame.setPivotX(frame.getWidth() / 2f);
        frame.setPivotY(frame.getHeight() / 2f);
        frame.setScaleX(zoom);
        frame.setScaleY(zoom);
        frame.setTranslationX(offsetX);
        frame.setTranslationY(offsetY);
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    @Override public boolean performClick() { super.performClick(); return true; }

    @Override protected void onDetachedFromWindow() {
        if (pendingTap != null) handler.removeCallbacks(pendingTap);
        super.onDetachedFromWindow();
    }
}
