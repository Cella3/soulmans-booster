package com.cleargain.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import java.util.Locale;
import java.util.function.DoubleSupplier;

/** Zoom actions plus an Audition-style pan thumb proportional to the visible time window. */
final class WaveformControls extends LinearLayout {
    private final WaveformViewport viewport;
    private final TextView range;
    private final Button full, defaults, minus, plus;
    final PanSlider pan;

    WaveformControls(Context context, WaveformViewport viewport, DoubleSupplier anchor, String fullLabel) {
        super(context); this.viewport = viewport; setOrientation(VERTICAL);
        pan = new PanSlider(context, viewport);
        addView(pan, new LayoutParams(-1, dp(44)));
        range = new TextView(context); range.setTextColor(0xffa0aac5); range.setTextSize(10);
        range.setPadding(dp(4), 0, dp(4), dp(4)); addView(range, new LayoutParams(-1, -2));
        LinearLayout actions = new LinearLayout(context);
        full = action(actions, fullLabel, 1.55f, "Show full waveform", viewport::fullSong);
        defaults = action(actions, "DEFAULT", 1.3f, "Default waveform view", () -> viewport.defaultView(anchor.getAsDouble()));
        minus = action(actions, "−", .65f, "Zoom waveform out", () -> viewport.zoomBy(.5));
        plus = action(actions, "+", .65f, "Zoom waveform in", () -> viewport.zoomBy(2));
        addView(actions, new LayoutParams(-1, dp(46)));
        viewport.onChange(this::refresh); refresh();
    }
    private Button action(LinearLayout row, String title, float weight, String description, Runnable callback) {
        Button button = new Button(getContext()); button.setText(title); button.setTextSize(10);
        button.setTextColor(0xff38e5ed); button.setAllCaps(false);
        button.setPadding(0, 0, 0, 0); button.setMinWidth(0); button.setMinimumWidth(0);
        button.setContentDescription(description); button.setOnClickListener(v -> callback.run());
        GradientDrawable background = new GradientDrawable(); background.setColor(0xff191f32);
        background.setCornerRadius(dp(10)); background.setStroke(dp(1), 0xff333d56); button.setBackground(background);
        LayoutParams params = new LayoutParams(0, dp(44), weight); params.setMargins(dp(2), 0, dp(2), 0);
        row.addView(button, params); return button;
    }
    private void refresh() {
        boolean available = viewport.available();
        full.setEnabled(available); defaults.setEnabled(available && viewport.duration() > 0);
        minus.setEnabled(available && viewport.zoom() > 1.0001);
        plus.setEnabled(available && viewport.zoom() < WaveformViewport.MAX_ZOOM - .0001);
        pan.setEnabled(viewport.canPan()); pan.invalidate();
        range.setText(available ? String.format(Locale.US, "%.1f×  ·  %s — %s  ·  PAN VIEW",
                viewport.zoom(), time(Math.round(viewport.duration() * viewport.start())),
                time(Math.round(viewport.duration() * viewport.end()))) : "Waveform controls available when WAV peaks are loaded");
    }
    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    private static String time(long milliseconds) {
        long seconds = Math.max(0, milliseconds) / 1000;
        return seconds >= 3600 ? String.format(Locale.US, "%d:%02d:%02d", seconds / 3600, seconds / 60 % 60, seconds % 60)
                : String.format(Locale.US, "%d:%02d", seconds / 60, seconds % 60);
    }

    static final class PanSlider extends View {
        private final WaveformViewport viewport;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rail = new RectF(), thumb = new RectF();
        private final float density;
        private float grab;
        private boolean dragging;
        PanSlider(Context context, WaveformViewport viewport) {
            super(context); this.viewport = viewport; density = getResources().getDisplayMetrics().density;
            setFocusable(true); setClickable(true); setContentDescription("Waveform pan");
        }
        private void geometry() {
            rail.set(6 * density, getHeight() / 2f - 10 * density, Math.max(6 * density, getWidth() - 6 * density), getHeight() / 2f + 10 * density);
            float width = Math.min(rail.width(), Math.max(24 * density, (float) viewport.span() * rail.width()));
            float left = rail.left + (float) viewport.pan() * (rail.width() - width);
            thumb.set(left, rail.top, left + width, rail.bottom);
        }
        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas); geometry();
            paint.setColor(0xff232d43); canvas.drawRoundRect(rail, 6 * density, 6 * density, paint);
            paint.setColor(isEnabled() ? 0xff205e70 : 0xff364056); canvas.drawRoundRect(thumb, 6 * density, 6 * density, paint);
            paint.setColor(isEnabled() ? 0xff38e5ed : 0xff768199); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(density);
            canvas.drawRoundRect(thumb, 6 * density, 6 * density, paint); paint.setStyle(Paint.Style.FILL);
            for (int i = -1; i <= 1; i++) canvas.drawRect(thumb.centerX() + i * 4 * density, thumb.centerY() - 4 * density, thumb.centerX() + i * 4 * density + density, thumb.centerY() + 4 * density, paint);
        }
        @Override public boolean onTouchEvent(MotionEvent event) {
            if (!isEnabled()) return false;
            geometry();
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    dragging = true; getParent().requestDisallowInterceptTouchEvent(true);
                    grab = event.getX() >= thumb.left && event.getX() <= thumb.right ? event.getX() - thumb.left : thumb.width() / 2;
                    move(event.getX()); return true;
                case MotionEvent.ACTION_MOVE:
                    if (dragging) move(event.getX()); return true;
                case MotionEvent.ACTION_UP:
                    move(event.getX()); dragging = false; getParent().requestDisallowInterceptTouchEvent(false); performClick(); return true;
                case MotionEvent.ACTION_CANCEL:
                    dragging = false; getParent().requestDisallowInterceptTouchEvent(false); return true;
                default: return true;
            }
        }
        private void move(float x) { float travel = rail.width() - thumb.width(); viewport.panTo(travel <= 0 ? 0 : (x - grab - rail.left) / travel); }
        @Override public boolean performClick() { super.performClick(); return true; }
        @Override public boolean onKeyDown(int key, KeyEvent event) {
            if (isEnabled() && (key == KeyEvent.KEYCODE_DPAD_LEFT || key == KeyEvent.KEYCODE_DPAD_RIGHT)) {
                viewport.moveBy(key == KeyEvent.KEYCODE_DPAD_LEFT ? -.1 : .1); return true;
            }
            return super.onKeyDown(key, event);
        }
        @Override public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo info) {
            super.onInitializeAccessibilityNodeInfo(info); info.setClassName(SeekBar.class.getName());
            info.setRangeInfo(AccessibilityNodeInfo.RangeInfo.obtain(AccessibilityNodeInfo.RangeInfo.RANGE_TYPE_FLOAT, 0, 100, (float) viewport.pan() * 100));
            if (isEnabled()) {
                info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SET_PROGRESS);
                info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD);
                info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_BACKWARD);
            }
        }
        @Override public boolean performAccessibilityAction(int action, Bundle args) {
            if (isEnabled()) {
                if (action == AccessibilityNodeInfo.AccessibilityAction.ACTION_SET_PROGRESS.getId() && args != null) {
                    viewport.panTo(args.getFloat(AccessibilityNodeInfo.ACTION_ARGUMENT_PROGRESS_VALUE) / 100); return true;
                }
                if (action == AccessibilityNodeInfo.ACTION_SCROLL_FORWARD || action == AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) {
                    viewport.moveBy(action == AccessibilityNodeInfo.ACTION_SCROLL_FORWARD ? .1 : -.1); return true;
                }
            }
            return super.performAccessibilityAction(action, args);
        }
    }
}
