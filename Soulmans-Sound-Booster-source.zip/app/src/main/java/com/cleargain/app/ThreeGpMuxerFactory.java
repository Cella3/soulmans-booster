package com.cleargain.app;

import android.media.MediaCodec;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.MediaFormatUtil;
import androidx.media3.muxer.BufferInfo;
import androidx.media3.muxer.Muxer;
import androidx.media3.muxer.MuxerException;
import com.google.common.collect.ImmutableList;
import java.io.IOException;
import java.nio.ByteBuffer;

/** Android's platform muxer adapter for exporting the selected clip as a 3GPP file. */
@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
final class ThreeGpMuxerFactory implements Muxer.Factory {
    @Override public Muxer create(String path) throws MuxerException {
        try {
            return new ThreeGpMuxer(new MediaMuxer(path, MediaMuxer.OutputFormat.MUXER_OUTPUT_3GPP));
        } catch (IOException e) {
            throw new MuxerException("Could not create a 3GP output file", e);
        }
    }

    @Override public ImmutableList<String> getSupportedSampleMimeTypes(int trackType) {
        if (trackType == C.TRACK_TYPE_VIDEO) return ImmutableList.of(MimeTypes.VIDEO_H264);
        if (trackType == C.TRACK_TYPE_AUDIO) return ImmutableList.of(MimeTypes.AUDIO_AAC);
        return ImmutableList.of();
    }

    private static final class ThreeGpMuxer implements Muxer {
        private final MediaMuxer muxer;
        private boolean started;

        ThreeGpMuxer(MediaMuxer muxer) { this.muxer = muxer; }

        @Override public int addTrack(Format format) throws MuxerException {
            try {
                if (MimeTypes.isVideo(format.sampleMimeType) && format.rotationDegrees != 0)
                    muxer.setOrientationHint(format.rotationDegrees);
                MediaFormat mediaFormat = MediaFormatUtil.createMediaFormatFromFormat(format);
                return muxer.addTrack(mediaFormat);
            } catch (RuntimeException e) {
                throw new MuxerException("3GP does not support this track format", e);
            }
        }

        @Override public void writeSampleData(int track, ByteBuffer data, BufferInfo info) throws MuxerException {
            try {
                if (!started) {
                    muxer.start();
                    started = true;
                }
                ByteBuffer sample = data.slice();
                MediaCodec.BufferInfo platformInfo = new MediaCodec.BufferInfo();
                platformInfo.set(0, sample.remaining(), info.presentationTimeUs, info.flags);
                muxer.writeSampleData(track, sample, platformInfo);
            } catch (RuntimeException e) {
                throw new MuxerException("Could not write the 3GP video clip", e);
            }
        }

        @Override public void addMetadataEntry(androidx.media3.common.Metadata.Entry entry) {}

        @Override public void close() throws MuxerException {
            try {
                if (started) muxer.stop();
            } catch (RuntimeException e) {
                throw new MuxerException("Could not finish the 3GP video clip", e);
            } finally {
                muxer.release();
            }
        }
    }
}
