package com.cleargain.app;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.util.function.DoubleConsumer;

final class DjWaveView extends View {
    private final Paint p=new Paint(3);private DjEngine.State state;private DoubleConsumer seek;private int accent;
    DjWaveView(Context c,int accent){super(c);this.accent=accent;setContentDescription("DJ track waveform: drag to seek");setClickable(true);}
    void listener(DoubleConsumer seek){this.seek=seek;}
    void state(DjEngine.State s){state=s;invalidate();}
    protected void onDraw(Canvas c){c.drawColor(0xff080e0c);if(state==null||state.peaks()==null)return;float w=getWidth(),h=getHeight(),center=h*.5f;p.setStrokeWidth(1.5f);float[] peaks=state.peaks();for(int x=0;x<w;x+=2){int index=Math.min(peaks.length-1,(int)(x/w*peaks.length));p.setColor(x/w<state.seconds()/state.duration()?accent:0xff687c6b);float v=peaks[index]*(h*.45f);c.drawLine(x,center-v,x,center+v,p);}if(state.loop()){p.setColor(0x447bbd5a);c.drawRect((float)(state.loopIn()/state.duration()*w),0,(float)(state.loopOut()/state.duration()*w),h,p);}p.setColor(0xffffecbd);c.drawLine((float)(state.seconds()/state.duration()*w),0,(float)(state.seconds()/state.duration()*w),h,p);}
    public boolean onTouchEvent(MotionEvent e){if(state==null||!state.loaded())return true;if(e.getAction()==MotionEvent.ACTION_DOWN)getParent().requestDisallowInterceptTouchEvent(true);if(e.getAction()==MotionEvent.ACTION_DOWN||e.getAction()==MotionEvent.ACTION_MOVE){if(seek!=null)seek.accept(Math.max(0,Math.min(1,e.getX()/getWidth()))*state.duration());}if(e.getAction()==MotionEvent.ACTION_UP||e.getAction()==MotionEvent.ACTION_CANCEL){getParent().requestDisallowInterceptTouchEvent(false);performClick();}return true;}
    public boolean performClick(){super.performClick();return true;}
}
