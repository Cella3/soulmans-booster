package com.cleargain.app;

/** Small, deterministic PCM operations shared by the clip exporter and its tests. */
final class SampleRenderMath {
    private SampleRenderMath() { }

    static short[] render(short[] input,int channels,int sampleRate,float pitchSemitones,int fadeInMs,int fadeOutMs,int echoDelayMs,float echoAmount){
        if(channels<1||input.length%channels!=0)throw new IllegalArgumentException("PCM must contain complete frames");
        int inputFrames=input.length/channels;if(inputFrames==0)return new short[0];
        double ratio=Math.pow(2,Math.max(-12,Math.min(12,pitchSemitones))/12.0);
        int outputFrames=Math.max(1,(int)Math.ceil(inputFrames/ratio));short[] pitched=new short[outputFrames*channels];
        for(int frame=0;frame<outputFrames;frame++){
            double source=frame*ratio;int low=Math.min(inputFrames-1,(int)source),high=Math.min(inputFrames-1,low+1);float frac=(float)(source-low);
            for(int c=0;c<channels;c++){float a=input[low*channels+c],b=input[high*channels+c];pitched[frame*channels+c]=(short)Math.round(a+(b-a)*frac);}
        }
        int fadeIn=Math.min(outputFrames,Math.max(0,sampleRate*fadeInMs/1000));
        int fadeOut=Math.min(outputFrames,Math.max(0,sampleRate*fadeOutMs/1000));
        int echoFrames=echoAmount<=0?0:Math.max(1,sampleRate*Math.max(1,echoDelayMs)/1000);
        int dryFrames=outputFrames;outputFrames+=echoFrames==0?0:echoFrames*3;
        short[] rendered=new short[outputFrames*channels];
        float wet=Math.max(0,Math.min(.7f,echoAmount));float[][] delay=echoFrames==0?null:new float[channels][echoFrames];int cursor=0;
        for(int frame=0;frame<outputFrames;frame++){
            float gain=1;
            if(frame<dryFrames&&fadeIn>0&&frame<fadeIn)gain=Math.min(gain,(float)frame/fadeIn);
            if(frame<dryFrames&&fadeOut>0&&frame>=dryFrames-fadeOut)gain=Math.min(gain,(float)(dryFrames-1-frame)/fadeOut);
            for(int c=0;c<channels;c++){
                float dry=frame<dryFrames?pitched[frame*channels+c]/32768f*gain:0;float tail=delay==null?0:delay[c][cursor];float mixed=dry+(tail*wet);
                if(delay!=null)delay[c][cursor]=Math.max(-1,Math.min(1,dry+tail*.48f));
                rendered[frame*channels+c]=(short)Math.max(-32768,Math.min(32767,Math.round(mixed*32767)));
            }
            if(delay!=null&&++cursor==echoFrames)cursor=0;
        }
        return rendered;
    }
}
