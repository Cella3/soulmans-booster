package com.cleargain.app;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import androidx.media3.common.*;
import androidx.media3.common.audio.AudioProcessor;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.audio.AudioSink;
import androidx.media3.exoplayer.audio.DefaultAudioSink;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;
import org.json.JSONArray;
import java.util.*;

@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
public final class PlaybackService extends MediaSessionService {
    static PlaybackService live;
    final SoundProcessor processor=new SoundProcessor();
    ExoPlayer player;
    private final ExoPlayer[] pads=new ExoPlayer[4];
    private final PadEffectProcessor[] padEffects=new PadEffectProcessor[4];
    private final Runnable sampleTick=new Runnable(){public void run(){boolean active=false;for(int i=0;i<pads.length;i++)if(pads[i]!=null&&padPlaying(i)){active=true;updatePad(i);}if(active)handler.postDelayed(this,24);}};
    private MediaSession session;
    private MusicStore store;
    private SharedPreferences prefs;
    private boolean counted,restoring;
    String message="";
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable remember=new Runnable(){public void run(){saveQueue();handler.postDelayed(this,5000);}};

    @Override public void onCreate() {
        super.onCreate(); live=this;store=MusicStore.get(this);prefs=getSharedPreferences("settings",MODE_PRIVATE);
        EqProfile.ensureDefaults(prefs);
        DefaultRenderersFactory renderers=new DefaultRenderersFactory(this) {
            @Override protected AudioSink buildAudioSink(Context c,boolean f,boolean p) {
                return new DefaultAudioSink.Builder(c).setEnableFloatOutput(false)
                        .setEnableAudioTrackPlaybackParams(false).setAudioProcessors(new AudioProcessor[]{processor}).build();
            }
        };
        player=new ExoPlayer.Builder(this,renderers).build();
        player.setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),true);
        player.setHandleAudioBecomingNoisy(true);
        player.setWakeMode(C.WAKE_MODE_LOCAL);
        applySound();
        player.addListener(new Player.Listener() {
            @Override public void onMediaItemTransition(MediaItem item,int reason) {
                counted=false;message="";applyPitch();applyVideoEffects();syncVideoClipLoop();if(!restoring)saveQueue();
                if(player.isPlaying())countPlay();
            }
            @Override public void onIsPlayingChanged(boolean playing) {
                syncVideoClipLoop();if(playing) {disableGlobalBoost();countPlay();}
                saveQueue();
            }
            @Override public void onPlaybackStateChanged(int state) {saveQueue();}
            @Override public void onTracksChanged(Tracks tracks){float speed=requestedSpeed();if(speed>8&&player.getTrackSelectionParameters().disabledTrackTypes.contains(C.TRACK_TYPE_AUDIO)&&Math.abs(player.getPlaybackParameters().speed-speed)>.01)applyPitch();}
            @Override public void onTimelineChanged(Timeline timeline,int reason) {if(!restoring)saveQueue();}
            @Override public void onPositionDiscontinuity(Player.PositionInfo oldPos,Player.PositionInfo newPos,int reason) {if(!restoring)saveQueue();}
            @Override public void onShuffleModeEnabledChanged(boolean enabled) {prefs.edit().putBoolean("shuffle",enabled).apply();}
            @Override public void onRepeatModeChanged(int mode) {prefs.edit().putInt("repeat",mode).apply();}
            @Override public void onPlayerError(PlaybackException error) {
                message="Couldn’t play this file. It may be unsupported, moved, or no longer accessible. Re-import it or try the next track.";
                player.pause();saveQueue();
            }
        });
        PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        session=new MediaSession.Builder(this,player).setSessionActivity(open).build();
        restoreQueue();handler.postDelayed(remember,5000);
    }
    private void countPlay() {
        MediaItem item=player.getCurrentMediaItem();if(!counted&&item!=null&&store.track(item.mediaId)!=null){counted=true;store.played(item.mediaId);}
    }
    private final Runnable videoClipLoop=new Runnable(){public void run(){
        if(player==null||!player.isPlaying())return;
        MediaItem item=player.getCurrentMediaItem();String uri=item==null?"":item.mediaId;Track track=uri.isEmpty()?null:store.track(uri);
        if(track==null||!track.isVideo()||!VideoClipPrefs.loops(prefs,uri))return;
        long start=VideoClipPrefs.start(prefs,uri),end=VideoClipPrefs.end(prefs,uri,player.getDuration());
        long duration=player.getDuration();if(duration>0&&duration!=C.TIME_UNSET)end=Math.min(end,duration);
        if(end>start){long position=player.getCurrentPosition();if(position<start||position>=end)player.seekTo(start);handler.postDelayed(this,40);}
    }};
    private void syncVideoClipLoop(){
        handler.removeCallbacks(videoClipLoop);
        if(player==null||!player.isPlaying())return;
        MediaItem item=player.getCurrentMediaItem();Track track=item==null?null:store.track(item.mediaId);
        if(track!=null&&track.isVideo()&&VideoClipPrefs.loops(prefs,item.mediaId))handler.post(videoClipLoop);
    }
    void disableGlobalBoost() {
        if(prefs.getBoolean("enabled",false)){prefs.edit().putBoolean("enabled",false).apply();stopService(new Intent(this,BoostService.class));}
    }
    void applySound() {
        processor.settings=new SoundProcessor.Settings(prefs.getBoolean("player_boost",false)?prefs.getInt("gain_db",4):0,
                EqProfile.levels(prefs),prefs.getBoolean("player_eq",false));
    }
    void pitch(float semitones) {
        MediaItem item=player.getCurrentMediaItem();if(item==null)return;
        semitones=Math.max(-12,Math.min(12,semitones));store.pitch(item.mediaId,semitones);
        player.setPlaybackParameters(new PlaybackParameters(requestedSpeed(),(float)Math.pow(2,semitones/12.0)));
    }
    private void applyPitch(){
        MediaItem item=player.getCurrentMediaItem();Track t=item==null?null:store.track(item.mediaId);float speed=requestedSpeed();
        player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_AUDIO,t!=null&&t.isVideo()&&speed>8).build());
        player.setPlaybackParameters(new PlaybackParameters(speed,t==null?1f:(float)Math.pow(2,t.pitch/12.0)));
    }
    float requestedSpeed(){MediaItem item=player.getCurrentMediaItem();return item==null?1:prefs.getFloat("video_speed_"+VideoClipPrefs.key(item.mediaId),1);}
    void speed(float value){MediaItem item=player.getCurrentMediaItem();if(item==null)return;prefs.edit().putFloat("video_speed_"+VideoClipPrefs.key(item.mediaId),Math.max(.25f,Math.min(50,value))).apply();applyPitch();}
    void updateVideoLoop(){syncVideoClipLoop();}
    void applyVideoEffects(){VideoColor.refresh();}
    void triggerPad(int i) {
        String uri=prefs.getString("pad_uri_"+i,"");if(uri.isEmpty())return;
        if(padPlaying(i)){int mode=prefs.getInt("pad_trigger_"+i,0);if(mode!=0){stopPad(i);return;}stopPad(i);}
        int start=Math.max(0,prefs.getInt("pad_start_"+i,0));int duration=prefs.getInt("pad_duration_"+i,0);int end=prefs.getInt("pad_end_"+i,duration);if(end<=0)end=duration;if(end>0)end=Math.max(start+1,Math.min(end,duration));
        if(pads[i]==null) {
            final int index=i;PadEffectProcessor effect=new PadEffectProcessor();padEffects[i]=effect;
            DefaultRenderersFactory padRenderers=new DefaultRenderersFactory(this){
                @Override protected AudioSink buildAudioSink(Context c,boolean floatOutput,boolean playbackParams){return new DefaultAudioSink.Builder(c).setEnableFloatOutput(false).setEnableAudioTrackPlaybackParams(false).setAudioProcessors(new AudioProcessor[]{effect}).build();}
            };
            pads[i]=new ExoPlayer.Builder(this,padRenderers).build();
            pads[i].setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),false);
            pads[i].setHandleAudioBecomingNoisy(true);
            pads[i].addListener(new Player.Listener(){@Override public void onPlayerError(PlaybackException error){message="Sample "+(index+1)+" unavailable. Hold its pad to choose another file.";}});
        }
        ExoPlayer p=pads[i];PadEffectProcessor effect=padEffects[i];if(effect!=null)effect.settings(prefs.getInt("pad_echo_delay_"+i,220),prefs.getInt("pad_echo_"+i,0)/100f);
        p.setMediaItem(MediaItem.fromUri(uri));p.setRepeatMode(Player.REPEAT_MODE_OFF);
        p.setPlaybackParameters(new PlaybackParameters(1f,(float)Math.pow(2,prefs.getInt("pad_pitch_"+i,0)/12.0)));
        p.setVolume(prefs.getInt("pad_volume",65)/100f);p.prepare();if(start>0)p.seekTo(start);p.play();handler.removeCallbacks(sampleTick);handler.post(sampleTick);
    }
    private void updatePad(int index){
        ExoPlayer p=pads[index];if(p==null||p.getPlaybackState()!=Player.STATE_READY)return;
        int start=Math.max(0,prefs.getInt("pad_start_"+index,0)),duration=prefs.getInt("pad_duration_"+index,0),end=prefs.getInt("pad_end_"+index,duration);if(end<=0)end=duration;if(end<=start)return;
        long position=p.getCurrentPosition();
        if(position>=end){if(prefs.getBoolean("pad_loop_"+index,false)){p.seekTo(start);position=start;}else{stopPad(index);return;}}
        float gain=prefs.getInt("pad_volume",65)/100f;
        int fadeIn=prefs.getInt("pad_fade_in_"+index,0),fadeOut=prefs.getInt("pad_fade_out_"+index,0);
        if(fadeIn>0&&position<start+fadeIn)gain*=Math.max(0,Math.min(1,(position-start)/(float)fadeIn));
        if(fadeOut>0&&position>end-fadeOut)gain*=Math.max(0,Math.min(1,(end-position)/(float)fadeOut));
        p.setVolume(gain);
    }
    boolean padPlaying(int i){return pads[i]!=null&&pads[i].getPlayWhenReady()&&pads[i].getPlaybackState()!=Player.STATE_ENDED&&pads[i].getPlaybackState()!=Player.STATE_IDLE;}
    void stopPad(int i){if(pads[i]!=null){pads[i].setVolume(0);pads[i].stop();pads[i].clearMediaItems();}}
    void stopPads(){for(int i=0;i<4;i++)stopPad(i);}
    void padVolume(int v){prefs.edit().putInt("pad_volume",v).apply();for(ExoPlayer p:pads)if(p!=null)p.setVolume(v/100f);}
    void saveQueue() {
        if(player==null||restoring)return;
        JSONArray q=new JSONArray();for(int i=0;i<player.getMediaItemCount();i++)q.put(player.getMediaItemAt(i).mediaId);
        prefs.edit().putString("queue",q.toString()).putInt("queue_index",Math.max(0,player.getCurrentMediaItemIndex()))
                .putLong("queue_position",Math.max(0,player.getCurrentPosition())).apply();
    }
    private void restoreQueue() {
        restoring=true;
        try {
            JSONArray q=new JSONArray(prefs.getString("queue","[]"));List<MediaItem> items=new ArrayList<>();
            int original=prefs.getInt("queue_index",0),newIndex=0;
            for(int i=0;i<q.length();i++){Track t=store.track(q.getString(i));if(t!=null){if(i<original)newIndex++;items.add(t.item());}}
            if(!items.isEmpty()){player.setMediaItems(items,Math.min(newIndex,items.size()-1),prefs.getLong("queue_position",0));player.prepare();}
            player.setShuffleModeEnabled(prefs.getBoolean("shuffle",false));player.setRepeatMode(prefs.getInt("repeat",Player.REPEAT_MODE_OFF));
        } catch(Exception ignored) {message="The saved queue could not be restored. Choose tracks from your library.";}
        finally{restoring=false;}
    }
    @Override public MediaSession onGetSession(MediaSession.ControllerInfo info){return session;}
    @Override public void onDestroy(){handler.removeCallbacksAndMessages(null);saveQueue();stopPads();for(ExoPlayer p:pads)if(p!=null)p.release();if(session!=null)session.release();if(player!=null)player.release();live=null;super.onDestroy();}
}
