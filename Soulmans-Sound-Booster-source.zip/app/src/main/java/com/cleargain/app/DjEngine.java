package com.cleargain.app;

import android.media.*;
import android.os.Process;
import android.os.SystemClock;
import java.util.Arrays;

/** Two independent, bidirectional PCM transports mixed into a single low-latency AudioTrack. */
final class DjEngine implements AutoCloseable {
    static final int RATE=44100;
    static final class Deck {
        DjPcm pcm;Track track;double position,scratchTarget;boolean playing,scratching,loop;
        double loopIn,loopOut;long scratchMoved;float rate=1,volume=1,trim=1,echo,filter,peak;float bpm;
        int[] bands=new int[7];boolean dirty=true;final DspEngine eq=new DspEngine();
        final float[][] delay=new float[2][RATE*2];final float[] low=new float[2];int delayAt;
        final double[] cues={-1,-1,-1,-1};
    }
    record State(String title,String uri,boolean playing,boolean loaded,double seconds,double duration,
                 float rate,float bpm,float peak,float[] peaks,boolean loop,double loopIn,double loopOut){}
    final Deck[] decks={new Deck(),new Deck()};
    private final Object lock=new Object();
    private volatile boolean running;
    private Thread thread;private AudioTrack output;
    private float cross=.5f,master=.8f;
    volatile String error="";
    volatile long renderedFrames;
    void start(){if(running)return;
        int size=Math.max(4096,AudioTrack.getMinBufferSize(RATE,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_FLOAT));
        output=new AudioTrack.Builder().setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(new AudioFormat.Builder().setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).setEncoding(AudioFormat.ENCODING_PCM_FLOAT).build())
                .setTransferMode(AudioTrack.MODE_STREAM).setBufferSizeInBytes(size).setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY).build();
        if(output.getState()!=AudioTrack.STATE_INITIALIZED){output.release();output=null;throw new IllegalStateException("Audio output unavailable");}
        running=true;output.play();thread=new Thread(()->{Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);float[] block=new float[512];try{while(running){render(block);int sent=0;while(running&&sent<block.length){int n=output.write(block,sent,block.length-sent,AudioTrack.WRITE_BLOCKING);if(n<0)throw new IllegalStateException("Audio output error "+n);sent+=n;}}}catch(RuntimeException e){error=e.getMessage();pause();running=false;}},"Soulmans-DJ-Audio");thread.start();
    }
    void load(int index,Track track,DjPcm pcm,float bpm){synchronized(lock){Deck d=decks[index];if(d.pcm!=null)d.pcm.close();d.pcm=pcm;d.track=track;d.position=0;d.scratchTarget=0;d.playing=false;d.scratching=false;d.loop=false;d.loopIn=0;d.loopOut=pcm.frames;d.rate=1;d.bpm=bpm;d.eq.reset();d.dirty=true;Arrays.fill(d.cues,-1);for(float[] line:d.delay)Arrays.fill(line,0);}}
    State state(int i){synchronized(lock){Deck d=decks[i];DjPcm p=d.pcm;return new State(d.track==null?"LOAD DECK "+(i==0?"A":"B"):d.track.title,d.track==null?"":d.track.uri,d.playing,p!=null,p==null?0:d.position/p.rate,p==null?0:p.frames/(double)p.rate,d.rate,d.bpm,d.peak,p==null?null:p.peaks,d.loop,p==null?0:d.loopIn/p.rate,p==null?0:d.loopOut/p.rate);}}
    void toggle(int i){synchronized(lock){Deck d=decks[i];if(d.pcm!=null){if(d.position>=d.pcm.frames-1)d.position=d.loop?d.loopIn:0;d.playing=!d.playing;}}}
    void pause(){synchronized(lock){for(Deck d:decks){d.playing=false;d.scratching=false;}}}
    void seek(int i,double seconds){synchronized(lock){Deck d=decks[i];if(d.pcm!=null)d.position=Math.max(0,Math.min(d.pcm.frames-1,seconds*d.pcm.rate));}}
    void rate(int i,float rate){synchronized(lock){decks[i].rate=Math.max(.5f,Math.min(2,rate));}}
    void bpm(int i,float bpm){synchronized(lock){decks[i].bpm=bpm;}}
    boolean sync(int i,boolean phase,double myFirstBeat,double otherFirstBeat){synchronized(lock){Deck mine=decks[i],other=decks[1-i];if(mine.pcm==null||other.pcm==null||mine.bpm<=0||other.bpm<=0)return false;float ratio=other.bpm*other.rate/mine.bpm;if(ratio<.5||ratio>2)return false;mine.rate=ratio;if(phase){double beat=60/mine.bpm,otherBeat=60/other.bpm,otherFraction=positiveMod(other.position/other.pcm.rate-otherFirstBeat,otherBeat)/otherBeat;double mineSeconds=mine.position/mine.pcm.rate;double bar=Math.floor((mineSeconds-myFirstBeat)/beat);mine.position=Math.max(0,Math.min(mine.pcm.frames-1,(myFirstBeat+(bar+otherFraction)*beat)*mine.pcm.rate));}return true;}}
    private static double positiveMod(double a,double b){return ((a%b)+b)%b;}
    void crossfade(float value){synchronized(lock){cross=Math.max(0,Math.min(1,value));}}
    float crossfade(){synchronized(lock){return cross;}}
    void master(float value){synchronized(lock){master=Math.max(0,Math.min(1,value));}}
    void volume(int i,float value){synchronized(lock){decks[i].volume=Math.max(0,Math.min(1,value));}}
    void trim(int i,float value){synchronized(lock){decks[i].trim=Math.max(0,Math.min(2,value));}}
    void eq(int i,int[] values){synchronized(lock){decks[i].bands=values.clone();decks[i].dirty=true;}}
    void effect(int i,float echo,float filter){synchronized(lock){decks[i].echo=Math.max(0,Math.min(.7f,echo));decks[i].filter=Math.max(-1,Math.min(1,filter));}}
    void cue(int i,int pad,boolean save){synchronized(lock){Deck d=decks[i];if(d.pcm==null)return;if(save||d.cues[pad]<0)d.cues[pad]=d.position;else {d.position=d.cues[pad];d.playing=true;}}}
    double cueTime(int i,int pad){synchronized(lock){Deck d=decks[i];return d.pcm==null||d.cues[pad]<0?-1:d.cues[pad]/d.pcm.rate;}}
    void restoreCue(int i,int pad,double seconds){synchronized(lock){Deck d=decks[i];if(d.pcm!=null)d.cues[pad]=seconds<0?-1:Math.min(d.pcm.frames-1,seconds*d.pcm.rate);}}
    void loop(int i,double in,double out,boolean enabled){synchronized(lock){Deck d=decks[i];if(d.pcm==null)return;d.loopIn=Math.max(0,Math.min(d.pcm.frames-2,in*d.pcm.rate));d.loopOut=Math.max(d.loopIn+1,Math.min(d.pcm.frames,out*d.pcm.rate));d.loop=enabled;}}
    void scratchBegin(int i){synchronized(lock){Deck d=decks[i];d.scratching=true;d.scratchTarget=d.position;d.scratchMoved=SystemClock.elapsedRealtime();}}
    void scratchMove(int i,double seconds){synchronized(lock){Deck d=decks[i];if(d.pcm!=null){d.scratchTarget=Math.max(0,Math.min(d.pcm.frames-1,d.scratchTarget+seconds*d.pcm.rate));d.scratchMoved=SystemClock.elapsedRealtime();}}}
    void scratchEnd(int i){synchronized(lock){decks[i].scratching=false;}}
    static float fadeGain(float cross,int deck){return (float)(deck==0?Math.cos(cross*Math.PI/2):Math.sin(cross*Math.PI/2));}
    static double transportStep(boolean scratch,double target,double position,int sourceRate,float speed,boolean playing,long ageMs){return scratch?(ageMs>65?0:Math.max(-12,Math.min(12,(target-position)/(sourceRate*.018)))*sourceRate/RATE):(playing?speed*sourceRate/RATE:0);}
    void render(float[] block){synchronized(lock){Arrays.fill(block,0);int frames=block.length/2;long now=SystemClock.elapsedRealtime();for(int i=0;i<2;i++){
            Deck d=decks[i];if(d.pcm==null)continue;DjPcm p=d.pcm;if(d.dirty){d.eq.configure(RATE,2,0,d.bands,true);d.dirty=false;}
            float gain=fadeGain(cross,i)*d.volume*d.trim*master,peak=0;int delay=Math.max(1,Math.min(RATE*2-1,(int)(RATE*30/Math.max(30,d.bpm*d.rate))));float cutoff=d.filter>=0?(float)(16000*Math.pow(.011,Math.abs(d.filter))):(float)(40*Math.pow(200,Math.abs(d.filter)));float alpha=1-(float)Math.exp(-2*Math.PI*cutoff/RATE);
            for(int f=0;f<frames;f++){
                double step=transportStep(d.scratching,d.scratchTarget,d.position,p.rate,d.rate,d.playing,now-d.scratchMoved);
                if(d.loop&&!d.scratching&&step!=0&&(d.position>=d.loopOut||d.position<d.loopIn))d.position=d.loopIn+positiveMod(d.position-d.loopIn,d.loopOut-d.loopIn);
                if(!d.scratching&&d.position>=p.frames-1){d.playing=false;step=0;}
                int tap=(d.delayAt-delay+RATE*2)%(RATE*2);
                for(int ch=0;ch<2;ch++){float x=step==0?0:p.interpolated(d.position,ch);x=d.eq.process(x,ch);if(Math.abs(d.filter)>.015){d.low[ch]+=alpha*(x-d.low[ch]);x=d.filter>0?d.low[ch]:x-d.low[ch];}float wet=d.delay[ch][tap];d.delay[ch][d.delayAt]=x+wet*.4f;x=x*(1-d.echo)+wet*d.echo;peak=Math.max(peak,Math.abs(x));block[f*2+ch]+=x*gain;}
                d.delayAt=(d.delayAt+1)%(RATE*2);d.position=Math.max(0,Math.min(p.frames-1,d.position+step));
            }d.peak=Math.max(peak,d.peak*.87f);
        }for(int i=0;i<block.length;i++){float x=block[i];if(Math.abs(x)>.9)block[i]=(float)Math.copySign(.9+.1*Math.tanh((Math.abs(x)-.9)/.1),x);}renderedFrames+=frames;}}
    public void close(){running=false;if(output!=null){try{output.pause();output.flush();}catch(RuntimeException ignored){}}if(thread!=null){try{thread.join(1000);}catch(InterruptedException e){Thread.currentThread().interrupt();}}if(output!=null){output.release();output=null;}synchronized(lock){for(Deck d:decks)if(d.pcm!=null){d.pcm.close();d.pcm=null;}}}
}
