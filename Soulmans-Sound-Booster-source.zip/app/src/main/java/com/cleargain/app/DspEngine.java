package com.cleargain.app;

/** PCM equalizer and soft limiter. No audio capture or microphone permission is used. */
final class DspEngine {
    static final int[] FREQUENCIES={60,150,400,1000,2500,6000,12000};
    private final double[][] coeff=new double[7][5];
    private double[][] z1,z2;
    private double gain=1;
    private boolean limiting;
    void configure(int rate,int channels,float boost,int[] levels,boolean eq) {
        if(z1==null||z1.length!=channels) {z1=new double[channels][7];z2=new double[channels][7];}
        gain=Math.pow(10,Math.max(0,Math.min(12,boost))/20.0);
        limiting=boost>0 || eq;
        for(int i=0;i<7;i++) {
            double db=eq?levels[i]:0, a=Math.pow(10,db/40),w=2*Math.PI*Math.min(FREQUENCIES[i],rate*.45)/rate;
            double alpha=Math.sin(w)/2.2,cos=Math.cos(w),a0=1+alpha/a;
            coeff[i]=new double[]{(1+alpha*a)/a0,-2*cos/a0,(1-alpha*a)/a0,-2*cos/a0,(1-alpha/a)/a0};
        }
    }
    void reset() { if(z1!=null) {for(double[] z:z1)java.util.Arrays.fill(z,0);for(double[] z:z2)java.util.Arrays.fill(z,0);} }
    float process(float input,int channel) {
        double x=input;
        for(int b=0;b<7;b++) {
            double[] c=coeff[b];double y=c[0]*x+z1[channel][b];
            z1[channel][b]=c[1]*x-c[3]*y+z2[channel][b];z2[channel][b]=c[2]*x-c[4]*y;x=y;
        }
        x*=gain;
        // Transparent below -2 dBFS; smooth saturation above it avoids hard clipping.
        if(limiting && Math.abs(x)>.8) x=Math.copySign(.8+.2*Math.tanh((Math.abs(x)-.8)/.2),x);
        return (float)x;
    }
}
