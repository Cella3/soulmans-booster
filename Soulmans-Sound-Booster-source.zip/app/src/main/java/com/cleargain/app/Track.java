package com.cleargain.app;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;

final class Track {
    final String uri, title, artist;
    final long duration, lastPlayed;
    final int plays;
    final float pitch;
    Track(String uri, String title, String artist, long duration, int plays, long lastPlayed, float pitch) {
        this.uri=uri; this.title=title; this.artist=artist; this.duration=duration;
        this.plays=plays; this.lastPlayed=lastPlayed; this.pitch=pitch;
    }
    MediaItem item() {
        return new MediaItem.Builder().setMediaId(uri).setUri(uri)
                .setMediaMetadata(new MediaMetadata.Builder().setTitle(title).setArtist(artist).build()).build();
    }
}
