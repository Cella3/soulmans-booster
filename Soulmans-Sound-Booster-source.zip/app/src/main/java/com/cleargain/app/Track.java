package com.cleargain.app;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;

final class Track {
    final String uri, title, artist, mimeType;
    final long duration, lastPlayed;
    final int plays;
    final float pitch;
    Track(String uri, String title, String artist, long duration, int plays, long lastPlayed, float pitch, String mimeType) {
        this.uri=uri; this.title=title; this.artist=artist; this.duration=duration;
        this.plays=plays; this.lastPlayed=lastPlayed; this.pitch=pitch; this.mimeType=mimeType==null?"":mimeType;
    }
    boolean isVideo() { return mimeType.startsWith("video/") || MusicStore.isVideo("",uri); }
    boolean isWave() { return uri.toLowerCase(java.util.Locale.ROOT).matches(".*\\.wav(?:[?#].*)?$"); }
    MediaItem item() {
        MediaItem.Builder builder=new MediaItem.Builder().setMediaId(uri).setUri(uri)
                .setMediaMetadata(new MediaMetadata.Builder().setTitle(title).setArtist(artist).build());
        if(!mimeType.isEmpty())builder.setMimeType(mimeType);
        return builder.build();
    }
}
