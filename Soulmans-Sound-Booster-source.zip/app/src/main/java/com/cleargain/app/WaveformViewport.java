package com.cleargain.app;

import java.util.ArrayList;
import java.util.List;

/** A bounded visible time window. Panning this window never changes audio playback. */
final class WaveformViewport {
    static final double MAX_ZOOM = 128;
    static final int PEAK_BINS = 16384;
    private double start, span = 1;
    private long duration;
    private boolean available;
    private final List<Runnable> listeners = new ArrayList<>();

    void onChange(Runnable listener) { listeners.add(listener); }
    private void changed() { for (Runnable listener : listeners) listener.run(); }
    double start() { return start; }
    double span() { return span; }
    double end() { return Math.min(1, start + span); }
    double zoom() { return 1 / span; }
    long duration() { return duration; }
    boolean available() { return available; }
    boolean canPan() { return available && span < 1; }
    double pan() { return span >= 1 ? 0 : start / (1 - span); }
    void setAvailable(boolean value) { if (available != value) { available = value; changed(); } }
    void setDuration(long value) { value = Math.max(0, value); if (duration != value) { duration = value; changed(); } }
    void fullSong() { window(0, 1); }
    void defaultView(double anchor) {
        double width = duration <= 0 ? 1 : Math.min(1, 30000.0 / duration);
        width = Math.max(1 / MAX_ZOOM, width);
        window(clamp(anchor) - width / 2, width);
    }
    void zoomBy(double factor) {
        if (!Double.isFinite(factor) || factor <= 0) return;
        double width = Math.max(1 / MAX_ZOOM, Math.min(1, span / factor));
        window(start + span / 2 - width / 2, width);
    }
    void panTo(double fraction) { window(clamp(fraction) * (1 - span), span); }
    void moveBy(double visibleWindows) { window(start + visibleWindows * span, span); }
    double timeAt(double relativeX) { return clamp(start + clamp(relativeX) * span); }
    double xAt(double time) { return (time - start) / span; }
    private void window(double from, double width) {
        width = Math.max(1 / MAX_ZOOM, Math.min(1, width));
        from = Math.max(0, Math.min(1 - width, from));
        if (start == from && span == width) return;
        start = from; span = width; changed();
    }
    private static double clamp(double value) { return Double.isFinite(value) ? Math.max(0, Math.min(1, value)) : 0; }

    /** Pool all bins covered by a bar, so overview rendering does not drop loud transients. */
    float peak(float[] peaks, double left, double right) {
        if (peaks == null || peaks.length == 0) return 0;
        int from = Math.min(peaks.length - 1, (int) Math.floor(timeAt(left) * peaks.length));
        int to = Math.max(from + 1, Math.min(peaks.length, (int) Math.ceil(timeAt(right) * peaks.length)));
        float maximum = 0;
        for (int i = from; i < to; i++) if (Float.isFinite(peaks[i])) maximum = Math.max(maximum, Math.abs(peaks[i]));
        return Math.min(1, maximum);
    }
}
