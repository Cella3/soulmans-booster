package com.cleargain.app;

import android.content.ContentResolver;
import android.net.Uri;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

/** Reads a compact peak envelope from ordinary little-endian PCM or float WAV files. */
final class WavWaveformReader {
    private WavWaveformReader() { }

    static float[] read(ContentResolver resolver, Uri uri, int bins) throws IOException {
        try(InputStream in=resolver.openInputStream(uri)) {
            if(in==null)throw new IOException("Cannot open WAV file");
            return read(in,bins);
        }
    }

    static float[] read(InputStream source,int bins) throws IOException {
        if(bins<1)throw new IllegalArgumentException("bins must be positive");
        InputStream in=source instanceof BufferedInputStream?source:new BufferedInputStream(source,32768);
        byte[] header=new byte[12];if(!readFully(in,header,header.length))return null;
        if(!ascii(header,0,"RIFF")||!ascii(header,8,"WAVE"))return null;
        int format=0,channels=0,bits=0,blockAlign=0;
        while(true) {
            byte[] chunk=new byte[8];if(!readFully(in,chunk,chunk.length))return null;
            String id=new String(chunk,0,4,java.nio.charset.StandardCharsets.US_ASCII);
            long size=u32(chunk,4);
            if(id.equals("fmt ")) {
                if(size<16||size>65536)return null;
                byte[] fmt=new byte[(int)size];if(!readFully(in,fmt,fmt.length))return null;
                format=u16(fmt,0);channels=u16(fmt,2);blockAlign=u16(fmt,12);bits=u16(fmt,14);
            } else if(id.equals("data")) {
                if(format!=1&&format!=3)return null;
                int bytesPerSample=(bits+7)/8;
                if(channels<1||channels>32||blockAlign<channels*bytesPerSample||bytesPerSample<1||bytesPerSample>4)return null;
                if(format==3&&bits!=32)return null;
                if(format==1&&bits!=8&&bits!=16&&bits!=24&&bits!=32)return null;
                return envelope(in,size,bins,channels,bits,blockAlign,format);
            } else {
                skipFully(in,size);
            }
            if((size&1)!=0)skipFully(in,1);
        }
    }

    private static float[] envelope(InputStream in,long dataBytes,int bins,int channels,int bits,int frameBytes,int format) throws IOException {
        long frames=dataBytes/frameBytes;if(frames<1)return null;
        int bytesPerSample=(bits+7)/8;float[] peaks=new float[bins];byte[] frame=new byte[frameBytes];
        long consumedFrame=0;
        for(int bin=0;bin<bins;bin++) {
            long start=frames*bin/bins,end=frames*(bin+1)/bins;
            if(end<=start)continue;
            long region=end-start;int picks=(int)Math.min(24,region);
            for(int pick=0;pick<picks;pick++) {
                long target=start+(region*pick)/picks;
                long gap=target-consumedFrame;if(gap>0)skipFully(in,gap*frameBytes);
                if(!readFully(in,frame,frame.length))return null;
                consumedFrame=target+1;
                float framePeak=0;
                for(int channel=0;channel<channels;channel++) {
                    int at=channel*bytesPerSample;float value;
                    if(format==3) {
                        int raw=(frame[at]&255)|((frame[at+1]&255)<<8)|((frame[at+2]&255)<<16)|(frame[at+3]<<24);
                        value=Float.intBitsToFloat(raw);
                    } else if(bits==8)value=((frame[at]&255)-128)/128f;
                    else if(bits==16){int raw=(frame[at]&255)|(frame[at+1]<<8);value=raw/32768f;}
                    else if(bits==24){int raw=(frame[at]&255)|((frame[at+1]&255)<<8)|(frame[at+2]<<16);value=raw/8388608f;}
                    else {int raw=(frame[at]&255)|((frame[at+1]&255)<<8)|((frame[at+2]&255)<<16)|(frame[at+3]<<24);value=(float)(raw/2147483648.0);}
                    if(!Float.isFinite(value))value=0;
                    framePeak=Math.max(framePeak,Math.min(1f,Math.abs(value)));
                }
                peaks[bin]=Math.max(peaks[bin],framePeak);
            }
        }
        return peaks;
    }

    private static boolean ascii(byte[] data,int offset,String expected) {
        for(int i=0;i<expected.length();i++)if(data[offset+i]!=(byte)expected.charAt(i))return false;
        return true;
    }
    private static int u16(byte[] data,int at){return(data[at]&255)|((data[at+1]&255)<<8);}
    private static long u32(byte[] data,int at){return((long)data[at]&255)|(((long)data[at+1]&255)<<8)|(((long)data[at+2]&255)<<16)|(((long)data[at+3]&255)<<24);}
    private static boolean readFully(InputStream in,byte[] data,int count)throws IOException {
        int at=0;while(at<count){int n=in.read(data,at,count-at);if(n<0)return false;if(n==0){int b=in.read();if(b<0)return false;data[at++]=(byte)b;}else at+=n;}return true;
    }
    private static void skipFully(InputStream in,long count)throws IOException {
        while(count>0){long n=in.skip(count);if(n>0){count-=n;continue;}if(in.read()<0)throw new IOException("Unexpected end of WAV file");count--;}
    }
}
