package com.cleargain.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Volume overview and editable-range guide for the MPC sample editor. */
final class SampleWaveformView extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density;
    private float[] peaks;
    private float start,end=1;
    private String message="WAV PEAKS";

    SampleWaveformView(Context context){super(context);density=getResources().getDisplayMetrics().density;setContentDescription("Sample volume waveform and selected clip range");}
    void setMessage(String value){message=value;invalidate();}
    void setWaveform(float[] values){peaks=values;message=values==null?"VOLUME VIEW AVAILABLE FOR PCM WAV":"SAMPLE VOLUME · WAV PEAKS";invalidate();}
    void setSelection(float from,float to){start=Math.max(0,Math.min(1,from));end=Math.max(start,Math.min(1,to));invalidate();}

    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);float w=getWidth(),h=getHeight(),mid=h*.52f;
        if(peaks==null){paint.setColor(0xffa0aac5);paint.setTextSize(10*density);canvas.drawText(message,8*density,mid+4*density,paint);return;}
        float lo=start*w,hi=end*w;
        paint.setColor(0x2238e5ed);canvas.drawRect(lo,0,hi,h-8*density,paint);
        int count=Math.max(1,(int)(w/(3*density)));float step=w/count,bar=Math.max(1.2f,1.7f*density),half=Math.max(2*density,(h-15*density)*.48f);
        for(int i=0;i<count;i++){
            float x=(i+.5f)*step;int sample=Math.min(peaks.length-1,(int)((long)i*peaks.length/count));
            float amp=(float)Math.pow(Math.max(.025f,peaks[sample]),.72)*half;
            paint.setColor(x>=lo&&x<=hi?0xff38e5ed:0xff716f8d);
            canvas.drawRoundRect(x-bar*.5f,mid-amp,x+bar*.5f,mid+amp,bar*.5f,bar*.5f,paint);
        }
        paint.setColor(0xffff4d91);canvas.drawRect(lo,0,lo+1.5f*density,h-8*density,paint);
        paint.setColor(0xffffbf4d);canvas.drawRect(hi-1.5f*density,0,hi,h-8*density,paint);
        paint.setTextSize(8*density);paint.setColor(0xffa0aac5);canvas.drawText("IN",Math.min(w-20*density,lo+3*density),h-1*density,paint);canvas.drawText("OUT",Math.max(0,hi-22*density),h-1*density,paint);
    }
}
