package com.cleargain.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/** Tappable waveform overview for PCM WAV tracks. */
final class WaveformView extends View {
    interface SeekListener { void seekTo(float fraction); }
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float density;
    private float[] peaks;
    private float position;
    private SeekListener listener;
    private String message="WAV PEAKS";
    WaveformView(Context context){this(context,null);}
    WaveformView(Context context,AttributeSet attrs){super(context,attrs);density=getResources().getDisplayMetrics().density;setFocusable(true);setContentDescription("WAV waveform. Touch or drag to seek.");}
    void setSeekListener(SeekListener callback){listener=callback;}
    void setMessage(String text){message=text;invalidate();}
    void setWaveform(float[] values){peaks=values;message=values==null?"PCM WAV waveform unavailable":"WAV PEAKS · TOUCH TO SEEK";invalidate();}
    void setPosition(float fraction){position=Math.max(0,Math.min(1,fraction));invalidate();}
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);float width=getWidth(),height=getHeight(),middle=height*.52f;
        if(peaks==null){paint.setColor(0xffa0aac5);paint.setTextSize(11*density);canvas.drawText(message,12*density,middle+4*density,paint);return;}
        float step=4*density,bar=Math.max(1.5f,2.2f*density),count=Math.max(1,width/step),half=Math.max(2*density,(height-13*density)*.48f);
        int bars=Math.max(1,(int)count);float done=width*position;
        for(int i=0;i<bars;i++){
            float x=(i+.5f)*width/bars;int sample=Math.min(peaks.length-1,(int)((long)i*peaks.length/bars));
            float amp=(float)Math.pow(Math.max(.035f,peaks[sample]),.72)*half;
            paint.setColor(x<=done?0xff38e5ed:0xff8a5ce8);
            canvas.drawRoundRect(x-bar*.5f,middle-amp,x+bar*.5f,middle+amp,bar*.5f,bar*.5f,paint);
        }
        paint.setColor(0xffb3faff);paint.setTextSize(8*density);canvas.drawText("WAV PEAKS",8*density,height-2*density,paint);
        paint.setColor(0x88ffffff);canvas.drawRect(0,height-7*density,width,height-6*density,paint);
    }
    @Override public boolean onTouchEvent(MotionEvent event){
        if(peaks==null||listener==null)return false;
        if(event.getAction()==MotionEvent.ACTION_DOWN||event.getAction()==MotionEvent.ACTION_MOVE||event.getAction()==MotionEvent.ACTION_UP){
            float fraction=Math.max(0,Math.min(1,event.getX()/Math.max(1,getWidth())));setPosition(fraction);listener.seekTo(fraction);
            if(event.getAction()==MotionEvent.ACTION_UP)performClick();return true;
        }
        return true;
    }
    @Override public boolean performClick(){super.performClick();return true;}
}
