# Soulmans Sound Booster

An ad-free Android media volume booster with a seven-control EQ, four presets, and original artwork based on the owner's portrait. The app has no internet permission, account, analytics, or third-party runtime dependencies.

## Controls

- Tap the large **BOOST** button to start or stop the effect. The foreground notification also has a **Turn off** action.
- **BOOST** adds up to +12 dB through Android's `LoudnessEnhancer`. If that effect is rejected, the app tries a global EQ boost.
- **MEDIA** adjusts the normal Android media volume for the current phone or Bluetooth output.
- **FLAT**, **BASS**, **VOCAL**, and **BRIGHT** load seven-control EQ settings. Moving a band switches to a custom setting. The seven controls are interpolated onto however many frequency bands the device's audio effect actually supports.

## Android limit

Android has deprecated attaching audio effects to the global output mix (audio session `0`). Some apps or Bluetooth routes may ignore the boost even when Android reports that the effect started. Test at a fixed media volume by toggling BOOST on and off. The app does not increase call volume or bypass safe listening limits. Start with low gain; high gain can distort sound or harm hearing or speakers.

## Build and install

Open the project in Android Studio, or install Android SDK Platform 35 and Build Tools 35.0.0, then run:

```text
gradlew.bat assembleDebug
```

The APK is written to `app/build/outputs/apk/debug/app-debug.apk`. Android 8 or newer is required. The application ID remains `com.cleargain.app`, so this version can update the earlier ClearGain APK when signed with the same key.

The owner's local `app/debug.keystore` signs the downloadable APK and is delivered in a separate private signing-key archive. It is excluded from the source archive and GitHub because it is a signing credential. To build an update that installs over the supplied APK, extract that keystore into `app/` before building. Without it, Gradle uses its normal local debug key and Android treats the build as a different signer.

## Project layout

- `app/src/main/java/com/cleargain/app/MainActivity.java`: app screen and controls.
- `app/src/main/java/com/cleargain/app/BoostService.java`: foreground audio effects.
- `app/src/main/java/com/cleargain/app/EqProfile.java`: seven-band preset and frequency mapping.
- `app/src/main/java/com/cleargain/app/EqBandView.java`: touch EQ view.
- `app/src/main/res/drawable-nodpi/`: original generated background, logo, and launcher artwork.
