package com.cleargain.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

final class EqBandView extends View {
    interface OnChange { void onBandChanged(int index, int db); }

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int[] levels = new int[EqProfile.HZ.length];
    private OnChange listener;
    private int activeBand = -1;

    EqBandView(Context context) {
        super(context);
        setContentDescription("Seven-band equalizer. Drag a band to adjust its level.");
    }

    void setLevels(int[] values) {
        System.arraycopy(values, 0, levels, 0, Math.min(values.length, levels.length));
        invalidate();
    }

    void setOnChange(OnChange listener) { this.listener = listener; }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float width = getWidth();
        float top = dp(10);
        float bottom = getHeight() - dp(31);
        float step = width / levels.length;
        paint.setStyle(Paint.Style.FILL);
        paint.setStrokeWidth(dp(1));
        paint.setColor(0x40516a7a);
        canvas.drawLine(dp(8), (top + bottom) / 2, width - dp(8), (top + bottom) / 2, paint);

        for (int i = 0; i < levels.length; i++) {
            float x = step * (i + 0.5f);
            float y = bottom - (levels[i] + 6) / 12f * (bottom - top);
            paint.setColor(0xff304052);
            canvas.drawRoundRect(new RectF(x - dp(3), top, x + dp(3), bottom), dp(3), dp(3), paint);
            paint.setColor(0xff13cfff);
            canvas.drawRoundRect(new RectF(x - dp(3), y, x + dp(3), bottom), dp(3), dp(3), paint);
            paint.setColor(0xff4be5ff);
            canvas.drawCircle(x, y, dp(8), paint);
            paint.setColor(Color.WHITE);
            canvas.drawCircle(x, y, dp(3), paint);
            paint.setColor(0xffbfd4de);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(dp(11));
            paint.setTypeface(android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL));
            canvas.drawText(EqProfile.LABELS[i], x, getHeight() - dp(5), paint);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                activeBand = Math.max(0, Math.min(levels.length - 1,
                        (int) (event.getX() / (getWidth() / (float) levels.length))));
                getParent().requestDisallowInterceptTouchEvent(true);
                updateBand(event.getY());
                return true;
            case MotionEvent.ACTION_MOVE:
                if (activeBand >= 0) updateBand(event.getY());
                return true;
            case MotionEvent.ACTION_UP:
                if (activeBand >= 0) updateBand(event.getY());
                activeBand = -1;
                performClick();
                return true;
            case MotionEvent.ACTION_CANCEL:
                activeBand = -1;
                return true;
            default:
                return super.onTouchEvent(event);
        }
    }

    private void updateBand(float y) {
        float top = dp(10);
        float bottom = getHeight() - dp(31);
        int db = Math.round((bottom - y) / (bottom - top) * 12f - 6f);
        db = Math.max(-6, Math.min(6, db));
        if (levels[activeBand] != db) {
            levels[activeBand] = db;
            invalidate();
            if (listener != null) listener.onBandChanged(activeBand, db);
        }
    }

    @Override public boolean performClick() {
        super.performClick();
        return true;
    }
}
